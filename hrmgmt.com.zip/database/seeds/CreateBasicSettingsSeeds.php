<?php

use Illuminate\Database\Seeder;

class CreateBasicSettingsSeeds extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        if(DB::table('users')->count() <= 0){

        	DB::table('users')->insert([
                'username' => "adamu",
                'name' => "Adamu",
                'email' => "adamu@fptb.edu.ng",
                'password' => bcrypt('secret'),
                'access_level' => 1
            ]); 

            DB::table('users')->insert([
                'username' => "idrisa",
                'name' => "Idrisa",
                'email' => "idrisa@fptb.edu.ng",
                'password' => bcrypt('secret'),
                'access_level' => 1
            ]);
            
            DB::table('users')->insert([
                'username' => "adamu2",
        		'name' => "Adamu 2",
        		'email' => "idrisa2@fptb.edu.ng",
        		'password' => bcrypt('secret'),
        		'access_level' => 2
         	]);
        }
        
    }
}
