<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateStaffExtrasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('staff_extras', function (Blueprint $table) {

            $indexes = Schema::getConnection()->getDoctrineSchemaManager()->listTableIndexes($table->getTable());
            $index_name = 'staff_id';

            if (array_key_exists($index_name, $indexes)) {
                $table->dropUnique('staff_id');
            }

            $table->dropColumn('value');
            $table->string('description');
            $table->string('registeredprobody');
            $table->string('qualificationtype');
            $table->integer('status');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('staff_extras', function (Blueprint $table) {
            $table->string("value");
            $table->dropColumn('description');
            $table->dropColumn('registeredprobody');
            $table->dropColumn('qualificationtype');
            $table->dropColumn('status');
        });
    }
}
