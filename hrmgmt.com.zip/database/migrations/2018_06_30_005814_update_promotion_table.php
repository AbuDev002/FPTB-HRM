<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdatePromotionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('promotions', function (Blueprint $table) {
           $table->dropColumn('level_id');

           if (!Schema::hasColumn('promotions', 'description')) {
                $table->string('description')->after('promotion_date');
           }
           $table->integer('position')->after('description');
           $table->integer('con___')->after('position');
           $table->string('staffclass')->after('con___');
           $table->integer('rank')->after('staffclass');
           $table->string('category')->after('rank');
           $table->integer('step')->after('category');

           // 1 - this is a remarkable/notable promotion
           // 2 - this is a normal/incremental non-remarkable promotion (possibly dubplicates most of the time)
           $table->integer('promotion_indicator')->after('step'); 

           // similar to promotion date just for little easy safety
           $table->date('presentappointdate')->after('promotion_indicator'); 

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('promotions', function (Blueprint $table) {
            //
           $table->integer('level_id');
           if(Schema::hasColumn('promotions', 'description')) {
                $table->dropColumn('description');
           }

           $table->dropColumn('position');
           $table->dropColumn('con___');
           $table->dropColumn('staffclass');
           $table->dropColumn('rank');
           $table->dropColumn('category');
           $table->dropColumn('step');

           // 1 - this is a remarkable/notable promotion
           // 2 - this is a normal/incremental non-remarkable promotion (possibly dubplicates most of the time)
           $table->dropColumn('promotion_indicator'); 

           // similar to promotion date just for little easy safety
           $table->dropColumn('presentappointdate');
        });
    }
}
