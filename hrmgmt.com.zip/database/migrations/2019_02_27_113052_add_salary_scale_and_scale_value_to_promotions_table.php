<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddSalaryScaleAndScaleValueToPromotionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('promotions', function (Blueprint $table) {
            $table->tinyInteger('salary_scale')->default(0); // Salary Scale and Salary Scale Value
            $table->tinyInteger('salary_scale_value')->default(1); // Salary Scale and Salary Scale Value
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('promotions', function (Blueprint $table) {
            $table->dropColumn('salary_scale');
            $table->dropColumn('salary_scale_value');
        });
    }
}
