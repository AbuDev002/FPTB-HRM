<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePromotionGradeLevelsStepsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('promotion_grade_levels_steps', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('salaryscale');
            $table->string('oldgrade');
            $table->string('newgrade');
            $table->unique(['salaryscale', 'oldgrade']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('promotion_grade_levels_steps');
    }
}
