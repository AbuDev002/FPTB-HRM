<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddNextofkinToStaff extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('staff', function (Blueprint $table) {
            $table->string('nok_fname');
            $table->string('nok_lname');
            $table->string('nok_oname');
            $table->string('nok_address');
            $table->string('nok_phoneno');
            $table->string('nok_relationship');
            $table->string('child1_name')->nullable();
            $table->integer('child1_age')->nullable();
            $table->string('child2_name')->nullable();
            $table->integer('child2_age')->nullable();
            $table->string('child3_name')->nullable();
            $table->integer('child3_age')->nullable();
            $table->string('child4_name')->nullable();
            $table->integer('child4_age')->nullable();
            $table->integer('appointmenttype');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('staff', function (Blueprint $table) {
            $table->dropColumn('nok_fname');
            $table->dropColumn('nok_lname');
            $table->dropColumn('nok_oname');
            $table->dropColumn('nok_address');
            $table->dropColumn('nok_phoneno');
            $table->dropColumn('nok_relationship');
            $table->dropColumn('child1_name');
            $table->dropColumn('child1_age');
            $table->dropColumn('child2_name');
            $table->dropColumn('child2_age');
            $table->dropColumn('child3_name');
            $table->dropColumn('child3_age');
            $table->dropColumn('child4_name');
            $table->dropColumn('child4_age');  
            $table->dropColumn('appointmenttype');  
        });
    }
}
