<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRankPromotionalModelTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('rank_promotional_model', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('salaryscale');
            $table->string('old_rank');
            $table->string('new_rank');
            $table->unique(['salaryscale', 'old_rank']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('rank_promotional_model');
    }
}
