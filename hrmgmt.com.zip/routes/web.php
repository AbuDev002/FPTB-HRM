<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@showHomePage');
Route::get('/testa', 'StaffController@processTest');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::resource('/staff', 'StaffController');
Route::get('staff_qualification', 'StaffController@getQualification');
Route::post('staff_qualification', 'StaffController@addQualification');
Route::put('staff_qualification', 'StaffController@updateQualification');
Route::post('staff_status', 'StaffController@updateStaffStatus');
Route::post('staff_level_info', 'StaffController@updateStaffLevelInfo');
Route::post('staff_dept_info', 'StaffController@updateStaffDeptInfo');
Route::post('staff_import', 'StaffController@importStaffInfo')->name('staff.import');


Route::resource('/level', 'LevelController');
Route::resource('/department', 'DepartmentController');
Route::resource('/units', 'UnitController');
Route::resource('/school', 'SchoolController');
Route::resource('/leave', 'LeaveController');
Route::get('/leaveresolver', 'LeaveController@resolver')->name('leave.resolver');
Route::resource('/rank', 'RankController');
Route::resource('/zone', 'ZoneController');
Route::resource('/status', 'StatusController');
Route::resource('/appointmenttype', 'AppointmenttypeController');
Route::resource('/position', 'PositionController');


Route::get('accountprofile', 'StaffController@getProfile')->name('account.profile');
Route::get('staffinfo', 'StaffController@getStaffInfo')->name('account.staffinfo');
Route::get('staffreports', 'StaffController@getStaffReports')->name('staff.reports');
Route::get('promotionlist', 'StaffController@getPromotionList')->name('staff.promotionlist');
Route::get('staffhome', 'HomeController@getStaffHome')->name('account.home');
Route::get('useronline', 'HomeController@getOnlineActiveUsers')->name('user.online');
Route::post('loguserout', 'HomeController@logUserOut')->name('user.logout');
Route::post('createaccount', 'HomeController@createUserAccount')->name('create.account');
Route::get('qualification', 'StaffController@manageQualification')->name('account.addqualification');
Route::post('qualification', 'StaffController@manageQualification')->name('account.addqualification');
Route::get('basic-info-update', 'StaffController@updateBasicInformation')->name('staff.basic-info-update');
Route::post('basic-info-update', 'StaffController@updateBasicInformation')->name('staff.basic-info-update');
Route::get('enablestaffupdate', 'StaffController@toggleStaffUpdate')->name('staff.togglestaffupdate');
Route::get('summary_report', 'StaffController@getStaffSummaryReport')->name('staff.staffsummaryreport');
Route::get('condolence', 'StaffController@addCondolenceMessage')->name('staff.condolencemessage');


// Route::post('accountprofile', 'UtilityController@getProfile');

// Route::get('accountprofile/{id}', 'UtilityController@getUserProfile');

Route::post('/updateaccountaccess', 'StaffController@updateAccountAccess')->name('updateaccountaccess');

#AJAX Request Routes
Route::get('/statelga', 'UtilityController@getLga');
Route::get('/school', 'UtilityController@getDept');
Route::get('/department_unit_select', 'UtilityController@getDeptUnit');
Route::get('/checkstaffno', 'UtilityController@checkstaffno');
Route::get('/checkstaffno_quick_find', 'UtilityController@checkstaffnoquickfind')->name('quick.find');
Route::get('/getranks', 'UtilityController@getRank');

#MORE AJAX REQUESTS
Route::get('/searchbyclassdept', 'SearchController@searchByClassDept');
Route::get('/searchbystaffno', 'SearchController@searchByStaffNo');
Route::get('/searchbystaffnames', 'SearchController@searchByStaffNames');
Route::get('/user_activate', 'HomeController@changeUserStatus');
Route::get('/searchbystaffnames_quick_find', 'UtilityController@searchByStaffNamesQuickSearch');

Route::get('/register', function(){
	return redirect('/');
});

Route::get('/password/reset', function(){
	return redirect('/');
});

Route::resource('/salaryscale', 'SalaryScaleController');
Route::get('/getvalues', 'SalaryScaleController@getSalaryScaleValues');
Route::get('/promote/{staff_id}', 'StaffController@viewPromoteStaffView');
Route::post('/promote', 'StaffController@promoteStaff');
Route::get('/setlastpromotion', 'StaffController@setLastPromotionStaff');

// Handle Rank Promotion Mapping
Route::resource('/rank_promotion_setting', 'RankPromotionStructureController');

// Handle Salary Structure and Steps Mapping From Lecturer to Lecturer Aid
Route::resource('/salary_structure_setting', 'StaffSalaryStructureController');

// Promotion Upload And Process Staff Promotion Controller
Route::resource('/promotion_upload_process', 'PromotionProcessController');
Route::post('/correction_upload_process', 'PromotionProcessController@correctStaffRecordUpload')->name('correction_upload_process.store');
Route::get('/promotion-letter-pdf', 'PromotionProcessController@generatePDF');
Route::get('/getPdfFile', 'PromotionProcessController@getPromotionLetters');