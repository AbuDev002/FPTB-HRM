@php
    $current_page = 'addqualification';
    $current_page = 'staffinfo';

    if(empty($displayType))
        $displayType = "all";
        // $displayType = "edit";
    
@endphp

@include('includes.dashboardheader')

        <div class="row">
            @if($displayType == "show")
                <div class="col-md-10">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">View Staff Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                @include('profile.viewstaff_show')
                            </div>
                        </div>
                    </div>
            @elseif( $displayType == "edit" )
                <div class="col-md-10">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">Update Staff Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                @include('profile.viewstaff_edit', ['some' => 'data'])
                            </div>
                        </div>
                    </div>
            @elseif( $displayType == "all" )
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">List Of Registered Staffs</h4>
                                <p class="category">This is the list of registered Staff</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table id="entirestafflist" class="table table-bordered table-condensed table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Staff No</th>
                                            <th>Staff Name</th>
                                            <th>Staff photo</th>
                                            <th>Gender</th>
                                            <th>Department</th>
                                            <th>Rank</th>
                                            <th>Category</th>
                                            <th>StaffClass</th>
                                            <th>DateOfBirth</th>
                                            <th>Address</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Staff No</th>
                                            <th>Staff Name</th>
                                            <th>Staff photo</th>
                                            <th>Gender</th>
                                            <th>Department</th>
                                            <th>Rank</th>
                                            <th>Category</th>
                                            <th>StaffClass</th>
                                            <th>DateOfBirth</th>
                                            <th>Address</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        
                                        @php
                                            $count_c = 1;
                                        @endphp

                                        @foreach ($staff as $eachStaff)

                                        @php
                                            $department = \App\Department::find(\App\StaffDepartment::where(['staff_id'=>$eachStaff->id])->first()['dept_id'])['description'];
                                            $currentPromotion = \App\Promotions::where('status', \App\Promotions::$APPROVED_PROMOTION)
                                                ->where('promotion_indicator', \App\Promotions::$CURRENT_PROMOTION)->where('staff_id', $eachStaff->id)->get()->first();

                                            $rank = \App\Rank::find($currentPromotion->rank);
                                            $status = \App\Status::find($currentPromotion->staff_status)->status;

                                        @endphp

                                        <tr>
                                            <td>{{ $count_c++ }}</td>
                                            <td>{{$eachStaff->staffno}}</td>
                                            <td>{{"{$eachStaff->fname} {$eachStaff->lname} {$eachStaff->oname}"}}</td>
                                            <td><img class="img" width="100px" height="100px" src="{{\Storage::url("{$eachStaff->photo}")}}"</td>
                                            <td>{{ $eachStaff->gender }}</td>
                                            <td>{{ $department }}</td>
                                            <td>{{ $rank->rank }}</td>
                                            <td>{{ $currentPromotion->category }}</td>
                                            <td>{{ $currentPromotion->staffclass }}</td>
                                            <td>{{"{$eachStaff->dateobirth}"}}</td>
                                            <td>{{"{$eachStaff->address1}"}}</td>
                                            <td>{{"{$status}"}}</td>
                                            <td>

                                                <form action="{{ url("staff/", ['id' => $eachStaff->id]) }}" method="POST" >
                                                    <input type="hidden" name="_method" value="delete">
                                                    @csrf
                                                    <a class="btn btn-sm btn-primary " href="{{url('staff/'.$eachStaff->id.'')}}">View</a>
                                                    <a class="btn btn-sm btn-info " href="{{url('staff/'.$eachStaff->id.'/edit')}}">Edit</a>
                                                    <button class="btn btn-sm btn-danger" href="{{url('staff/'.$eachStaff->id.'/edit')}}">Delete</button>

                                                </form>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                    @endif
                </div>


                </div>
@include('includes.dashboardfooter')
