@php
    $current_page = 'online';
    $page_title = "Users";
@endphp

@include('includes.dashboardheader')

        <div class="row">

                    <div class="col-md-4">
                        <div class="card">
                            <div class="header">
                                <p class="text-info">
                                    @if ($errors->any())
                                        @foreach ($errors->all() as $error)
                                            <li class="info text-danger">{{ $error }}</li>
                                        @endforeach
                                    @endif
                            
                                </p>
                                <h4 class="title">Create SubAmin User Account</h4>
                                <p class="category"></p>
                                 @if (session('status'))
                                    <div class="alert alert-success">
                                        {{ session('status') }}
                                    </div>
                                @endif
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ route('create.account') }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Full Name') }}</label>
                                                <input type="text" placeholder="{{ __('Full Name') }}" class="form-control {{ $errors->has('fullname') ? ' is-invalid' : '' }}" name="fullname" value="{{ old('fullname') }}" required autofocus>
                                                @if ($errors->has('fullname'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('fullname') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('User Name') }}</label>
                                                <input type="text" placeholder="{{ __('User Name') }}" class="form-control {{ $errors->has('username') ? ' is-invalid' : '' }}" name="username" value="{{ old('username') }}" required autofocus>
                                                @if ($errors->has('username'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('username') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Email') }}</label>
                                                <input type="email" placeholder="{{ __('Email') }}" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required autofocus>
                                                @if ($errors->has('email'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('email') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('User Type') }}</label>
                                                <!-- <select name="usertype">
                                                    <option></option>
                                                    <option></option>
                                                    <option></option>
                                                </select> -->
                                                <input readonly="readonly" type="text" placeholder="{{ __('User Type') }}" class="form-control {{ $errors->has('usertype') ? ' is-invalid' : '' }}" name="usertype" value="SubAmin" required autofocus>
                                                @if ($errors->has('usertype'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('usertype') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Photo') }}</label>
                                                <input type="file" required="required" class="form-control" placeholder="{{ __('photo') }}" class="form-control {{ $errors->has('photo') ? ' is-invalid' : '' }}" name="photo" value="{{ old('photo') }}"  autofocus>

                                                @if ($errors->has('photo'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('photo') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('New Password') }}</label>
                                                <input type="password" placeholder="{{ __('New Password') }}" class="form-control {{ $errors->has('newpassword') ? ' is-invalid' : '' }}" name="newpassword" value="{{ old('newpassword') }}" required autofocus>
                                                @if ($errors->has('newpassword'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('newpassword') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('Confirm New Password') }}</label>
                                                <input type="password" placeholder="{{ __('Confirm New Password') }}" class="form-control {{ $errors->has('confirmnewpassword') ? ' is-invalid' : '' }}" name="confirmnewpassword" value="{{ old('confirmnewpassword') }}" required autofocus>
                                                @if ($errors->has('confirmnewpassword'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('confirmnewpassword') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <hr>

                                    <button id="updateStaffbtnsubmit" type="submit" class="btn btn-success btn-fill pull-right">Add New Account</button>
                                    <div class="clearfix"></div>
                                </form>
                                <hr>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-md-6">
                                            <div class="btn-group">
                                                @if(\App\GenSettings::showEnable())
                                                    <button id="btn_enable_staff_update" class="btn btn-success btn-fill hidden"><i class="glyphicon glyphicon-info"></i> Enable Staff Update</button>

                                                    <button id="btn_disable_staff_update" class="btn btn-warning btn-fill "><i class="glyphicon glyphicon-info"></i> Disable Staff Update</button>
                                                @else
                                                    <button id="btn_enable_staff_update" class="btn btn-success btn-fill"><i class="glyphicon glyphicon-info"></i> Enable Staff Update</button>

                                                    <button id="btn_disable_staff_update" class="btn btn-warning btn-fill hidden"><i class="glyphicon glyphicon-info hidden"></i> Disable Staff Update</button>
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                

                            </div>
                        </div>

                                
                    </div>

                    <div class="col-md-8">
                        <div class="row">
                            <h3 class="text-center">List Of Users Online </h3>
                        </div>
                        <div class="row">
                            <div class="content">
                                <div class="panel-group" id="accordion">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a title="Click Or Toggle To View List Of Users Online" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"> <strong>List Of Users Online</strong></a>
                                        </h4>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse in">
                                        <div class="panel-body">
                                            <p><h4>List Of Active Users Currently Online</h4>
                                                        <table id="usersonline_table" class="table table-bordered table-condensed">
                                                            <thead>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    <td>Name</td>
                                                                    <td>User-Status</td>
                                                                    <td>Level</td>
                                                                    <td>Status</td>
                                                                    <td>Last Seen</td>
                                                                    <td>Action</td>
                                                                </tr>
                                                            </thead>
                                                            <tfoot>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    <td>Name</td>
                                                                    <td>User-Status</td>
                                                                    <td>Level</td>
                                                                    <td>Status</td>
                                                                    <td>Last Seen</td>
                                                                    <td>Action</td>
                                                                </tr>
                                                            </tfoot>
                                                            <tbody id="usersonline_table_body">
                                                                @php
                                                                    $count_id = 1;
                                                                @endphp

                                                                @foreach($sessionlast as $thisSession)

                                                                    @php
                                                                        $thisVeryUser = \App\User::find($thisSession->user_id);
                                                                        $cT = \Carbon\Carbon::createFromTimestamp($thisSession->last_activity);
                                                                        $diff_in_minutes = $cT->diffInMinutes(\Carbon\Carbon::now());
                                                                    @endphp
                                                                @if($diff_in_minutes <= 10)
                                                                <tr>
                                                                    <td>{{ $count_id++ }}</td>
                                                                    <td>{{ $thisVeryUser->username }}</td>
                                                                    <td>{{ $thisVeryUser->name }}</td>
                                                                    @if($thisVeryUser->status == \App\User::$USER_ACCOUNT_STATUS_ENABLED)
                                                                    <td><span class="label label-success">Enabled Account</span></td>
                                                                    @else
                                                                    <td><span class="label label-danger">Disabled Account</span></td>
                                                                    @endif
                                                                    <td>{{ ($thisVeryUser->access_level == \App\Staff::$USER_ADMIN) ? "ADMIN" : ( ($thisVeryUser->access_level == \App\Staff::$USER_SUBADMIN) ? "SUB-ADMIN" : ($thisVeryUser->access_level == \App\Staff::$USER_STAFF ? "STAFF" : "STAFF")) }}</td>
                                                                    <td><span class="label label-success">Online (Active)</span></td>
                                                                    <td>{{ $thisVeryUser->isOnline()['last_activity'] }}</td>
                                                                    <td><form loguserout="yes"  action="{{ url('loguserout') }}" method="POST">
                                                                        @csrf
                                                                        <input type="hidden" name="loguserout" value="{{ $thisVeryUser->id }}" >
                                                                        <button class="btn btn-danger btn-sm btn-fill" href="">Logout User</button>
                                                                        </form>
                                                                    </td>
                                                                </tr>
                                                                @endif
                                                                @if($diff_in_minutes > 10 && $diff_in_minutes <= 30)
                                                                <tr>
                                                                    <td>{{ $count_id++ }}</td>
                                                                    <td>{{ $thisVeryUser->username }}</td>
                                                                    <td>{{ $thisVeryUser->name }}</td>
                                                                    @if($thisVeryUser->status == \App\User::$USER_ACCOUNT_STATUS_ENABLED)
                                                                    <td><span class="label label-success">Enabled Account</span></td>
                                                                    @else
                                                                    <td><span class="label label-danger">Disabled Account</span></td>
                                                                    @endif
                                                                    {{-- <td>{{ $thisSession->admin ?? '' }}</td> --}}
                                                                    <td>{{ ($thisVeryUser->access_level == \App\Staff::$USER_ADMIN) ? "ADMIN" : ( ($thisVeryUser->access_level == \App\Staff::$USER_SUBADMIN) ? "SUB-ADMIN" : ($thisVeryUser->access_level == \App\Staff::$USER_STAFF ? "STAFF" : "STAFF")) }}</td>
                                                                    <td><span class="label label-warning">Online (Inactive)</span></td>
                                                                    <td>{{ $thisVeryUser->isOnline()['last_activity'] }}</td>
                                                                     <td><form loguserout="yes" action="{{ url('loguserout') }}" method="POST">
                                                                        @csrf
                                                                        <input type="hidden" name="loguserout" value="{{ $thisVeryUser->id }}" >
                                                                        <button class="btn btn-danger btn-sm btn-fill" href="">Logout User</button>
                                                                        </form>
                                                                    </td>
                                                                </tr>
                                                                @endif

                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div class="row">
                            <h3 class="text-center">List Of Users</h3>
                        </div>
                        <div class="row">
                            <div class="content">
                                <div class="panel-group" id="accordion">
                                @php
                                    $count_id = 1;
                                    $table_count = 1;
                                    $table_count_show = TRUE;
                                @endphp

                                <span class="hidden" id="count_users_info">{{ count($users) }}</span>

                                @foreach ($users as $eachUserH)
                                    
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">

                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne{{ $eachUserH->id}}">{{ $eachUserH->id}}. {{ $eachUserH->name }}</a>
                                            @if ($eachUserH->isOnline()['online'])
                                                <span class="label label-success">Online</span>
                                            @else
                                                <span class="label label-warning">Offline</span>
                                            @endif
                                            
                                            <span class="label label-warning">Last Login: {{ $eachUserH->lastLogin() }}</span>

                                            @if($eachUserH->status == \App\User::$USER_ACCOUNT_STATUS_ENABLED)
                                                <span class="label label-success btn-fill">Account Enabled</span>
                                            @else
                                                <span class="label label-danger btn-fill">Account Disabled</span>
                                            @endif
                                                <span class="label label-primary btn-fill">{{ ($eachUserH->access_level == \App\Staff::$USER_ADMIN) ? "ADMIN" : ( ($eachUserH->access_level == \App\Staff::$USER_SUBADMIN) ? "SUB-ADMIN" : ($eachUserH->access_level == \App\Staff::$USER_STAFF ? "STAFF" : "STAFF")) }}</span>

                                            <span class="pull-right">&nbsp;</span>
                                            <button {{ $eachUserH->access_level == \App\Staff::$USER_ADMIN? '' : ''  }} class="pull-right btn btn-xs btn-warning btn-fill" me_u="ad" user_id="{{ $eachUserH->id }}" action="reset" >Reset Password</button>
                                            <span class="pull-right">&nbsp;</span>
                                            @if ($eachUserH->status == \App\User::$USER_ACCOUNT_STATUS_DISABLED)
                                                <button {{ $eachUserH->access_level == \App\Staff::$USER_ADMIN? 'disabled="disabled"' : ''  }} class="pull-right btn-xs btn btn-success btn-fill" me_u="ad" user_id="{{ $eachUserH->id }}" action="enable" >Enable</button>
                                            @else
                                                <button {{ $eachUserH->access_level == \App\Staff::$USER_ADMIN? 'disabled="disabled"' : ''  }} class="pull-right btn btn-danger btn-fill btn-xs" me_u="ad" user_id="{{ $eachUserH->id }}" action="disable" >Disable</button>
                                            @endif
                                            <span class="clearfix"></span>
                                        </h4>
                                    </div>
                                    {{-- {{ $eachUserH->isOnline()['online'] }} --}}
                                    <div id="collapseOne{{ $eachUserH->id}}" class="panel-collapse collapse">
                                        <div class="panel-body">
                                            <p><h4>Your Account Login History For the Last 30 Days</h4>
                                                        <table id="{{ "userloginhistory_".($table_count++) }}" class="table table-bordered table-condensed">
                                                            <thead>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    {{-- <td>User-Status</td> --}}
                                                                    <td>Admin Initiated</td>
                                                                    <td>TYPE</td>
                                                                    <td>DATETIME</td>
                                                                    <td>LastTime</td>
                                                                    <td>IP-Address</td>
                                                                    <td>Browser</td>
                                                                    <td>Platform</td>
                                                                </tr>
                                                            </thead>
                                                            <tfoot>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    {{-- <td>User-Status</td> --}}
                                                                    <td>Admin Initiated</td>
                                                                    <td>TYPE</td>
                                                                    <td>DATETIME</td>
                                                                    <td>LastTime</td>
                                                                    <td>IP-Address</td>
                                                                    <td>Browser</td>
                                                                    <td>Platform</td>
                                                                </tr>
                                                            </tfoot>
                                                            <tbody>
                                                                @php
                                                                    $count_id = 1;
                                                                    $thisVeryUserLoginHistory = $eachUserH->loginHistory();
                                                                @endphp

                                                                @foreach($thisVeryUserLoginHistory as $eachLoginHistory)
                                                                
                                                                <tr>
                                                                    <td>{{ $count_id++ }}</td>
                                                                    <td>{{ $eachLoginHistory->username }}</td>
                                                                    <td>{{ $eachLoginHistory->admin_id > 0 ? (\App\User::find($eachLoginHistory->admin_id)->name) : "NONE" }}</td>
                                                                    <td>{{ ($eachLoginHistory->type == \App\LoginHistory::$LOGIN_TYPE) ? "LOGIN" : ( ($eachLoginHistory->type == \App\LoginHistory::$LOGOUT_TYPE) ? "LOGOUT" : ($eachLoginHistory->type == \App\LoginHistory::$LOGIN_ATTEMPT ? "LOGIN_ATTEMPT" : "UNKNOWN")) }}</td>
                                                                    <td>{{ $c = new \Carbon\Carbon($eachLoginHistory->created_at) }}</td>
                                                                    <td>{{ ($c = new \Carbon\Carbon($eachLoginHistory->created_at))->diffForHumans() }}</td>
                                                                    <td>{{ $eachLoginHistory->ip }}</td>
                                                                    <td>{{ $eachLoginHistory->browser }}</td>
                                                                    <td>{{ $eachLoginHistory->platform }}</td>
                                                                </tr>

                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </p>
                                        </div>
                                    </div>
                                </div>
                                    @php
                                        $count_id = $count_id + 1;
                                    @endphp

                                @endforeach

                            </div>
                            </div>
                        </div>
                       <!-- <div class="card card-user">
                           <div class="image">
                               <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt="..."/>
                           </div>
                           <div class="content">
                               <div class="author">
                                    <a href="#">
                                   {{-- <img class="avatar border-gray" src="assets/img/faces/face-3.jpg" alt="..."/> --}}
                                          
                                   @if (Auth::user()->access_level == \App\Staff::$USER_STAFF)
                                       @php
                                           $thisStaff = \App\Staff::where('staffno', Auth::user()->username)->get()->first();
                                       @endphp
                                       <img class="avatar border-gray" src="{{\Storage::exists($thisStaff->photo)? url('/').\Storage::url($thisStaff->photo) : url('/').\Storage::url('defaultlogo.jpg')}}" alt="..."/>
                                   @elseif(Auth::user()->access_level == \App\Staff::$USER_SUBADMIN)
                                       {{-- <img class="avatar border-gray" src="{{\Storage::exists($school_in->logo)? url('/').\Storage::url($school_in->logo) : url('/').\Storage::url('defaultlogo.jpg')}}" alt="..."/> --}}
                                       <img class="avatar border-gray" src="{{asset('assets/img/default-avatar.png') }}" alt="..."/>
                                   @elseif(Auth::user()->access_level == \App\Staff::$USER_ADMIN)
                                       <img class="avatar border-gray" src="{{asset('assets/img/default-avatar.png') }}" alt="..."/>
                                   @endif
                                          
                                     <h4 class="title">Mike Andrew<br />
                                        <small>michael24</small>
                                     </h4>
                                   </a>
                               </div>
                               <p class="description text-center"> {{Auth::user()->name}}
                               </p>
                           </div>
                           <hr>
                           <div class="text-center">
                           
                           </div>
                       </div> -->
                   </div>

                </div>


                </div>
@include('includes.dashboardfooter')