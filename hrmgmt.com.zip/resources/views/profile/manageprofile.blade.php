@php
    $current_page = 'profile';
    $page_title = "Your Profile Page";
@endphp

@include('includes.dashboardheader')

        <div class="row">


                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <p class="text-info">
                                    @if ($errors->any())
                                        @foreach ($errors->all() as $error)
                                            <li class="info text-danger">{{ $error }}</li>
                                        @endforeach
                                    @endif
                                </p>
                                <h4 class="title">Manage Your Account</h4>
                                <p class="category"></p>
                                 @if (session('status'))
                                    <div class="alert alert-success">
                                        {{ session('status') }}
                                    </div>
                                @endif
                                @if (session('pasword-update-alert'))
                                    <div class="alert alert-info">
                                        {{ session('pasword-update-alert') }}
                                    </div>
                                @endif
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ route('updateaccountaccess') }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Full Name') }}</label>
                                                <input disabled="disabled" type="text" placeholder="{{ __('Full Name') }}" class="form-control {{ $errors->has('firstname') ? ' is-invalid' : '' }}" name="firstname" value="{{ Auth::user()->name }}" required autofocus>
                                                @if ($errors->has('firstname'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('firstname') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('OldPassword') }}</label>
                                                <input type="password" placeholder="{{ __('Old Password') }}" class="form-control {{ $errors->has('oldpassword') ? ' is-invalid' : '' }}" name="oldpassword" value="{{ old('oldpassword') }}" required autofocus>
                                                @if ($errors->has('oldpassword'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('oldpassword') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('New Password') }}</label>
                                                <input type="password" placeholder="{{ __('New Password') }}" class="form-control {{ $errors->has('newpassword') ? ' is-invalid' : '' }}" name="newpassword" value="{{ old('newpassword') }}" required autofocus>
                                                @if ($errors->has('newpassword'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('newpassword') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('Confirm New Password') }}</label>
                                                <input type="password" placeholder="{{ __('Confirm New Password') }}" class="form-control {{ $errors->has('confirmnewpassword') ? ' is-invalid' : '' }}" name="confirmnewpassword" value="{{ old('confirmnewpassword') }}" required autofocus>
                                                @if ($errors->has('confirmnewpassword'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('confirmnewpassword') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>


                                    </div>
                                    <hr>

                                    <button id="updateStaffbtnsubmit" type="submit" class="btn btn-success btn-fill pull-right">Updated Account Password</button>
                                    <div class="clearfix"></div>
                                </form>
                                @if (\Auth::user()->isAdmin())
                                <form enctype="multipart/form-data" action="{{ route('updateaccountaccess') }}" method="POST">
                                    @csrf
                                    <input type="hidden" name="photo_update" value="TRUE" >
                                    <hr/>
                                     <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>{{ __('Photo') }}</label>
                                                <input required="required" type="file" class="form-control" placeholder="{{ __('photo') }}" class="form-control {{ $errors->has('photo') ? ' is-invalid' : '' }}" name="photo" value="{{ old('photo') }}"  autofocus>

                                                @if ($errors->has('photo'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('photo') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <button id="updateStaffbtnsubmit" type="submit" class="btn btn-success btn-fill pull-left">Updated Profile Picture</button>
                                    <div class="clearfix"></div>
                                </form>
                                @endif
                                

                            </div>
                        </div>
                                <h4>Your Account Login History For the Last 30 Days</h4>
                                <table id="account_login_history_personal" class="table table-bordered table-condensed">
                                    <thead>
                                        <tr>
                                            <td>ID</td>
                                            <td>Username</td>
                                            {{-- <td>User-Status</td>
                                            <td>Admin</td> --}}
                                            <td>TYPE</td>
                                            <td>DATETIME</td>
                                            <td>IP-Address</td>
                                            <td>Browser</td>
                                            <td>Platform</td>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <td>ID</td>
                                            <td>Username</td>
                                            {{-- <td>User-Status</td>
                                            <td>Admin</td> --}}
                                            <td>TYPE</td>
                                            <td>DATETIME</td>
                                            <td>IP-Address</td>
                                            <td>Browser</td>
                                            <td>Platform</td>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        @php
                                            $count_id = 1;
                                        @endphp

                                        @foreach($loginHistory as $eachLoginHistory)
                                        
                                        <tr>
                                            <td>{{ $count_id++ }}</td>
                                            <td>{{ $eachLoginHistory->username }}</td>
                                            <td>{{ ($eachLoginHistory->type == \App\LoginHistory::$LOGIN_TYPE) ? "LOGIN" : ( ($eachLoginHistory->type == \App\LoginHistory::$LOGOUT_TYPE) ? "LOGOUT" : ($eachLoginHistory->type == \App\LoginHistory::$LOGIN_ATTEMPT ? "LOGIN_ATTEMPT" : "UNKNOWN")) }}</td>
                                            <td>{{ $c = new \Carbon\Carbon($eachLoginHistory->created_at) }} - <span>&nbsp;&nbsp;</span> {{ $c->diffForHumans() }}</td>
                                            <td>{{ $eachLoginHistory->ip }}</td>
                                            <td>{{ $eachLoginHistory->browser }}</td>
                                            <td>{{ $eachLoginHistory->platform }}</td>
                                        </tr>

                                        @endforeach
                                    </tbody>
                                </table>
                    </div>

                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">
                                <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt="..."/>
                            </div>
                            <div class="content">
                                <div class="author">
                                     <a href="#">
                                    {{-- <img class="avatar border-gray" src="assets/img/faces/face-3.jpg" alt="..."/> --}}

                                    @if (Auth::user()->isStaff())
                                        @php
                                            $thisStaff = \App\Staff::where('staffno', Auth::user()->username)->get()->first();
                                        @endphp
                                        <img class="avatar border-gray" src="{{\Storage::exists($thisStaff->photo)? url('/').\Storage::url($thisStaff->photo) : url('/').\Storage::url('defaultlogo.jpg')}}" alt="..."/>
                                    @elseif(Auth::user()->isSubAdmin())
                                        <img class="avatar border-gray" src="{{ \Storage::exists(Auth::user()->photo)? url('/').\Storage::url(Auth::user()->photo) : asset('assets/img/default-avatar.png') }}" alt="..."/>
                                    @elseif(Auth::user()->isAdmin())
                                        {{-- <img class="avatar border-gray" src="{{asset('assets/img/default-avatar.png') }}" alt="..."/> --}}
                                        <img class="avatar border-gray" src="{{ \Storage::exists(Auth::user()->photo)? url('/').\Storage::url(Auth::user()->photo) : asset('assets/img/default-avatar.png') }}" alt="..."/>
                                    @endif

                                      <!-- <h4 class="title">Mike Andrew<br />
                                         <small>michael24</small> -->
                                      </h4>
                                    </a>
                                </div>
                                <p class="description text-center"> {{Auth::user()->name}}
                                </p>
                            </div>
                            <hr>
                            <div class="text-center">
                            
                            </div>
                        </div>
                    </div>

                </div>


                </div>
@include('includes.dashboardfooter')