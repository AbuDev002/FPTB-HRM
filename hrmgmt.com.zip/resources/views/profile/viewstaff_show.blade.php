                                                            
<form enctype="multipart/form-data" action="{{ url('staff/'.$thisStaff->id) }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <img class="img-thumbnail" src="{{ Storage::url($thisStaff->photo) }}" width="100px" height="100px">
                                            </div>
                                        </div>
                                    </div>
                                    <table class="table table-condensed table-responsive">
                                        <tr>
                                            <td colspan="5">
                                                <label>{{ __('Staff No') }}</label>
                                                <p>{{ $thisStaff->staffno }}<p/>
                                            </td>
                                          
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>{{ __('First Name') }}</label>
                                                <p>{{ $thisStaff->fname }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('Last Name') }}</label>
                                                <p>{{ $thisStaff->lname }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('Other Name') }}</label>
                                                <p>{{ $thisStaff->oname }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('Gender') }}</label>
                                                <p>{{ $thisStaff->gender == "M"? "Male" : "Female" }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('Date Of Birth') }}</label>
                                                <p>{{ $thisStaff->dateobirth }}<p/>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>{{ __('Marital Status') }}</label>
                                                <p>{{ $thisStaff->maritalstatus == "M" ? "Married" : "Single" }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('Phone No') }}</label>
                                                <p>{{ $thisStaff->phoneno }}<p/>
                                            </td>
                                            <td >
                                                <label>{{ __('Email Address') }}</label>
                                                <p>{{ $thisStaff->email }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('STATE') }}</label>
                                                <p>
                                                    @foreach ($state as $eachState)

                                                        @if($thisStaff->state_id ==$eachState->id)
                                                            {{$eachState->state}}
                                                        @endif

                                                    @endforeach
                                                <p/>
                                            </td>
                                            <td>
                                                <label>{{ __('LGA') }}</label>
                                                <p>
                                                    @foreach($lga as $eachLga)

                                                        @if($thisStaff->lga_id == $eachLga->id)
                                                            {{$eachLga->lga}}
                                                        @endif

                                                    @endforeach
                                                <p/>
                                            </td>
                                        </tr>
                                        <tr>
                                            
                                            <td colspan="3">
                                                <label>{{ __('Address 1') }}</label>
                                                <p>{{ $thisStaff->address1 }}<p/>
                                            </td>
                                            <td colspan="2">
                                                <label>{{ __('Address 2') }}</label>
                                                <p>{{ $thisStaff->address2 }}<p/>
                                            </td>
                                            <td>
                                               
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="5" style="text-align: center;"><strong>Next Of Kin Information</strong></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>{{ __('NEXT OF KIN FIRST NAME') }}</label>
                                                <p>{{ $thisStaff->nok_fname }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('NEXT OF KIN LAST NAME') }}</label>
                                                <p>{{ $thisStaff->nok_lname }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('NEXT OF KIN OTHER NAME') }}</label>
                                                <p>{{ $thisStaff->nok_oname }}<p/>
                                            </td>
                                            <td>
                                               <label>{{ __('NEXT OF KIN ADDRESS') }}</label>
                                                <p>{{ $thisStaff->nok_address }}<p/>
                                            </td>
                                            <td>
                                               <label>{{ __('NEXT OF KIN Relationship') }}</label>
                                                <p>{{ $thisStaff->nok_relationship }}<p/>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="5">
                                                <label>{{ __('NEXT OF KIN PHONE NO') }}</label>
                                                <p>{{ $thisStaff->nok_phoneno }}<p/>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <label>{{ __('CHILD\'S NAME (IF ANY)') }}</label>
                                                <p>{{ $thisStaff->child1_name }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('CHILD\' AGE') }}</label>
                                                <p>{{ $thisStaff->child1_age }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('CHILD\'S NAME (IF ANY)') }}</label>
                                                <p>{{ $thisStaff->child2_name }}<p/>
                                            </td>
                                            <td colspan="2">
                                                <label>{{ __('CHILD\' AGE') }}</label>
                                                <p>{{ $thisStaff->child2_age }}<p/>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>{{ __('CHILD\'S NAME (IF ANY)') }}</label>
                                                <p>{{ $thisStaff->child3_name }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('CHILD\' AGE') }}</label>
                                                <p>{{ $thisStaff->child3_age }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('CHILD\'S NAME (IF ANY)') }}</label>
                                                <p>{{ $thisStaff->child4_name }}<p/>
                                            </td>
                                            <td>
                                                <label>{{ __('CHILD\' AGE') }}</label>
                                                <p>{{ $thisStaff->child4_age }}<p/>
                                            </td>
                                           
                                        </tr>

                                    </table>                                
                                 
                                    <hr id="childsection2_hr" class="">

                                    <table class="table table-condensed">
                                        <tr>
                                            
                                            <td colspan="2">
                                                <label>{{ __('SCHOOL') }}</label>
                                                <p>
                                                    @foreach ($school as $eachSchool)
                                                        @if($staffdepartment->school == $eachSchool->id)
                                                            {{$eachSchool->school}}
                                                        @endif
                                                    @endforeach
                                                <p/>
                                            </td>
                                            <td colspan="2">
                                                <label>{{ __('DEPARTMENT') }}</label>
                                                <p>
                                                     @foreach ($department as $eachDepartment)
                                                        @if($staffdepartment->dept_id == $eachDepartment->id)
                                                            {{$eachDepartment->department}} {{ $eachDepartment->description}}
                                                        @endif
                                                    @endforeach
                                                <p/>
                                            </td>
                                           
                                        </tr>
                                        <tr>
                                            <td >
                                                <label>{{ __('FIRST APPOINTMENT DATE') }}</label>
                                                <p>
                                                    {{ $thisStaff->firstappointdate }}
                                                <p/>
                                            </td>
                                            <td >
                                                <label>{{ __('APPOINTMENT TYPE') }}</label>
                                                <p>
                                                     @foreach ($appointmenttype as $anAppointment)
                                                        @if($currentPromotion->appointmenttype == $anAppointment->id)
                                                            {{$anAppointment->appointmenttype}}
                                                        @endif
                                                    @endforeach
                                                <p/>
                                            </td>
                                            <td >
                                                <label>{{ __('POSITION (IF ANY)') }}</label>
                                                <p>
                                                     @foreach ($position as $eachPosition)
                                                        @if($currentPromotion->position == $eachPosition->id)
                                                            {{$eachPosition->position}}
                                                        @endif
                                                    @endforeach
                                                <p/>
                                            </td>
                                            <td >
                                                <label>{{ __('STEP') }}</label>
                                                <p>
                                                    {{ $currentPromotion->step }}
                                                <p/>
                                            </td>
                                           
                                        </tr>

                                        <tr>
                                            <td >
                                                <label>{{ __('PRESENT APPOINTMENT DATE') }}</label>
                                                <p>
                                                    {{ $currentPromotion->presentappointdate }}
                                                <p/>
                                            </td>
                                            <td >
                                                <label>{{ __('STAFF CLASS') }}</label>
                                                <p>
                                                     {{ $currentPromotion->staffclass == "AS" ? "Academic Staff" : "Non-Academic Staff"}}
                                                <p/>
                                            </td>
                                            <td >
                                                <label>{{ __('RANK') }}</label>
                                                <p>
                                                     @foreach($rank as $eachRank)
                                                        {{ $currentPromotion->rank == $eachRank->id ? $eachRank->rank : '' }}
                                                     @endforeach
                                                <p/>
                                            </td>
                                            <td >
                                                <label>{{ $currentPromotion->staffclass == "AS" ? __('CONPCASS') : __('CONTEDISS') }}</label>
                                                <p>
                                                    {{ $currentPromotion->con___ }}
                                                <p/>
                                            </td>
                                           
                                        </tr>

                                        <tr>
                                            <td >
                                                <label>{{ __('CATEGORY') }}</label>
                                                <p>
                                                    {{ $currentPromotion->category =="JS"? "Junior Staff" : "Senior Staff" }}
                                                <p/>
                                            </td>
                                            <td >
                                                <label>{{ __('GPZONE') }}</label>
                                                <p>
                                                     @foreach($gpzone as $eachGPZone)
                                                        @if ($thisStaff->gpzone==$eachGPZone->id)
                                                            {{$eachGPZone->gpzone}} [{{$eachGPZone->description}}]
                                                        @endif
                                                    @endforeach
                                                <p/>
                                            </td>
                                            <td colspan="2" >
                                                <label>{{ __('STATUS') }}</label>
                                                <p>
                                                     @foreach($status as $eachStatus)
                                                        @if ($thisStaff->status==$eachStatus->id)
                                                            {{$eachStatus->status}}
                                                        @endif
                                                    @endforeach
                                                <p/>
                                            </td>
                                           
                                        </tr>
                                        
                                    </table>

                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend  title="#qualification" class="title">Qualification [APPROVED]</legend>
                                            <table class="table table-responsive">
                                                <thead>
                                                    <tr>
                                                        <td>ID</td>
                                                        <td>Q-TYPE</td>
                                                        <td>QUALIFICATION-TITLE</td>
                                                        <td>QUALIFICATION-DESCRIPTION</td>
                                                        <td>REGISTERED PROFESSIONAL BODY</td>
                                                        <td>STATUS</td>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                       <td>ID</td>
                                                       <td>Q-TYPE</td>
                                                       <td>QUALIFICATION-TITLE</td>
                                                       <td>QUALIFICATION-DESCRIPTION</td>
                                                       <td>REGISTERED PROFESSIONAL BODY</td>
                                                       <td>STATUS</td>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    @php
                                                        $countSN = 1;
                                                    @endphp
        
                                                    @foreach($staffExtras as $eachStaffExtra)

                                                        @if ($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS )
                                                        <tr>
                                                            <td>{{ $countSN++ }}</td>
                                                            <td>{{ $eachStaffExtra->qualificationtype }}</td>
                                                            <td>{{ $eachStaffExtra->title }}</td>
                                                            <td>{{ $eachStaffExtra->description }}</td>
                                                            <td>{{ $eachStaffExtra->registeredprobody }}</td>
                                                            <td id="staffextras_td{{ $eachStaffExtra->id }}" >
                                                            @if ($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS)
                                                                <span class="label label-success">approved</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS)
                                                                <span class="label label-info">accepted</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$PROPOSED_QUALIFICATION_STATUS)
                                                                <span class="label label-warning">proposed</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$REJECTED_QUALIFICATION_STATUS)
                                                                <span class="label label-danger">rejected</span>
                                                            @endif
                                                            </td>
                                                        </tr>
                                                        @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                            <hr style="border: 1px solid grey;" />
                                        </fieldset>
                                    </div>
                                    {{-- <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend  title="#qualification" class="title">Qualification [YET TO BE APPROVED]</legend>
                                            <table class="table table-responsive">
                                                <thead>
                                                    <tr>
                                                        <td>ID</td>
                                                        <td>Q-TYPE</td>
                                                        <td>QUALIFICATION-TITLE</td>
                                                        <td>QUALIFICATION-DESCRIPTION</td>
                                                        <td>REGISTERED PROFESSIONAL BODY</td>
                                                        <td>STATUS</td>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                       <td>ID</td>
                                                       <td>Q-TYPE</td>
                                                       <td>QUALIFICATION-TITLE</td>
                                                       <td>QUALIFICATION-DESCRIPTION</td>
                                                       <td>REGISTERED PROFESSIONAL BODY</td>
                                                       <td>STATUS</td>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    @php 
                                                        $countSN = 1;
                                                    @endphp

                                                    @foreach($staffExtras as $eachStaffExtra)
                                                        @if ($eachStaffExtra->status != \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS )
                                                        <tr>
                                                            <td>{{ $countSN++ }}</td>
                                                            <td>{{ $eachStaffExtra->qualificationtype }}</td>
                                                            <td>{{ $eachStaffExtra->title }}</td>
                                                            <td>{{ $eachStaffExtra->description }}</td>
                                                            <td>{{ $eachStaffExtra->registeredprobody }}</td>
                                                            <td id="staffextras_td{{ $eachStaffExtra->id }}" >
                                                            @if ($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS)
                                                                <span class="label label-success">approved</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS)
                                                                <span class="label label-info">accepted</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$PROPOSED_QUALIFICATION_STATUS)
                                                                <span class="label label-warning">proposed</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$REJECTED_QUALIFICATION_STATUS)
                                                                <span class="label label-danger">rejected</span>
                                                            @endif
                                                            </td>
                                                        </tr>
                                                        @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                            <hr style="border: 1px solid grey;" />
                                        </fieldset>
                                    </div>
 --}}

                                    {{-- <button id="add_qualification" type="button" class="btn btn-info btn-fill pull-left">Print</button> --}}
                                    <button onclick="window.print()" type="button" class="btn btn-info btn-fill pull-left">Print</button>
                                    {{-- <a id="btnsubmit" href="{{ url('staff/'.$thisStaff->id.'/edit') }}" class="btn btn-info btn-fill pull-right">Edit Staff</a> --}}
                                    <div class="clearfix"></div>
                                </form>
                                <br>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="panel-group" id="accordion">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        <a title="Click Or Toggle Collapse" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"> <strong>Promotion History</strong></a>
                                                    </h4>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse in">
                                                    <div class="panel-body">
                                                        <table class="table table-bordered table-hover table-responsive table-striped table-condensed">
                                                            <thead>
                                                                <tr>
                                                                    <td>S/N</td>
                                                                    <td>Position</td>
                                                                    <td>Staff-Class</td>
                                                                    <td>Rank</td>
                                                                    <td>Category</td>
                                                                    <td>Step</td>
                                                                    <td>Present Appointment Date</td>
                                                                    <td>Status</td>
                                                                    <td>Appointment-Type</td>
                                                                    <td>Staff-Status</td>
                                                                    <td>Promotion-Indicator</td>
                                                                    <td>Promotion-Date</td>

                                                                </tr>
                                                            </thead>
                                                            <tfoot>
                                                                <tr>
                                                                    <td>S/N</td>
                                                                    <td>Position</td>
                                                                    <td>Staff-Class</td>
                                                                    <td>Rank</td>
                                                                    <td>Category</td>
                                                                    <td>Step</td>
                                                                    <td>Present Appointment Date</td>
                                                                    <td>Status</td>
                                                                    <td>Appointment-Type</td>
                                                                    <td>Staff-Status</td>
                                                                    <td>Promotion-Indicator</td>
                                                                    <td>Promotion-Date</td>

                                                                </tr>
                                                            </tfoot>
                                                            <tbody>
                                                                @php
                                                                    $count_sn_ = 1;
                                                                @endphp

                                                                @foreach($thisStaff->getAllPromotionHistory() as $eachPromotion)
                                                                    <tr>
                                                                        <td>{{ $count_sn_++ }}</td>
                                                                        <td>{{ $eachPromotion->getPosition()}}</td>
                                                                        <td>{{ $eachPromotion->getStaffClass()}}</td>
                                                                        <td>{{ $eachPromotion->getRank()}}</td>
                                                                        <td>{{ $eachPromotion->category}}</td>
                                                                        <td>{{ $eachPromotion->step}}</td>
                                                                        <td>{{ $eachPromotion->presentappointdate}}</td>
                                                                        <td>{{ $eachPromotion->status == \App\Promotions::$APPROVED_PROMOTION? "APPROVED" : "DISAPPROVED" }}</td>
                                                                        <td>{{ $eachPromotion->getAppointmentType() }}</td>
                                                                        <td>{{ $eachPromotion->getStaffStatus() }}</td>
                                                                        <td>{{ $eachPromotion->promotion_indicator == \App\Promotions::$CURRENT_PROMOTION? "CURRENT" : "PAST" }}</td>
                                                                        <td>{{ $eachPromotion->created_at }}</td>
                                                                    </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        <a title="Click Or Toggle Collapse" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"> <strong>Staff Department History</strong></a>
                                                    </h4>
                                                </div>
                                                <div id="collapseTwo" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <table class="table table-bordered table-hover table-responsive table-striped table-condensed">
                                                            <thead>
                                                                <tr>
                                                                    <td>S/N</td>
                                                                    <td>Department</td>
                                                                    <td>School</td>
                                                                    <td>Status</td>
                                                                    <td>Date</td>
                                                                </tr>
                                                            </thead>
                                                            <tfoot>
                                                                <tr>
                                                                    <td>S/N</td>
                                                                    <td>Department</td>
                                                                    <td>School</td>
                                                                    <td>Status</td>
                                                                    <td>Date</td>
                                                                </tr>
                                                            </tfoot>
                                                            <tbody>
                                                                @php
                                                                    $count_sn_ = 1;
                                                                @endphp

                                                                @foreach($thisStaff->getDepartmentHistory() as $eachDepartmentH)
                                                                    <tr>
                                                                        <td>{{ $count_sn_++ }}</td>
                                                                        <td>{{ $eachDepartmentH->getDepartment()}}</td>
                                                                        <td>{{ $eachDepartmentH->getSchool()}}</td>
                                                                        <td>{{ $eachDepartmentH->status == \App\StaffDepartment::$STATUS_CURRENT ? "CURRENT" : "PAST" }}</td>
                                                                        <td>{{ $eachDepartmentH->created_at}}</td>
                                                                        
                                                                    </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>


                                <div id="conpcass" class="form-group hidden">
                                                <label id="con_label">{{ __('CONPCASS') }}</label>
                                                <select class="form-control {{ $errors->has('con___') ? ' is-invalid' : '' }} " name="con___" required>

                                                    @for ($i = 1; $i < 10; $i++)
                                                        <option {{old('con___')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>
                                                @if ($errors->has('con___'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('con___') }}</strong>
                                                        </span>
                                                @endif
                                </div>
                                <div id="contediss" class="form-group hidden">
                                                <label id="con_label">{{ __('CONTEDISS') }}</label>
                                                <select class="form-control {{ $errors->has('con___') ? ' is-invalid' : '' }} " name="con___" required>

                                                    @for ($i = 1; $i < 16; $i++)
                                                        <option {{old('con___')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>
                                                @if ($errors->has('con___'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('con___') }}</strong>
                                                        </span>
                                                @endif
                                 </div>

                                 <div id="qualificationformcontrols" class="qualificationformcontrols hidden">
                                    <div class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select name="qualificationtype[]" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option value="OND">OND</option>
                                                            <option value="HND">HND</option>
                                                            <option value="DEG">Degree</option>
                                                            <option value="PGD">PGD</option>
                                                            <option value="MSC">MSC</option>
                                                            <option value="PHD">PHD</option>
                                                            <option value="OTHERS">Others</option>
                                                        </select>
                                                        @if ($errors->has('qualificationtype[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtype[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input required="required" name="qualificationtitle[]" type="text" class="form-control" placeholder="Qualification Title" value="{{ old('qualificationtitle[]') }}">
                                                        @if ($errors->has('qualificationtitle[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtitle[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input required="required" name="qualificationdesc[]" type="text" class="form-control" placeholder="Qualification Description" value="{{ old('qualificationdesc[]') }}"  required="required" >
                                                        @if ($errors->has('qualificationdesc[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationdesc[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea required="required" name="registeredprobody[]" class="form-control" placeholder="Registered Professional Body" >{{ old('registeredprobody[]', "NONE") }}</textarea>
                                                        @if ($errors->has('registeredprobody[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('registeredprobody[]') }}</strong>
                                                                </span>
                                                        @endif

                                                        <input type="hidden" name="qualificationcount[]" value="1" >
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <button onclick="this.parentNode.parentNode.remove()" type="button" class="btn-sm btn-danger pull-right btn removebtn">Remove</button>
                                                </div>
                                                <div class="col-md-12" style="padding-top: 1px; padding-left: 1px;">
                                                <hr style="border: 1px solid grey;">
                                                </div>
                                            </div>
                                 </div>