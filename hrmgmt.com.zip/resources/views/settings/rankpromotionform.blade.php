@php
    $current_page = 'rankpromotionform';
@endphp

@include('includes.dashboardheader')

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">

                            @isset($displaystate)
                            @if ($displaystate == 'edit')
                                <div class="header">
                                <h4 class="title">Update Rank Promotion Rules Settings</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ url('rank_promotion_setting/'.$this_rankpromotionId->id )}}" method="POST">

                                    @method('PUT')
                                    @csrf

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Salary Scale') }}</label>
                                                <select type="text" placeholder="{{ __('Select Salary Scale') }}" class="form-control {{ $errors->has('salaryscale') ? ' is-invalid' : '' }}" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    @foreach ($salaryscale as $eachSalaryScale)

                                                        @if ($eachSalaryScale->id == old('salaryscale', $this_rankpromotionId->salaryscale))
                                                            <option selected="selected" value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @else
                                                            <option value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('salaryscale'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('salaryscale') }}</strong>
                                                        </span>
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                    
                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('From Old Rank: ') }}</label>
                                                <select type="text" placeholder="{{ __('Select From Old Rank') }}" class="form-control {{ $errors->has('old_rank') ? ' is-invalid' : '' }}" name="old_rank" required autofocus>
                                                    <option value="">Select From Old Rank</option>

                                                    @foreach ($rank as $eachRanks)
                                                        @if ($eachRanks->id == old('old_rank', $this_rankpromotionId->old_rank))
                                                            <option selected="selected" value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @else
                                                            <option value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('old_rank'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('old_rank') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('To New Rank: ') }}</label>
                                                 <select type="text" placeholder="{{ __('Select To New Rank') }}" class="form-control {{ $errors->has('new_rank') ? ' is-invalid' : '' }}" name="new_rank" required autofocus>
                                                    <option value="">Select To New Rank</option>

                                                    @foreach ($rank as $eachRanks)
                                                        @if ($eachRanks->id == old('new_rank', $this_rankpromotionId->new_rank))
                                                            <option selected="selected" value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @else
                                                            <option value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('new_rank'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('new_rank') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                    </div>
    
                                    <a href="{{ url("rank_promotion_setting/create")}}" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Rank Promotion Rules</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @elseif($displaystate == 'delete')
                                <div class="header">
                                <h4 class="title text-danger">Delete Rank Promotion Rule Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ url('rank_promotion_setting/'.$this_rankpromotionId->id )}}" method="POST">

                                    @method('DELETE')
                                    @csrf

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Rank Promotion Rule?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Salary Scale') }}</label>
                                                <select disabled="disabled" type="text" placeholder="{{ __('Select Salary Scale') }}" class="form-control {{ $errors->has('salaryscale') ? ' is-invalid' : '' }}" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    @foreach ($salaryscale as $eachSalaryScale)
                                                        @if ($eachSalaryScale->id == old('salaryscale', $this_rankpromotionId->salaryscale))
                                                            <option selected="selected" value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @else
                                                            <option value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('salaryscale'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('salaryscale') }}</strong>
                                                        </span>
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('From Old Rank: ') }}</label>
                                                <select disabled type="text" placeholder="{{ __('Select From Old Rank') }}" class="form-control {{ $errors->has('old_rank') ? ' is-invalid' : '' }}" name="old_rank" required autofocus>
                                                    <option value="">Select From Old Rank</option>

                                                    @foreach ($rank as $eachRanks)
                                                        @if ($eachRanks->id == old('old_rank', $this_rankpromotionId->old_rank))
                                                            <option selected="selected" value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @else
                                                            <option value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('old_rank'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('old_rank') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('To New Rank: ') }}</label>
                                                 <select disabled type="text" placeholder="{{ __('Select To New Rank') }}" class="form-control {{ $errors->has('new_rank') ? ' is-invalid' : '' }}" name="new_rank" required autofocus>
                                                    <option value="">Select To New Rank</option>

                                                    @foreach ($rank as $eachRanks)
                                                        @if ($eachRanks->id == old('new_rank', $this_rankpromotionId->new_rank))
                                                            <option selected="selected" value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @else
                                                            <option value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('new_rank'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('new_rank') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
    
                                    <a href="{{ url("rank_promotion_setting/create")}}" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE Rank Promotion Rule</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @else
                                <div class="header">
                                    <h4 class="title">View Rank Promotion Rules Settings</h4>
                                    <p class="category"></p>
                                </div>
                                <div class="content">
                                    <form enctype="multipart/form-data" >

                                        <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Salary Scale') }}</label>
                                                <select disabled="disabled" type="text" placeholder="{{ __('Select Salary Scale') }}" class="form-control {{ $errors->has('salaryscale') ? ' is-invalid' : '' }}" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    @foreach ($salaryscale as $eachSalaryScale)
                                                        @if ($eachSalaryScale->id == old('salaryscale', $this_rankpromotionId->salaryscale))
                                                            <option selected="selected" value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @else
                                                            <option value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('salaryscale'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('salaryscale') }}</strong>
                                                        </span>
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('From Old Rank: ') }}</label>
                                                <select disabled type="text" placeholder="{{ __('Select From Old Rank') }}" class="form-control {{ $errors->has('old_rank') ? ' is-invalid' : '' }}" name="old_rank" required autofocus>
                                                    <option value="">Select From Old Rank</option>

                                                    @foreach ($rank as $eachRanks)
                                                        @if ($eachRanks->id == old('old_rank', $this_rankpromotionId->old_rank))
                                                            <option selected="selected" value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @else
                                                            <option value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('old_rank'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('old_rank') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('To New Rank: ') }}</label>
                                                 <select disabled type="text" placeholder="{{ __('Select To New Rank') }}" class="form-control {{ $errors->has('new_rank') ? ' is-invalid' : '' }}" name="new_rank" required autofocus>
                                                    <option value="">Select To New Rank</option>

                                                    @foreach ($rank as $eachRanks)
                                                        @if ($eachRanks->id == old('new_rank', $this_rankpromotionId->new_rank))
                                                            <option selected="selected" value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @else
                                                            <option value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('new_rank'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('new_rank') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>


                                    <a href="{{ url("rank_promotion_setting/create") }}" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="{{ url("rank_promotion_setting/{$this_rankpromotionId->id}").'/edit' }}" class="btn btn-info btn-fill pull-right">Edit Rank Promotion Rules Setting</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @endif
                        @else

                            <div class="header">
                                <h4 class="title">Add Rank Promotion Rules Settings</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                @if(\Session::has('status'))
                                  <div class="alert alert-success">{{ \Session::get('status') }}</div>
                               @endif
                                <form enctype="multipart/form-data" action="{{ route('rank_promotion_setting.store') }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Salary Scale') }}</label>
                                                <select type="text" placeholder="{{ __('Select Salary Scale') }}" class="form-control {{ $errors->has('salaryscale') ? ' is-invalid' : '' }}" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    @foreach ($salaryscale as $eachSalaryScale)
                                                        @if ($eachSalaryScale->id == old('salaryscale'))
                                                            <option selected="selected" value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @else
                                                            <option value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('salaryscale'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('salaryscale') }}</strong>
                                                        </span>
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('From Old Rank: ') }}</label>
                                                <select type="text" placeholder="{{ __('Select From Old Rank') }}" class="form-control {{ $errors->has('old_rank') ? ' is-invalid' : '' }}" name="old_rank" required autofocus>
                                                    <option value="">Select From Old Rank</option>

                                                    @foreach ($rank as $eachRanks)
                                                        @if ($eachRanks->id == old('old_rank'))
                                                            <option selected="selected" value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @else
                                                            <option value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('old_rank'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('old_rank') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('To New Rank: ') }}</label>
                                                 <select type="text" placeholder="{{ __('Select To New Rank') }}" class="form-control {{ $errors->has('new_rank') ? ' is-invalid' : '' }}" name="new_rank" required autofocus>
                                                    <option value="">Select To New Rank</option>

                                                    @foreach ($rank as $eachRanks)
                                                        @if ($eachRanks->id == old('new_rank'))
                                                            <option selected="selected" value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @else
                                                            <option value="{{ $eachRanks->id }}">{{ $eachRanks->rank }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('new_rank'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('new_rank') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add Rank Promotion Rule Settings</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @endisset
                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">All Rank Promotion Rule Settings Listing</h4>
                                <p class="category">Rank Promotion Rules Settings</p>
                                @if (session('salaryscale'))
                                    <div class="alert alert-success">
                                        {{ session('salaryscale') }}
                                    </div>
                                @endif
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table id="entirestafflist" class="table table-hover table-striped">
                                    <thead>
                                        <th>Salary Scale</th>
                                        <th>From Old Rank</th>
                                        <th>To New Rank</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        @foreach ($rank_promotion_model as $eachRankPromotion)

                                        <tr>
                                            <td>{{ $eachRankPromotion->getSalaryScale() }}</td>
                                            <td>{{ $eachRankPromotion->getOldRank() }}</td>
                                            <td>{{"{$eachRankPromotion->getNewRank()}"}}</td>
                                            <td>
                                                <a class="btn btn-sm btn-info" href="{{ url("rank_promotion_setting/$eachRankPromotion->id").'/edit' }}" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="{{ url("rank_promotion_setting/$eachRankPromotion->id") }}" >View</a>
                                                <a class="btn btn-sm btn-danger" href="{{ url("rank_promotion_setting/$eachRankPromotion->id?action=del") }}" >Delete</a>
                                            </td>
                                        </tr>

                                        @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
@include('includes.dashboardfooter')