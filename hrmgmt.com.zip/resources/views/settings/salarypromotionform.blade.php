@php
    $current_page = 'salary_structure_setting';
@endphp

@include('includes.dashboardheader')

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">

                            @isset($displaystate)
                            @if ($displaystate == 'edit')
                                <div class="header">
                                <h4 class="title">Update Salary Scale/Step Rules Settings</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ url('salary_structure_setting/'.$this_salaryscaleSPId->id )}}" method="POST">

                                    @method('PUT')
                                    @csrf

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Salary Scale') }}</label>
                                                <select type="text" placeholder="{{ __('Select Salary Scale') }}" class="form-control {{ $errors->has('salaryscale') ? ' is-invalid' : '' }}" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    @foreach ($salaryscale as $eachSalaryScale)

                                                        @if ($eachSalaryScale->id == old('salaryscale', $this_salaryscaleSPId->salaryscale))
                                                            <option selected="selected" value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @else
                                                            <option value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('salaryscale'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('salaryscale') }}</strong>
                                                        </span>
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('From Old Level/Step: ') }}</label>
                                                <input type="text" placeholder="{{ __('Old Grade Level/Step') }}" class="form-control {{ $errors->has('oldgrade') ? ' is-invalid' : '' }}" name="oldgrade" value="{{ old('oldgrade', $this_salaryscaleSPId->oldgrade) }}" required autofocus>
                                                @if ($errors->has('oldgrade'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('oldgrade') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('To New Level/Step: ') }}</label>
                                                <input type="text" placeholder="{{ __('New Grade Level/Step') }}" class="form-control {{ $errors->has('newgrade') ? ' is-invalid' : '' }}" name="newgrade" value="{{ old('newgrade', $this_salaryscaleSPId->newgrade ) }}" required autofocus>
                                                @if ($errors->has('newgrade'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('newgrade') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="{{ url("salary_structure_setting/create")}}" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Promotion Salary Scale/Steps</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @elseif($displaystate == 'delete')
                                <div class="header">
                                <h4 class="title text-danger">Delete Promotion Salary Structure Scale Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ url('salary_structure_setting/'.$this_salaryscaleSPId->id )}}" method="POST">

                                    @method('DELETE')
                                    @csrf

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Promotion Salary Structure/Scale?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Salary Scale') }}</label>
                                                <select disabled="disabled" type="text" placeholder="{{ __('Select Salary Scale') }}" class="form-control {{ $errors->has('salaryscale') ? ' is-invalid' : '' }}" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    @foreach ($salaryscale as $eachSalaryScale)
                                                        @if ($eachSalaryScale->id == old('salaryscale', $this_salaryscaleSPId->salaryscale))
                                                            <option selected="selected" value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @else
                                                            <option value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('salaryscale'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('salaryscale') }}</strong>
                                                        </span>
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('From Old Level/Step: ') }}</label>
                                                <input type="text" readonly="readonly" placeholder="{{ __('Old Grade Level/Step') }}" class="form-control {{ $errors->has('oldgrade') ? ' is-invalid' : '' }}" name="oldgrade" value="{{ old('oldgrade', $this_salaryscaleSPId->oldgrade) }}" required autofocus>
                                                @if ($errors->has('oldgrade'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('oldgrade') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('To New Level/Step: ') }}</label>
                                                <input type="text" placeholder="{{ __('New Grade Level/Step') }}" class="form-control {{ $errors->has('newgrade') ? ' is-invalid' : '' }}" name="newgrade" value="{{ old('newgrade', $this_salaryscaleSPId->newgrade) }}" readonly="readonly" required autofocus>
                                                @if ($errors->has('newgrade'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('newgrade') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="{{ url("salary_structure_setting/create")}}" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE Promotion Salary Structure/Scale</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @else
                                <div class="header">
                                    <h4 class="title">View Salary Scale/Step Rules Settings</h4>
                                    <p class="category"></p>
                                </div>
                                <div class="content">
                                    <form enctype="multipart/form-data" >

                                        <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Salary Scale') }}</label>
                                                <select disabled="disabled" type="text" placeholder="{{ __('Select Salary Scale') }}" class="form-control {{ $errors->has('salaryscale') ? ' is-invalid' : '' }}" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    @foreach ($salaryscale as $eachSalaryScale)
                                                        @if ($eachSalaryScale->id == old('salaryscale', $this_salaryscaleSPId->salaryscale))
                                                            <option selected="selected" value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @else
                                                            <option value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('salaryscale'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('salaryscale') }}</strong>
                                                        </span>
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('From Old Level/Step: ') }}</label>
                                                <input type="text" readonly="readonly" placeholder="{{ __('Old Grade Level/Step') }}" class="form-control {{ $errors->has('oldgrade') ? ' is-invalid' : '' }}" name="oldgrade" value="{{ old('oldgrade', $this_salaryscaleSPId->oldgrade) }}" required autofocus>
                                                @if ($errors->has('oldgrade'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('oldgrade') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('To New Level/Step: ') }}</label>
                                                <input type="text" placeholder="{{ __('New Grade Level/Step') }}" class="form-control {{ $errors->has('newgrade') ? ' is-invalid' : '' }}" name="newgrade" value="{{ old('newgrade', $this_salaryscaleSPId->newgrade) }}" readonly="readonly" required autofocus>
                                                @if ($errors->has('newgrade'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('newgrade') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>


                                    <a href="{{ url("salary_structure_setting/create") }}" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="{{ url("salary_structure_setting/{$this_salaryscaleSPId->id}").'/edit' }}" class="btn btn-info btn-fill pull-right">Edit Salary Scale Promotion Rules Setting</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @endif
                        @else

                            <div class="header">
                                <h4 class="title">Add Salary Scale/Step Rules Settings</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                @if(\Session::has('status'))
                                  <div class="alert alert-success">{{ \Session::get('status') }}</div>
                               @endif
                                <form enctype="multipart/form-data" action="{{ route('salary_structure_setting.store') }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Salary Scale') }}</label>
                                                <select type="text" placeholder="{{ __('Select Salary Scale') }}" class="form-control {{ $errors->has('salaryscale') ? ' is-invalid' : '' }}" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    @foreach ($salaryscale as $eachSalaryScale)
                                                        {{-- @dd($key) --}}
                                                        @if ($eachSalaryScale->id == old('salaryscale'))
                                                            <option selected="selected" value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @else
                                                            <option value="{{ $eachSalaryScale->id }}">{{ $eachSalaryScale->salaryscale }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('salaryscale'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('salaryscale') }}</strong>
                                                        </span>
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('From Old Level/Step: ') }}</label>
                                                <input type="text" placeholder="{{ __('Old Grade Level/Step') }}" class="form-control {{ $errors->has('oldgrade') ? ' is-invalid' : '' }}" name="oldgrade" value="{{ old('oldgrade') }}" required autofocus>
                                                @if ($errors->has('oldgrade'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('oldgrade') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>{{ __('To New Level/Step: ') }}</label>
                                                <input type="text" placeholder="{{ __('New Grade Level/Step') }}" class="form-control {{ $errors->has('newgrade') ? ' is-invalid' : '' }}" name="newgrade" value="{{ old('newgrade') }}" required autofocus>
                                                @if ($errors->has('newgrade'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('newgrade') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add Promotion Salary Scale/Steps Rules</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @endisset
                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">All Salary Scale/Step Promotion Listing</h4>
                                <p class="category">Grade Level or Salary Scale and Step Promotion Settings</p>
                                @if (session('salaryscale'))
                                    <div class="alert alert-success">
                                        {{ session('salaryscale') }}
                                    </div>
                                @endif
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table id="entirestafflist" class="table table-hover table-striped">
                                    <thead>
                                        <th>Salary Scale</th>
                                        <th>From S-Scale Value/Step</th>
                                        <th>To S-Scale/Step</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        @foreach ($salaryscalestructure_with_steps as $eachSS_With_Steps)

                                        <tr>
                                            <td>{{ $eachSS_With_Steps->getSalaryScale() }}</td>
                                            <td>{{ $eachSS_With_Steps->oldgrade }}</td>
                                            <td>{{"{$eachSS_With_Steps->newgrade}"}}</td>
                                            <td>
                                                <a class="btn btn-sm btn-info" href="{{ url("salary_structure_setting/$eachSS_With_Steps->id").'/edit' }}" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="{{ url("salary_structure_setting/$eachSS_With_Steps->id") }}" >View</a>
                                                <a class="btn btn-sm btn-danger" href="{{ url("salary_structure_setting/$eachSS_With_Steps->id?action=del") }}" >Delete</a>
                                            </td>
                                        </tr>

                                        @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
@include('includes.dashboardfooter')