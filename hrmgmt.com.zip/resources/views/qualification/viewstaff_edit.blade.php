
                                    <div class="row">
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <img class="img-thumbnail" src="{{ Storage::url($thisStaff->photo) }}" width="100px" height="100px">
                                            </div>
                                        </div>
                                    </div>


                                <form id="qualification_form" method="POST" enctype="multipart/form-data" action="{{ url('staff_qualification') }}">
                                            
                                            <hr style="border: 1px solid grey;" />
                                            @csrf
                                    <input type="hidden" name="_method" value="POST" id="qualification_form_method">
                                    <input type="hidden" name="this_staff" value="{{ $thisStaff->id }}" id="this_staff">

                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend  title="#qualification" class="title">Qualification [APPROVED]</legend>
                                            <table class="table table-responsive tab-content">
                                                <thead>
                                                    <tr>
                                                        <td>ID</td>
                                                        <td>Q-TYPE</td>
                                                        <td>QUALIFICATION-TITLE</td>
                                                        <td>QUALIFICATION-DESCRIPTION</td>
                                                        <td>REGISTERED PROFESSIONAL BODY</td>
                                                        <td>STATUS</td>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                       <td>ID</td>
                                                       <td>Q-TYPE</td>
                                                       <td>QUALIFICATION-TITLE</td>
                                                       <td>QUALIFICATION-DESCRIPTION</td>
                                                       <td>REGISTERED PROFESSIONAL BODY</td>
                                                       <td>STATUS</td>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    @php($countSN = 1)
                                                    @foreach($staffExtras as $eachStaffExtra)

                                                        @if ($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS )
                                                        <tr>
                                                            <td>{{ $countSN++ }}</td>
                                                            <td>{{ $eachStaffExtra->qualificationtype }}</td>
                                                            <td>{{ $eachStaffExtra->title }}</td>
                                                            <td>{{ $eachStaffExtra->description }}</td>
                                                            <td>{{ $eachStaffExtra->registeredprobody }}</td>
                                                            <td id="staffextras_td{{ $eachStaffExtra->id }}" >
                                                            @if ($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS)
                                                                <span class="label label-success">approved</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS)
                                                                <span class="label label-info">accepted</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$PROPOSED_QUALIFICATION_STATUS)
                                                                <span class="label label-warning">proposed</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$REJECTED_QUALIFICATION_STATUS)
                                                                <span class="label label-danger">rejected</span>
                                                            @endif
                                                            </td>
        
                                                        </tr>
                                                        @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                            <hr style="border: 1px solid grey;" />
                                        </fieldset>
                                    </div>
                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend  title="#qualification" class="title">Qualification [YET TO BE APPROVED]</legend>
                                            <table class="table table-responsive tab-content">
                                                <thead>
                                                    <tr>
                                                        <td>ID</td>
                                                        <td>Q-TYPE</td>
                                                        <td>QUALIFICATION-TITLE</td>
                                                        <td>QUALIFICATION-DESCRIPTION</td>
                                                        <td>REGISTERED PROFESSIONAL BODY</td>
                                                        <td>STATUS</td>
                                                        <td>ACTION</td>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                       <td>ID</td>
                                                       <td>Q-TYPE</td>
                                                       <td>QUALIFICATION-TITLE</td>
                                                       <td>QUALIFICATION-DESCRIPTION</td>
                                                       <td>REGISTERED PROFESSIONAL BODY</td>
                                                       <td>STATUS</td>
                                                       <td>ACTION</td>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    @php($countSN = 1)
                                                    @foreach($staffExtras as $eachStaffExtra)
                                                        @if ($eachStaffExtra->status != \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS )
                                                        <tr>
                                                            <td>{{ $countSN++ }}</td>
                                                            <td>{{ $eachStaffExtra->qualificationtype }}</td>
                                                            <td>{{ $eachStaffExtra->title }}</td>
                                                            <td>{{ $eachStaffExtra->description }}</td>
                                                            <td>{{ $eachStaffExtra->registeredprobody }}</td>
                                                            <td id="staffextras_td{{ $eachStaffExtra->id }}" >
                                                            @if ($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS)
                                                                <span class="label label-success">approved</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS)
                                                                <span class="label label-info">accepted</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$PROPOSED_QUALIFICATION_STATUS)
                                                                <span class="label label-warning">proposed</span>
                                                            @elseif($eachStaffExtra->status == \App\StaffExtras::$REJECTED_QUALIFICATION_STATUS)
                                                                <span class="label label-danger">rejected</span>
                                                            @endif
                                                            </td>
        
                                                            <td>
                                                                @if ($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS)
                                                                <span class="label label-success">Already Approved</span>
                                                                @elseif ($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS)
                                                                <span class="label label-info">Accepted Awaiting Approval</span>
                                                                @else
                                                                    <button extras_id="{{ $eachStaffExtra->id }}" extras_act="modify" class="btn btn-xs btn-warning btn-outline-warning" type="button">MODIFY</button>
                                                                @endif
                                                            </td>
                                                        </tr>
                                                        @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                            <hr style="border: 1px solid grey;" />
                                            <div id="qualification_new_div" class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select id="qualificationtype" name="qualificationtype" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option  value="OND">OND</option>
                                                            <option  value="HND">HND</option>
                                                            <option  value="DEG">Degree</option>
                                                            <option  value="PGD">PGD</option>
                                                            <option  value="MSC">MSC</option>
                                                            <option  value="PHD">PHD</option>
                                                            <option  value="OTHERS">Others</option>
                                                        </select>
                                                        @if ($errors->has('qualificationtype'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtype') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input id="qualificationtitle" name="qualificationtitle" type="text" class="form-control" placeholder="Qualification Title" value="{{ old('qualificationtitle') }}"  required="required" >
                                                        @if ($errors->has('qualificationtitle'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtitle') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input id="qualificationdesc" name="qualificationdesc" type="text" class="form-control" placeholder="Qualification Description" value="{{ old('qualificationdesc') }}"  required="required" >
                                                        @if ($errors->has('qualificationdesc'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationdesc') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea id="registeredprobody" required="required" name="registeredprobody" class="form-control" placeholder="Registered Professional Body" >{{ old('registeredprobody') }}</textarea>
                                                        @if ($errors->has('registeredprobody'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('registeredprobody') }}</strong>
                                                                </span>
                                                        @endif

                                                        <input type="hidden" name="qualificationcount" value="1" >
                                                    </div>
                                                </div>

                                            </div>
                                        </fieldset>
                                    </div>

                                    <button id="qualification_submit_btn" type="submit" class="btn btn-success btn-fill pull-right">Submit New Qualification</button>
                                    <div class="clearfix"></div>
                                </form>

                                <div id="conpcass" class="form-group hidden">
                                                <label id="con_label">{{ __('CONPCASS') }}</label>
                                                <select id="con___AS_select" class="form-control {{ $errors->has('con___') ? ' is-invalid' : '' }} " name="con___" required>

                                                    @for ($i = 1; $i < 10; $i++)
                                                        <option {{old('con___')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>
                                                @if ($errors->has('con___'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('con___') }}</strong>
                                                        </span>
                                                @endif
                                </div>
                                <div id="contediss" class="form-group hidden">
                                                <label id="con_label">{{ __('CONTEDISS') }}</label>
                                                <select id="con___NA_select" class="form-control {{ $errors->has('con___') ? ' is-invalid' : '' }} " name="con___" required>

                                                    @for ($i = 1; $i < 16; $i++)
                                                        <option {{old('con___')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>
                                                @if ($errors->has('con___'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('con___') }}</strong>
                                                        </span>
                                                @endif
                                 </div>

                                 <div id="qualificationformcontrols" class="qualificationformcontrols hidden">
                                    <div class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select name="qualificationtype[]" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option value="OND">OND</option>
                                                            <option value="HND">HND</option>
                                                            <option value="DEG">Degree</option>
                                                            <option value="PGD">PGD</option>
                                                            <option value="MSC">MSC</option>
                                                            <option value="PHD">PHD</option>
                                                            <option value="OTHERS">Others</option>
                                                        </select>
                                                        @if ($errors->has('qualificationtype[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtype[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input required="required" name="qualificationtitle[]" type="text" class="form-control" placeholder="Qualification Title" value="{{ old('qualificationtitle[]') }}">
                                                        @if ($errors->has('qualificationtitle[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtitle[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input required="required" name="qualificationdesc[]" type="text" class="form-control" placeholder="Qualification Description" value="{{ old('qualificationdesc[]') }}"  required="required" >
                                                        @if ($errors->has('qualificationdesc[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationdesc[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea required="required" name="registeredprobody[]" class="form-control" placeholder="Registered Professional Body" >{{ old('registeredprobody[]', "NONE") }}</textarea>
                                                        @if ($errors->has('registeredprobody[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('registeredprobody[]') }}</strong>
                                                                </span>
                                                        @endif

                                                        <input type="hidden" name="qualificationcount[]" value="1" >
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <button onclick="this.parentNode.parentNode.remove()" type="button" class="btn-sm btn-danger pull-right btn removebtn">Remove</button>
                                                </div>
                                                <div class="col-md-12" style="padding-top: 1px; padding-left: 1px;">
                                                <hr style="border: 1px solid grey;">
                                                </div>
                                            </div>
                                 </div>