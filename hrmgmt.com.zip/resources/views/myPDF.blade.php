<!DOCTYPE html>
<html>
<head>
    <title>Hi</title>
</head>
<body>
    
@php
    $count = count($staffs);
    $count_st = 0;
@endphp
@foreach ($staffs as $eachStaff)

@php

    $salaryscale = $eachStaff->getDetails()['salary_scale'];
    $salaryscalevalue = $eachStaff->getDetails()['salary_scale_value'];
    $step = $eachStaff->getDetails()['step'];
    $promotiondate = $eachStaff->getPromotion()->promotion_date;

    $count_st++;

@endphp
    
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

    <table>
        <tbody style="width:100%; border: 0px" >
            <tr>
                {{-- <td>FPTB/CA/SS/PF.14</td> --}}
                <td>FPTB/CA/{{ $eachStaff->staffno }}</td>
                <td></td>
                <td>{{ $todays_date }}</td>
            </tr>
            <tr>
                <td><br>
                    <p>
                        {{ $eachStaff->getFullName() }} <br>
                        Ufs: HOD, {{ $eachStaff->getDepartmentUnit() }}, <br>
                        Federal Polytechnic,<br>
                        Bauchi. <br><br>
                    </p>
                </td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>
                    <b><u>PROMOTION</u></b>
                </td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="3">
                    <p align="justify">
                        I am happy to inform you that the Governing Council at its {{ $council_count }} Regular Meeting has approved the recommendations of the Expanded Management Committee for your promotion in recognition of your hard work and dedication to duties. <br><br>

                        It is my pleasure and priviledge  inform you that you have been promoted to the rank of <b><u>{{ $eachStaff->getDetails()['rank'] }}</u></b> on {{ $salaryscale }} <b><u>{{ $salaryscalevalue }}</u></b> step <b><u>{{  $step }}</u></b> with effect from {{ $promotiondate }}. Your next increment will be with effect from {{ $promotiondate }}. <br><br>

                        It is hoped that you will justify our promotion by increased productivity and total devotion to duties. <br>
                        Accept my congratulations. <br> <br><br>


                        <br>
                        
                        @php
                            $full_path = Storage::disk('public')->path('_______signsample.png');
                        @endphp

                        <img src="{{$full_path}}" width="100px" height="100px" /> <br>
                        <b>{{ $registrar }}</b><br>
                        <b><tt>REGISTRAR</tt></b>
                        <br>
                        <br>
                        <b>CC: Bursar</b><br>
                        <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Chief Internal Auditor</b>
                    </p>
                </td>
                {{-- <td></td> --}}
            </tr>
        </tbody>
    </table>

    @if ($count_st < $count)
        <p style="page-break-before: always;"></p>
    @endif

    @endforeach
   
</body>
</html>