@php
    $current_page = 'leave';
@endphp

@include('includes.dashboardheader')

        <div class="row">
                    <div class="col-md-10">
                        <div class="card">

                            <div class="header">
                                @if(is_null($staff) || is_null($status))
                                    <h4 class="title">Give Staff A Leave</h4>
                                @else
                                    <h4 class="title">Give Staff <b>{{"$staff->fname $staff->lname $staff->oname"}}</b> A {{"$status->status"}}</h4>
                                @endif
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ route('leave.store') }}" method="POST">
                                    @csrf

                                    <div class="row">
                                        @if(!is_null($staff) && !is_null($status))
                                            <input type="hidden" name="staff_id" class="btn btn-primary|secondary|success|danger|warning|info|light|dark|link" type="button" value="{{$staff->id}}">
                                            <input type="hidden" name="status_id" class="btn btn-primary|secondary|success|danger|warning|info|light|dark|link" type="button" value="{{$status->id}}">
                                        @endif

                                        <div class="col-md-1">
                                            <label>
                                            <input required name="daterangetype" id="" class="radio input-radio" type="radio" value="{{\App\Leave::RANGE_ONE}}">None-Range Date:
                                        </label>
                                        </div>
                                          <div class="col-md-2">
                                            <div class="form-group">
                                                @if(!is_null($status))
                                                <label>{{ __("$status->status" . ' On') }}</label>
                                                @else
                                                <label>{{ __('On') }}</label>
                                                @endif
                                                <input id="leavefrom_date"  type="date" class="form-control" placeholder="{{ __('leaveon') }}" class="form-control {{ $errors->has('leaveon') ? ' is-invalid' : '' }}" name="leaveon" value="{{ old('leaveon') }}"  autofocus>

                                                @if ($errors->has('leaveon'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('leaveon') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        @php($staff_no = $staff? $staff->staffno : '')

                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>{{ __('Staff No') }}</label>
                                                <input disabled type="text" class="form-control" placeholder="{{ __('staffno') }}" class="form-control {{ $errors->has('staffno') ? ' is-invalid' : '' }}" name="staffno" value="{{ old('staffno', $staff_no) }}"  autofocus>
                                                @if ($errors->has('staffno'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('staffno') }}</strong>
                                                        </span>
                                                @endif

                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        @if(!is_null($staff) && !is_null($status))
                                            <input type="hidden" name="staff_id" class="btn btn-primary|secondary|success|danger|warning|info|light|dark|link" type="button" value="{{$staff->id}}">
                                        @endif
                                        <div class="col-md-1">
                                            <label>
                                            <input required name="daterangetype" id="" class="radio input-radio" type="radio" value="{{\App\Leave::RANGE_TWO}}">Range Date:
                                        </label>
                                        </div>
                                          <div class="col-md-2">
                                            <div class="form-group">
                                                @if(!is_null($status))
                                                <label>{{ __("$status->status" . ' From') }}</label>
                                                @else
                                                <label>{{ __('From') }}</label>
                                                @endif
                                                <input id="leavefrom_date"  type="date" class="form-control" placeholder="{{ __('leavefrom') }}" class="form-control {{ $errors->has('leavefrom') ? ' is-invalid' : '' }}" name="leavefrom" value="{{ old('leavefrom') }}"  autofocus>

                                                @if ($errors->has('leavefrom'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('leavefrom') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                @if(!is_null($status))
                                                <label>{{ __("$status->status" . ' To') }}</label>
                                                @else
                                                <label>{{ __(' On') }}</label>
                                                @endif
                                                <input id="leaveto_date" type="date" class="form-control" placeholder="{{ __('leaveto') }}" class="form-control {{ $errors->has('leaveto') ? ' is-invalid' : '' }}" name="leaveto" value="{{ old('leaveto') }}"  autofocus>

                                                @if ($errors->has('leaveto'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('leaveto') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        @php($staff_no = $staff? $staff->staffno : '')

                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>{{ __('Staff No') }}</label>
                                                <input disabled type="text" class="form-control" placeholder="{{ __('staffno') }}" class="form-control {{ $errors->has('staffno') ? ' is-invalid' : '' }}" name="staffno" value="{{ old('staffno', $staff_no) }}"  autofocus>
                                                @if ($errors->has('staffno'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('staffno') }}</strong>
                                                        </span>
                                                @endif

                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                @if(!is_null($status))
                                                <label>{{"$status->status"}} Comment/Description</label>
                                                @else
                                                <label>{{ 'Comment/Description' }}</label>
                                                @endif
                                                <textarea required name="statusdescription" type="text" class="form-control" placeholder="{{ !is_null($status)? $status->status : '' }} Description">{{ old('statusdescription') }}</textarea>
                                                @if ($errors->has('statusdescription'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('statusdescription') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <hr>
                                    @if(is_null($staff) || is_null($status))
                                    <button id="btnsubmit" disabled="" type="submit" class="btn btn-info btn-fill pull-right">Give This Staff Leave</button>
                                    @else
                                    <button id="btnsubmit"  type="submit" class="btn btn-info btn-fill pull-right">Change This Staff {{"$status->status"}}</button>
                                    @endif
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-10 container-fluid">
                        <h5>Two Date Range Leave List</h5>
                        <table id="staff_leave_table" class="table table-condensed table-responsive">
                            <thead>
                                <tr>
                                    <th>S/N</th>
                                    <th>STAFF NAME</th>
                                    <th>STAFF REGNO</th>
                                    <th>FROM DATE</th>
                                    <th>TO DATE</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php($count = 1)
                                @foreach ($allLeave as $eachLeave)
                                    <tr>
                                        <td scope="row">{{$count++}}</td>
                                        <td> {{ \App\Staff::find($eachLeave->staff_id)->getFullName() }} </td>
                                        <td>{{\App\Staff::find($eachLeave->staff_id)->staffno}}</td>
                                        <td>{{(new DateTime($eachLeave->from))->format('d M Y')}}</td>
                                        <td>{{(new DateTime($eachLeave->to))->format('d M Y')}}</td>
                                        <td>{{$eachLeave->description}}</td>
                                        <td>{!! $eachLeave->status == \App\Leave::ACTIVE ? "<span class='label label-success'>ACTIVELY ON LEAVE</span>" : "<span class='label label-danger'>BACK FROM LEAVE</span>" !!}</td>
                                        <td></td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>

                </div>
@include('includes.dashboardfooter')
