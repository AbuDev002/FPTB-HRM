@php
    $current_page = 'viewstaff';

    if(empty($displayType))
        $displayType = "all";

@endphp

@include('includes.dashboardheader')

        <div class="row">
            @if($displayType == "show")
                <div class="col-md-10">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">View Staff Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                @include('staff.viewstaff_show')
                            </div>
                        </div>
                    </div>
            @elseif( $displayType == "edit" )
                <div class="col-md-10">
                        <div class="card">
                            @if($show_dc_print)
                            <div class="header">
                                <h4 class="title">DECEASED STAFF</h4>
                                <p class="category"></p>
                            </div>
                            @else
                            <fieldset class="container"> <legend>Quick Find: </legend>
                                <form enctype="multipart/form-data" action="{{ route('quick.find') }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-2 col-sm-2" style="border-right: 1px solid #333"  >
                                            <div class="form-group">
                                                <label>{{ __('Staff Number Search') }}</label>
                                                <input id="staffno_quick_find" type="text" class="form-control" placeholder="{{ __('Staff No Search') }}" class="form-control {{ $errors->has('staffno') ? ' is-invalid' : '' }}" name="staffno" value="{{ old('staffno') }}"  autofocus>
                                                @if ($errors->has('staffno'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('staffno') }}</strong>
                                                        </span>
                                                @endif

                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label>{{ __('Full-Name') }}</label>
                                                <input id="full_name_quick_search" type="text" placeholder="{{ __('Enter Staff Name') }}" class="form-control {{ $errors->has('fullname') ? ' is-invalid' : '' }}" name="fullname" value="{{ old('fullname') }}" required autofocus>
                                                @if ($errors->has('fullname'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('fullname') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <label>{{ __('Search Action') }}</label>
                                            <button id="btn_names_quick_search" type="button" class="btn btn-success">Search By Names</button>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3 col-sm-3">
                                             <div style="display: none;" class="imgloaderindicator"></div> 
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div id="staff_listing_quick_search" class="hide col-md-12 col-sm-12">
                                            <div class="form-group" id="quick_find_table_div">
                                                <table class="table table-bordered table-condensed table-hover table-striped" >
                                                    <thead>
                                                        <tr>
                                                            <th>Staff Name</th>
                                                            <th>Status</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </fieldset>
                            <div class="header">
                                <h4 class="title">Update Staff Information</h4>
                                <p class="category"></p>
                            </div>
                            @endif
                            <div class="content">
                                @include('staff.viewstaff_edit', ['some' => 'data'])
                            </div>
                        </div>
                    </div>
            @elseif( $displayType == "all" )
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">List Of Staffs</h4>
                                <p class="category">This is the list of Staff</p>
                                <p>
                                    @if(in_array('photo',$hide_columns) || in_array('action', $hide_columns) )
                                        <button src-link-attr="{{url('staff')}}/?hide1=action&hide2=photo" id="btn_select_staff" class="btn-small btn-fill btn btn-danger">Hide/Show Action & Photo Columns</button>
                                    @else
                                        <button src-link-attr="{{url('staff')}}" id="btn_select_staff" class="btn-small btn btn-danger">Hide/Show Action & Photo Columns</button>
                                    @endif

                                    @php
                                        /*  var_dump($hide_columns);
                                            var_dump(in_array('action',$hide_columns));
                                        */
                                    @endphp
                                </p>
                                @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                @endif
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table id="entirestafflist" class="table table-bordered table-condensed table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Staff No</th>
                                            <th>Staff Name</th>
                                            @if(!in_array('photo',$hide_columns))
                                                <th>Staff photo</th>
                                            @endif
                                            <th>Gender</th>
                                            <th>Department</th>
                                            <th>Unit</th>
                                            <th>Salary Scale</th>
                                            <td>LEVEL</td>
                                            <td>STEP</td>
                                            <th>Rank</th>
                                            <th>Category</th>
                                            <th>Position</th>
                                            <th>Added Resp.</th>
                                            <th>StaffClass</th>
                                            <th>DateOfBirth</th>
                                            <th>Address</th>
                                            <th>Status</th>
                                            @if(!in_array('action',$hide_columns))
                                                <th>Action</th>
                                            @endif
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Staff No</th>
                                            <th>Staff Name</th>
                                            @if(!in_array('photo',$hide_columns))
                                                <th>Staff photo</th>
                                            @endif
                                            <th>Gender</th>
                                            <th>Department</th>
                                            <th>Unit</th>
                                            <th>Salary Scale</th>
                                            <td>LEVEL</td>
                                            <td>STEP</td>
                                            <th>Rank</th>
                                            <th>Category</th>
                                            <th>Position</th>
                                            <th>Added Resp.</th>
                                            <th>StaffClass</th>
                                            <th>DateOfBirth</th>
                                            <th>Address</th>
                                            <th>Status</th>
                                            @if(!in_array('action',$hide_columns))
                                                <th>Action</th>
                                            @endif
                                        </tr>
                                    </tfoot>
                                    <tbody>

                                        @php
                                            $count_c = 1;
                                        @endphp

                                        @foreach ($staff as $eachStaff)

                                        @php
                                            $department = \App\Department::find(\App\StaffDepartment::where(['staff_id'=>$eachStaff->id])->first()['dept_id'])['description'];
                                            $department = $eachStaff->getDepartment();
                                            $departmentunit = $eachStaff->getDepartmentUnit();
                                            $currentPromotion = \App\Promotions::where('status', \App\Promotions::$APPROVED_PROMOTION)
                                                ->where('promotion_indicator', \App\Promotions::$CURRENT_PROMOTION)->where('staff_id', $eachStaff->id)->get()->first();

                                            $rank = \App\Rank::find($currentPromotion->rank);
                                            $status = \App\Status::find($currentPromotion->staff_status)->status;

                                        @endphp

                                        <tr>
                                            <td>{{ $count_c++ }}</td>
                                            <td>{{$eachStaff->staffno}}</td>
                                            <td>{{"{$eachStaff->fname} {$eachStaff->lname} {$eachStaff->oname}"}}</td>
                                            @if(!in_array('photo',$hide_columns))
                                                <td><img class="img" width="100px" height="100px" src="{{\Storage::url("{$eachStaff->photo}")}}"  /> </td>
                                            @endif
                                            <td>{{ $eachStaff->gender }}</td>
                                            <td>{{ $department }}</td>
                                            <td>{{ $departmentunit }}</td>
                                            <td>{{ $currentPromotion->getSalaryScale() }}</td>
                                            <td>{{ $currentPromotion->salary_scale_value }}</td>
                                            <td>{{ $currentPromotion->step }}</td>
                                            <td>{{ $rank->rank }}</td>
                                            <td>{{ $currentPromotion->category }}</td>
                                            <td>{{ $eachStaff->getDetails()['position'] }}</td>
                                            <td>
                                                @foreach ($eachStaff->getDetails()['addedresponsibilities'] as $eachRes)
                                                            {{$eachRes->position . ', '}}
                                                    @endforeach
                                            </td>
                                            <td>{{ $currentPromotion->staffclass }}</td>
                                            <td>{{"{$eachStaff->dateobirth}"}}</td>
                                            <td>{{"{$eachStaff->address1}"}}</td>
                                            <td>{{"{$status}"}}</td>

                                            @if(!in_array('action',$hide_columns))
                                                <td>

                                                    <form onsubmit="return (confirm('Are you Sure That You Want To Delete This Record? Please Confirm.?'))" action="{{ url("staff/". $eachStaff->id) }}" method="POST" >
                                                        <input type="hidden" name="_method" value="delete">
                                                        @csrf
                                                        <a class="btn btn-sm btn-primary " href="{{url('staff/'.$eachStaff->id.'')}}">View</a>
                                                        <a class="btn btn-sm btn-info " href="{{url('staff/'.$eachStaff->id.'/edit')}}">Edit</a>
                                                        <button class="btn btn-sm btn-danger" href="{{url('staff/'.$eachStaff->id.'/delete')}}">Delete</button>

                                                    </form>
                                                </td>
                                            @endif
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                    @endif
                </div>


                </div>
@include('includes.dashboardfooter')
