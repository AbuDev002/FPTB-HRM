@php
    $current_page = 'basic-info-update';

    if(empty($displayType))
        $displayType = "all";
        // $displayType = "edit";

@endphp

@include('includes.dashboardheader')

<div class="row">
    <div class="col-md-10">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">Update Your Basic Information</h4>

                                @if(\Session::get('success'))
                                    <div class="alert alert-success">{{ \Session::get('success') }}</div>
                                @endif
                                <p class="category"></p>
                            </div>
                            <div class="content">

        <form id="btn_basic_update_form" enctype="multipart/form-data" action="{{ url('basic-info-update') }}" method="POST">
                                    @csrf

                                    <input type="hidden" name="this_staff" value="{{ $thisStaff->id }}">

                                    <div class="row">
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <img class="img-thumbnail" src="{{ Storage::url($thisStaff->photo) }}" width="100px" height="100px">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Staff No (PFN)') }}</label>
                                                <span id="staffnocheckokmessage"class="hide text-success">Staff No - Available (good!)</span>
                                                <span id="staffnocheckbadmessage" class="hide text-danger">Staff No - Unavailable (try again)</span>
                                                <input readonly="readonly" id="staffnocheck_" type="text" class="form-control control" placeholder="{{ __('staffno (PFN)') }}" class="form-control {{ $errors->has('staffno') ? ' is-invalid' : '' }}" name="staffno" value="{{ old('staffno', $thisStaff->staffno) }}"  required="required" autofocus>

                                                @if ($errors->has('staffno'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('staffno') }}</strong>
                                                        </span>
                                                @endif

                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Marital Status') }}</label>
                                                <select id="maritalstatus" class="form-control {{ $errors->has('maritalstatus') ? ' is-invalid' : '' }} " name="maritalstatus" required>

                                                    <option {{old('maritalstatus', $thisStaff->maritalstatus)=="M"? 'selected="selected"' : ''}} value="M" >Married</option>
                                                    <option {{old('maritalstatus', $thisStaff->maritalstatus) =="S"? 'selected="selected"' : ''}} value="S" >Single</option>

                                                </select>
                                                @if ($errors->has('maritalstatus'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('maritalstatus') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('PhoneNo') }}</label>
                                                <input id="phoneno_input" type="text" placeholder="{{ __('PhoneNo') }}" class="form-control {{ $errors->has('phoneno') ? ' is-invalid' : '' }}" name="phoneno" value="{{ old('phoneno', $thisStaff->phoneno) }}" required  autofocus>
                                                @if ($errors->has('phoneno'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('phoneno') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Email') }}</label>
                                                <input id="email_input" type="email" placeholder="{{ __('Email') }}" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email', $thisStaff->email) }}"  autofocus>
                                                @if ($errors->has('email'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('email') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        
                                        <!-- <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('DateOfBirth') }}</label>
                                                <input id="dateobirth_input" type="date" class="form-control" placeholder="{{ __('dateobirth') }}" class="form-control {{ $errors->has('dateobirth') ? ' is-invalid' : '' }}" name="dateobirth" value="{{ old('dateobirth', $thisStaff->dateobirth) }}" required="required"  autofocus>
                                        
                                                @if ($errors->has('dateobirth'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('dateobirth') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div> -->
                                        <!-- <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('Photo') }}</label>
                                                <input id="photo_input" type="file" class="form-control" placeholder="{{ __('photo') }}" class="form-control {{ $errors->has('photo') ? ' is-invalid' : '' }}" name="photo" value="{{ old('photo') }}"  autofocus>
                                        
                                                @if ($errors->has('photo'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('photo') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div> -->

                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6 col-md-6">
                                            <div class="form-group">
                                                <label>Address 1</label>
                                                <input name="address1" type="text" class="form-control" placeholder="Address 2" value="{{ old('address1', $thisStaff->address1) }}"  required="required" >
                                                @if ($errors->has('address1'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('address1') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-sm-6 col-md-6">
                                            <div class="form-group">
                                                <label>Address 2</label>
                                                <input name="address2" type="text" class="form-control" placeholder="Address 2" value="{{ old('address2', $thisStaff->address2) }}"  required="required" >
                                                @if ($errors->has('address2'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('address2') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">

                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('GPZone') }}</label>
                                                <select id="gpzone_select" class="form-control {{ $errors->has('gpzone') ? ' is-invalid' : '' }} " name="gpzone" required>

                                                    @foreach($gpzone as $eachGPZone)
                                                        <option {{old('gpzone', $thisStaff->gpzone)==$eachGPZone->id? 'selected="selected"' : ''}} value="{{$eachGPZone->id}}">{{$eachGPZone->gpzone}}</option>
                                                    @endforeach


                                                </select>
                                                @if ($errors->has('gpzone'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('gpzone') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-sm-4 col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label>{{ __('State') }}</label>
                                                <select id="state" name="state" class="form-control" required="required">
                                                    <option value="">Select State Of Origin</option>
                                                    @foreach ($state as $eachState)

                                                    <option {{old('state', $thisStaff->state_id)==$eachState->id? 'selected="selected"' : ''}} value="{{$eachState->id}}" >{{$eachState->state}}</option>

                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-4 col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label>{{ __('Lga') }}</label>
                                                <select id="lga" name="lga" class="form-control" required="required">
                                                    <option value="">Select Local Government</option>
                                                    @foreach ($lga as $eachLga)
                                                    <option {{old('lga', $thisStaff->lga_id)==$eachLga->id? 'selected="selected"' : ''}} value="{{$eachLga->id}}" >{{$eachLga->lga}}</option>

                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                    </div>
                                    <hr>
                                    <div class="row" >
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokfname">{{ __('Next Of Kin First Name')}}</label>
                                                <input id="nokfname_input" class="form-control" placeholder="Next Of Kin First Name" type="text" name="nokfname" value="{{ $thisStaff->nok_fname }}" required="required">
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="noklname">{{ __('Next Of Kin Last Name')}}</label>
                                                <input id="noklname_input" class="form-control" placeholder="Next Of Kin Last Name" type="text" name="noklname" value="{{ $thisStaff->nok_lname }}" required="required">
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokoname">{{ __('Next Of Kin Other Name')}}</label>
                                                <input id="nokoname_input" class="form-control" placeholder="Next Of Kin Other Name" type="text" name="nokoname" value="{{ $thisStaff->nok_oname }}" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" >
                                         <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokaddress">{{ __('Next Of Kin Address')}}</label>
                                                <textarea id="nokaddress_input" class="form-control" required name="nokaddress" placeholder="Enter Next Of Kin Address" >{{ $thisStaff->nok_address }}</textarea>
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokphoneno">{{ __('Next Of Kin Phone No')}}</label>
                                                <input id="nokphoneno_input" type="text" class="form-control" required="required" name="nokphoneno" value="{{ $thisStaff->nok_phoneno }}" placeholder="Enter Next Of Kin PhoneNo" />
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokrelationship">{{ __('Relationship With Next Of Kin')}}</label>
                                                <input id="nok_relationship_input" type="text" class="form-control" required="required" name="nokrelationship" value="{{ $thisStaff->nok_relationship }}" placeholder="Enter Next Of Kin Relationship">
                                                </textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div id="childsection1_div" class="row" style="border-bottom: 2px solid #eee" >
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nameofchild1">{{ __('Child\'s Name  (If Any)')}}</label>
                                                <input id="nameofchild1_input" type="text" name="nameofchild1" placeholder="Name of Child (If Any)" class="form-control" value="{{old('nameofchild1', $thisStaff->child1_name )}}" >
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2" style="border-right: 2px solid #eee">
                                            <div class="form-group">
                                                <label for="ageofchild1">{{ __('Child\'s Age')}}</label>
                                                <input id="ageofchild1_input" type="number" name="ageofchild1" placeholder="Age of Child" class="form-control"  value="{{old('ageofchild1', $thisStaff->child1_age )}}" >
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nameofchild2">{{ __('Child\'s Name  (If Any)')}}</label>
                                                <input id="nameofchild2_input" type="text" name="nameofchild2" placeholder="Name of Child (If Any)" class="form-control"  value="{{old('ageofchild2', $thisStaff->child2_name )}}" >
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2">
                                            <div class="form-group">
                                                <label for="ageofchild2">{{ __('Child\'s Age')}}</label>
                                                <input id="ageofchild2_input" type="number" name="ageofchild2" placeholder="Age of Child" class="form-control"  value="{{old('ageofchild3', $thisStaff->child2_age)}}" >
                                            </div>
                                        </div>

                                    </div>
                                    <div id="childsection2_div" class="row">
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group bor">
                                                <label for="nameofchild3">{{ __('Child\'s Name  (If Any)')}}</label>
                                                <input id="nameofchild3_input" type="text" name="nameofchild3" placeholder="Name of Child (If Any)" class="form-control"  value="{{old('nameofchild3', $thisStaff->child3_name)}}" >
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2" style="border-right: 2px solid #eee">
                                            <div class="form-group">
                                                <label for="ageofchild3">{{ __('Child\'s Age')}}</label>
                                                <input id="ageofchild3_input" type="number" name="ageofchild3" placeholder="Age of Child" class="form-control"  value="{{old('ageofchild3', $thisStaff->child3_age)}}" >
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nameofchild4">{{ __('Child\'s Name  (If Any)')}}</label>
                                                <input id="nameofchild4_input" type="text" name="nameofchild4" placeholder="Name of Child (If Any)" class="form-control"  value="{{old('nameofchild4', $thisStaff->child4_name)}}" >
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2">
                                            <div class="form-group">
                                                <label for="ageofchild4">{{ __('Child\'s Age')}}</label>
                                                <input id="ageofchild4_input" type="number" name="ageofchild4" placeholder="Age of Child" class="form-control"  value="{{old('ageofchild4', $thisStaff->child4_age)}}" >
                                            </div>
                                        </div>

                                    </div>

                                    <button id="staff_basic_update_btn" type="submit" disabled="disabled" class="btn btn-success btn-fill pull-right">Update My Basic Information</button>
                                    <div class="clearfix"></div>

                                </form>

                                <hr>
                               
    </div>
        </div>
        </div>

@include('includes.dashboardfooter')