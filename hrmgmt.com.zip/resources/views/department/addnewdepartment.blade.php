@php
    $current_page = 'department';
@endphp

@include('includes.dashboardheader')

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                        
                        @isset($displaystate)
                            @if ($displaystate == 'edit')
                            <div class="header">
                                <h4 class="title">Update Department Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ url('department/'.$department->id )}}" method="POST">

                                    @method('PUT')
                                    @csrf

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Department') }}</label>
                                                <input type="text" placeholder="{{ __('Department') }}" class="form-control {{ $errors->has('department') ? ' is-invalid' : '' }}" name="department" value="{{ old('department', $department->department) }}" required autofocus>
                                                @if ($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                                    {{-- @dd($school) --}}
                                                    {{-- @dd($department->school) --}}
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('School') }}</label>
                                                <select type="text" placeholder="{{ __('Select School') }}" class="form-control {{ $errors->has('school') ? ' is-invalid' : '' }}" name="school" required autofocus>
                                                    <option value="">Select School</option>

                                                    @foreach ($school as $key => $eachSchool)
                                                        {{-- @dd($key) --}}
                                                        @if ($key == $department->school)
                                                            <option selected="selected" value="{{ $key }}">{{ $eachSchool }}</option>
                                                        @else
                                                            <option value="{{ $key }}">{{ $eachSchool }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('school'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('school') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Description') }}</label>
                                                <input type="text" placeholder="{{ __('description') }}" class="form-control {{ $errors->has('description') ? ' is-invalid' : '' }}" name="description" value="{{ old('description', $department->description ) }}" autofocus>
                                                @if ($errors->has('description'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('description') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="{{ url("department/create")}}" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Department Information</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @elseif($displaystate == 'delete')
                                <div class="header">
                                <h4 class="title text-danger">Delete Department Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ url('department/'.$department->id )}}" method="POST">

                                    @method('DELETE')
                                    @csrf

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Department?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Department') }}</label>
                                                <input disabled="disabled" type="text" placeholder="{{ __('Department') }}" class="form-control {{ $errors->has('department') ? ' is-invalid' : '' }}" name="department" value="{{ old('department', $department->department) }}" required autofocus>
                                                @if($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Department Description') }}</label>
                                                <input disabled="disabled" type="text" placeholder="{{ __('department') }}" class="form-control {{ $errors->has('department') ? ' is-invalid' : '' }}" name="department" value="{{ old('department', $department->description ) }}" autofocus>
                                                @if ($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="{{ url("department/create")}}" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE department</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @else
                                {{-- Only Display the Information --}}
                                <div class="header">
                                <h4 class="title">View Department Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" >


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Department') }}</label>
                                                <input readonly="readonly" type="text" placeholder="{{ __('Department') }}" class="form-control {{ $errors->has('department') ? ' is-invalid' : '' }}" name="department" value="{{ old('department', $department->department) }}" required autofocus>
                                                @if ($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('School') }}</label>
                                                
                                                    @foreach ($school as $key => $eachSchool)

                                                        @if ($key == $department->school)
                                                            <input readonly="readonly" type="text" placeholder="{{ __('School') }}" class="form-control" name="school" value="{{ $eachSchool }}" required autofocus>
                                                        @break
                                                            <option value="{{ $key }}">{{ $eachSchool }}</option>
                                                        @endif

                                                    @endforeach
                                                
                                                @if ($errors->has('school'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('school') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Description') }}</label>
                                                <input readonly="readonly" type="text" placeholder="{{ __('description') }}" class="form-control {{ $errors->has('description') ? ' is-invalid' : '' }}" name="description" value="{{ old('description', $department->description ) }}" autofocus>
                                                @if ($errors->has('description'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('description') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <a href="{{ url("department/create") }}" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="{{ url("department/{$department->id}").'/edit' }}" class="btn btn-info btn-fill pull-right">Edit Department Information</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @endif
                        @else
                            
                            <div class="header">
                                <h4 class="title">Add New Department</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ route('department.store') }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Department') }}</label>
                                                <input type="text" placeholder="{{ __('Department') }}" class="form-control {{ $errors->has('department') ? ' is-invalid' : '' }}" name="department" value="{{ old('department') }}" required autofocus>
                                                @if ($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('School') }}</label>
                                                <select type="text" placeholder="{{ __('Select School') }}" class="form-control {{ $errors->has('school') ? ' is-invalid' : '' }}" name="school" required autofocus>
                                                    <option value="">Select School</option>
                                                    @foreach ($school as $key => $eachSchool)

                                                        @if ($key == old('school'))
                                                            <option selected="selected" value="{{ $key }}">{{ $eachSchool }}</option>
                                                        @else
                                                            <option value="{{ $key }}">{{ $eachSchool }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('school'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('school') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Description') }}</label>
                                                <input type="text" placeholder="{{ __('description') }}" class="form-control {{ $errors->has('description') ? ' is-invalid' : '' }}" name="description" value="{{ old('description') }}" autofocus>
                                                @if ($errors->has('description'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('description') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add New Department</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        @endisset
                        </div>
                        <div> 
                            @php 
                                $totalDeptCount = \App\Department::where('is_currently_active', 1)->count();

                            @endphp

                            TOTAL DEPARTMENT IS: {{ $totalDeptCount }}

                            <script type="text/javascript">
                              document.title = "DEPARTMENT LISTING::TOTAL DEPARTMENT {{ $totalDeptCount }}";
                            </script>

                            <table id="stafftobepromoted" class="table table-bordered table-condensed">
                                <thead>
                                    <tr>
                                        <td>Dept Code</td>
                                        <td>Department</td>
                                        <td>School</td>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <td>Dept Code</td>
                                        <td>Department</td>
                                        <td>School</td>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    @php
                                        $allDepts = \App\Department::where('is_currently_active', 1)->get()->all();
                                    @endphp

                                    @foreach ($allDepts as $eachDept)
                                        
                                    <tr>
                                        <td>{{ $eachDept->department }}</td>
                                        <td>{{ $eachDept->description }}</td>
                                        <td>{{ $eachDept->getSchool() }}</td>
                                    </tr>

                                    @endforeach

                                </tbody>
                            </table>

                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Department Available</h4>
                                <p class="category">This is the list of All Department Available</p>
                                @if (session('status'))
                                    <div class="alert alert-success">
                                        {{ session('status') }}
                                    </div>
                                @endif
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table id="stafftobepromotedlist" class="table table-hover table-striped">
                                    <thead>
                                        <th>Department</th>
                                        <th>School</th>
                                        <th style="width: 25%" >Description</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        @php

                                            if(!is_array($department) && !($department instanceof Countable)){
                                                $department = array($department);
                                            }

                                        @endphp

                                        @foreach ($department as $eachDeparment)
                                        <tr>
                                            <td>{{ $eachDeparment->department }}</td>
                                            <td>{{ $school[$eachDeparment->school] }}</td>
                                            <td>{{ $eachDeparment->description }}</td>
                                            <td>
                                                <a class="btn btn-sm btn-info" href="{{ url("department/$eachDeparment->id").'/edit' }}" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="{{ url("department/$eachDeparment->id") }}" >View</a>
                                                <a class="btn btn-sm btn-danger" href="{{ url("department/$eachDeparment->id?action=del") }}" >Delete</a>
                                            </td>
                                        </tr>

                                        @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
@include('includes.dashboardfooter')