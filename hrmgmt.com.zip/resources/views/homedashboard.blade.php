@php
    $current_page = 'dashboard';
    $page_title = "Dashboard";
@endphp

@include('includes.dashboardheader')

        @if (Auth::user()->access_level == \App\Staff::$USER_ADMIN)

            <div class="row">
                <div class="col-md-12">
                    <h5>Last Login: {{ Auth::user()->lastLogin() }}</h5>
                </div>
            </div>
            <div class="row">
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Active Staff</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h1>
                                    {{\App\SummaryReport::getStaffCount('active')}}
                                </h1>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Staff On Leave</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h3>
                                    Sabbatical: {{\App\SummaryReport::getStaffCount('sabbatical')}}
                                </h3>
                                <h3>
                                    Study: {{\App\SummaryReport::getStaffCount('study leave')}}
                                </h3>
                                <h3>
                                    Leave Of Absence: {{\App\SummaryReport::getStaffCount('leave of absence')}}
                                </h3>

                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Department</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    {{\App\Department::where('is_currently_active', 1)->count()}}
                                </h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">School</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    {{\App\School::count()}}
                                </h1>
                            </div>
                        </div>
                    </div>

                </div>
            <div class="row">
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Staff On Holiday</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                {{--<h1>--}}
                                    {{--{{\App\Staff::where('status', '<>', \App\Status::where('status', 'active')->get()->first()->id)->get()->count()}}--}}
                                {{--</h1>--}}
                                <h3>
                                    Suspension Pay: {{\App\SummaryReport::getStaffCount('suspension with pay')}}
                                </h3>
                                <h3>
                                    Suspension No-Pay: {{\App\SummaryReport::getStaffCount('suspension without pay')}}
                                </h3>
                                <h3>
                                    Annual Leave: {{\App\SummaryReport::getStaffCount('annual leave')}}
                                </h3>
                                <h3>
                                    Maternity Leave: {{\App\SummaryReport::getStaffCount('maternity leave')}}
                                </h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Out Of Service</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h3>
                                    Dismisal: {{\App\SummaryReport::getStaffCount('dismissal')}}
                                </h3>
                                <h3>
                                    Withdrawal: {{\App\SummaryReport::getStaffCount('withdrawal')}}
                                </h3>
                                <h3>
                                    Transfer: {{\App\SummaryReport::getStaffCount('transfer')}}
                                </h3>
                                <h3>
                                    Retire: {{\App\SummaryReport::getStaffCount('retire')}}
                                </h3>
                                <h3>
                                    Termination: {{\App\SummaryReport::getStaffCount('termination')}}
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Deceased</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    {{\App\SummaryReport::getStaffCount('deceased')}}
                                </h1>
                            </div>
                        </div>
                    </div>

                <div class="col-md-3">
                    <div class="card">

                        <div class="header">
                            <h4 class="title text-center">Promotion Notification</h4>
                            <p class="category"></p>
                        </div>
                        <div class="content text-info  text-center">
                            <h1>
                                {{\App\SummaryReport::getPromotionNotification()}}
                            </h1>
                            <p>
                                <a class="btn btn-success" href="{{url('promotionlist')}}">View</a>
                            </p>
                        </div>
                    </div>
                </div>



            </div>

                <div class="row">

                    <div class="col-md-12">
                        <table id="usersonline_table" class="table table-bordered table-condensed">
                                                            <thead>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    <td>Name</td>
                                                                    <td>User-Status</td>
                                                                    <td>Level</td>
                                                                    <td>Status</td>
                                                                    <td>Last Seen</td>
                                                                    <td>Action</td>
                                                                </tr>
                                                            </thead>
                                                            <tfoot>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    <td>Name</td>
                                                                    <td>User-Status</td>
                                                                    <td>Level</td>
                                                                    <td>Status</td>
                                                                    <td>Last Seen</td>
                                                                    <td>Action</td>
                                                                </tr>
                                                            </tfoot>
                                                            <tbody id="usersonline_table_body">
                                                                @php
                                                                    $count_id = 1;
                                                                @endphp

                                                                @foreach($sessionlast as $thisSession)

                                                                    @php
                                                                        $thisVeryUser = \App\User::find($thisSession->user_id);
                                                                        $cT = \Carbon\Carbon::createFromTimestamp($thisSession->last_activity);
                                                                        $diff_in_minutes = $cT->diffInMinutes(\Carbon\Carbon::now());
                                                                    @endphp
                                                                @if($diff_in_minutes <= 10)
                                                                <tr>
                                                                    <td>{{ $count_id++ }}</td>
                                                                    <td>{{ $thisVeryUser->username }}</td>
                                                                    <td>{{ $thisVeryUser->name }}</td>
                                                                    @if($thisVeryUser->status == \App\User::$USER_ACCOUNT_STATUS_ENABLED)
                                                                    <td><span class="label label-success">Enabled Account</span></td>
                                                                    @else
                                                                    <td><span class="label label-danger">Disabled Account</span></td>
                                                                    @endif
                                                                    <td>{{ ($thisVeryUser->access_level == \App\Staff::$USER_ADMIN) ? "ADMIN" : ( ($thisVeryUser->access_level == \App\Staff::$USER_SUBADMIN) ? "SUB-ADMIN" : ($thisVeryUser->access_level == \App\Staff::$USER_STAFF ? "STAFF" : "STAFF")) }}</td>
                                                                    <td><span class="label label-success">Online (Active)</span></td>
                                                                    <td>{{ $thisVeryUser->isOnline()['last_activity'] }}</td>
                                                                    <td><form loguserout="yes"  action="{{ url('loguserout') }}" method="POST">
                                                                        @csrf
                                                                        <input type="hidden" name="loguserout" value="{{ $thisVeryUser->id }}" >
                                                                        <button class="btn btn-danger btn-sm btn-fill" href="">Logout User</button>
                                                                        </form>
                                                                    </td>
                                                                </tr>
                                                                @endif
                                                                @if($diff_in_minutes > 10 && $diff_in_minutes <= 30)
                                                                <tr>
                                                                    <td>{{ $count_id++ }}</td>
                                                                    <td>{{ $thisVeryUser->username }}</td>
                                                                    <td>{{ $thisVeryUser->name }}</td>
                                                                    @if($thisVeryUser->status == \App\User::$USER_ACCOUNT_STATUS_ENABLED)
                                                                    <td><span class="label label-success">Enabled Account</span></td>
                                                                    @else
                                                                    <td><span class="label label-danger">Disabled Account</span></td>
                                                                    @endif
                                                                    <td>{{ $thisSession->admin ?? '' }}</td>
                                                                    <td>{{ ($thisVeryUser->access_level == \App\Staff::$USER_ADMIN) ? "ADMIN" : ( ($thisVeryUser->access_level == \App\Staff::$USER_SUBADMIN) ? "SUB-ADMIN" : ($thisVeryUser->access_level == \App\Staff::$USER_STAFF ? "STAFF" : "STAFF")) }}</td>
                                                                    <td><span class="label label-warning">Online (Inactive)</span></td>
                                                                    <td>{{ $thisVeryUser->isOnline()['last_activity'] }}</td>
                                                                     <td><form loguserout="yes" action="{{ url('loguserout') }}" method="POST">
                                                                        @csrf
                                                                        <input type="hidden" name="loguserout" value="{{ $thisVeryUser->id }}" >
                                                                        <button class="btn btn-danger btn-sm btn-fill" href="">Logout User</button>
                                                                        </form>
                                                                    </td>
                                                                </tr>
                                                                @endif

                                                                @endforeach
                                                            </tbody>
                                                        </table>
                    </div>

                </div>


        @elseif(Auth::user()->access_level == \App\Staff::$USER_SUBADMIN)
                <div class="row">
                <div class="col-md-12">
                    <h5>Last Login: {{ Auth::user()->lastLogin() }}</h5>
                </div>
            </div>
            <div class="row">
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Active Staff</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h1>
                                    {{\App\SummaryReport::getStaffCount('active')}}
                                </h1>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Staff On Leave</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h3>
                                    Sabbatical: {{\App\SummaryReport::getStaffCount('sabbatical')}}
                                </h3>
                                <h3>
                                    Study: {{\App\SummaryReport::getStaffCount('study leave')}}
                                </h3>
                                <h3>
                                    Leave Of Absence: {{\App\SummaryReport::getStaffCount('leave of absence')}}
                                </h3>

                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Department</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    {{\App\Department::where('is_currently_active', 1)->count()}}
                                </h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">School</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    {{\App\School::count()}}
                                </h1>
                            </div>
                        </div>
                    </div>

                </div>
            <div class="row">
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Staff On Holiday</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                {{--<h1>--}}
                                    {{--{{\App\Staff::where('status', '<>', \App\Status::where('status', 'active')->get()->first()->id)->get()->count()}}--}}
                                {{--</h1>--}}
                                <h3>
                                    Suspension Pay: {{\App\SummaryReport::getStaffCount('suspension with pay')}}
                                </h3>
                                <h3>
                                    Suspension No-Pay: {{\App\SummaryReport::getStaffCount('suspension without pay')}}
                                </h3>
                                <h3>
                                    Annual Leave: {{\App\SummaryReport::getStaffCount('annual leave')}}
                                </h3>
                                <h3>
                                    Maternity Leave: {{\App\SummaryReport::getStaffCount('maternity leave')}}
                                </h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Out Of Service</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h3>
                                    Dismisal: {{\App\SummaryReport::getStaffCount('dismissal')}}
                                </h3>
                                <h3>
                                    Withdrawal: {{\App\SummaryReport::getStaffCount('withdrawal')}}
                                </h3>
                                <h3>
                                    Transfer: {{\App\SummaryReport::getStaffCount('transfer')}}
                                </h3>
                                <h3>
                                    Retire: {{\App\SummaryReport::getStaffCount('retire')}}
                                </h3>
                                <h3>
                                    Termination: {{\App\SummaryReport::getStaffCount('termination')}}
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Deceased</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    {{\App\SummaryReport::getStaffCount('deceased')}}
                                </h1>
                            </div>
                        </div>
                    </div>

                <div class="col-md-3">
                    <div class="card">

                        <div class="header">
                            <h4 class="title text-center">Promotion Notification</h4>
                            <p class="category"></p>
                        </div>
                        <div class="content text-info  text-center">
                            <h1>
                                {{\App\SummaryReport::getPromotionNotification()}}
                            </h1>
                            <p>
                                <a class="btn btn-success" href="{{url('promotionlist')}}">View</a>
                            </p>
                        </div>
                    </div>
                </div>



            </div>

                <div class="row">

                    <div class="col-md-12">

                    </div>

                </div>

        @elseif(Auth::user()->access_level == \App\Staff::$USER_SUBADMIN)
                <div class="row">
                    <div class="col-md-12">
                        <h5>Last Login: {{ Auth::user()->lastLogin() }}</h5>
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Active Staff</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h1>
                                    {{\App\Staff::where('status', \App\Status::where('status', 'active')->get()->first()->id)->get()->count()}}
                                </h1>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">In-Active Staff</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h1>
                                    {{\App\Staff::where('status', '<>', \App\Status::where('status', 'active')->get()->first()->id)->get()->count()}}
                                </h1>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Department</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    {{\App\Department::where('is_currently_active', 1)->count() }}
                                </h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">School</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    {{\App\School::count()}}
                                </h1>
                            </div>
                        </div>
                    </div>
                </div>
        @elseif(Auth::user()->access_level == \App\Staff::$USER_STAFF)

            <div class="row">
                <h4 class="panel-heading text-primary">
                    Welcome To Your Dashboard Staff: {{Auth::user()->name}}
                </h4>
            </div>

            <div class="row">
                 <div class="col-md-12">
                        <div class="card">
                        </div>
                    </div>
            </div>

            <div class="row">


                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <p class="text-info">
                                    @if ($errors->any())
                                        @foreach ($errors->all() as $error)
                                            <li class="info text-danger">{{ $error }}</li>
                                        @endforeach
                                    @endif

                                </p>
                                <h4 class="title">Manage Your Account</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ route('staff.store') }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('FirstName') }}</label>
                                                <input type="text" placeholder="{{ __('FirstName') }}" class="form-control {{ $errors->has('firstname') ? ' is-invalid' : '' }}" name="firstname" value="{{ old('firstname') }}" required autofocus>
                                                @if ($errors->has('firstname'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('firstname') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('LastName') }}</label>
                                                <input type="text" placeholder="{{ __('LastName') }}" class="form-control {{ $errors->has('lastname') ? ' is-invalid' : '' }}" name="lastname" value="{{ old('lastname') }}" required autofocus>
                                                @if ($errors->has('lastname'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('lastname') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('OtherName') }}</label>
                                                <input type="text" placeholder="{{ __('OtherName') }}" class="form-control {{ $errors->has('othername') ? ' is-invalid' : '' }}" name="othername" value="{{ old('othername') }}"  autofocus>
                                                @if ($errors->has('othername'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('othername') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>{{ __('Gender') }}</label>
                                                <select name="gender" class="form-control" required="required">
                                                    <option value="M">{{ __('Male') }}</option>
                                                    <option value="F">{{ __('Female') }}</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Staff No (PFN)') }}</label>
                                                <span id="staffnocheckokmessage"class="hide text-success">Staff No - Available (good!)</span>
                                                <span id="staffnocheckbadmessage" class="hide text-danger">Staff No - Unavailable (try again)</span>
                                                <input id="staffnocheck" type="text" class="form-control control" placeholder="{{ __('staffno (PFN)') }}" class="form-control {{ $errors->has('staffno') ? ' is-invalid' : '' }}" name="staffno" value="{{ old('staffno') }}"  required="required" autofocus>

                                                @if ($errors->has('staffno'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('staffno') }}</strong>
                                                        </span>
                                                @endif

                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('Marital Status') }}</label>
                                                <select class="form-control {{ $errors->has('maritalstatus') ? ' is-invalid' : '' }} " name="maritalstatus" required>

                                                    <option {{old('maritalstatus')=="M"? 'selected="selected"' : ''}} value="M" >Married</option>
                                                    <option {{old('maritalstatus') =="S"? 'selected="selected"' : ''}} value="S" >Single</option>


                                                </select>
                                                @if ($errors->has('maritalstatus'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('maritalstatus') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('PhoneNo') }}</label>
                                                <input type="phoneno" placeholder="{{ __('PhoneNo') }}" class="form-control {{ $errors->has('phoneno') ? ' is-invalid' : '' }}" name="phoneno" value="{{ old('phoneno') }}" required  autofocus>
                                                @if ($errors->has('phoneno'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('phoneno') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('Email') }}</label>
                                                <input type="email" placeholder="{{ __('Email') }}" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}"  autofocus>
                                                @if ($errors->has('email'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('email') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('DateOfBirth') }}</label>
                                                <input type="date" class="form-control" placeholder="{{ __('dateobirth') }}" class="form-control {{ $errors->has('dateobirth') ? ' is-invalid' : '' }}" name="dateobirth" value="{{ old('dateobirth') }}" required="required"  autofocus>

                                                @if ($errors->has('dateobirth'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('dateobirth') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('Photo') }}</label>
                                                <input type="file" class="form-control" placeholder="{{ __('photo') }}" class="form-control {{ $errors->has('photo') ? ' is-invalid' : '' }}" name="photo" value="{{ old('photo') }}"  autofocus>

                                                @if ($errors->has('photo'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('photo') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                    </div>
                                    <hr>

                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('State') }}</label>
                                                <select id="state" name="state" class="form-control" required="required">
                                                    <option value="">Select State Of Origin</option>
                                                    @foreach ($state as $eachState)

                                                    <option {{old('level')==$eachState? $eachState : ''}} value="{{$eachState->id}}" >{{$eachState->state}}</option>

                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Lga') }}</label>
                                                <select id="lga" name="lga" class="form-control" required="required">
                                                    <option value="">Select Local Government</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Staff Class') }}</label>
                                                <select id="staffclass" class="form-control {{ $errors->has('staffclass') ? ' is-invalid' : '' }} " name="staffclass" required>
                                                    <option selected="selected" >Select Staff Class</option>
                                                    <option value="AS">Academic Staff</option>
                                                    <option value="NA">Non-Academic Staff</option>
                                                </select>

                                                @if($errors->has('staffclass'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('staffclass') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Department') }}</label>
                                                <select class="form-control {{ $errors->has('department') ? ' is-invalid' : '' }} " name="department" required>
                                                    @foreach ($department as $eachDepartment)

                                                    <option {{old('department')==$eachDepartment? $eachDepartment : ''}} value="{{$eachDepartment->id}}" >{{$eachDepartment->department}} {{ $eachDepartment->description}}</option>
                                                    @endforeach
                                                </select>

                                                @if($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('First Appointment Date') }}</label>
                                                <input type="date" class="form-control" placeholder="{{ __('First Appointment Date') }}" class="form-control {{ $errors->has('firstappointdate') ? ' is-invalid' : '' }}" name="firstappointdate" value="{{ old('firstappointdate') }}"  required="required"  autofocus>

                                                @if ($errors->has('firstappointdate'))
                                                    <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('firstappointdate') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Appointment Type') }}</label>
                                                <select class="form-control {{ $errors->has('appointmenttype') ? ' is-invalid' : '' }} " name="appointmenttype" required>
                                                    @foreach($appointmenttype as $anAppointment)
                                                        <option value="{{$anAppointment->id}}">{{$anAppointment->appointmenttype}}</option>
                                                    @endforeach
                                                </select>

                                                @if($errors->has('appointmenttype'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('appointmenttype') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Position (If Any)') }}</label>
                                                    <select class="form-control {{ $errors->has('position') ? ' is-invalid' : '' }} " name="position" required>

                                                            <option value="0">None</option>
                                                        @foreach($position as $eachPosition)
                                                            <option value="{{$eachPosition->id}}">{{$eachPosition->position}}</option>
                                                        @endforeach
                                                    </select>

                                                @if ($errors->has('position'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('position') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Step') }}</label>

                                                    <select class="form-control {{ $errors->has('step') ? ' is-invalid' : '' }} " name="step" required>

                                                    @for ($i = 1; $i <= 50; $i++)
                                                        <option {{old('step')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>

                                                @if ($errors->has('step'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('step') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Present Appointment Date') }}</label>
                                                <input type="date" class="form-control" placeholder="{{ __('Present Appointment Date') }}" class="form-control {{ $errors->has('presentappointdate') ? ' is-invalid' : '' }}" name="presentappointdate" value="{{ old('presentappointdate') }}" required="required"  autofocus>

                                                @if ($errors->has('presentappointdate'))
                                                    <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('presentappointdate') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Rank') }}</label>
                                                <select id="rank" class="form-control {{ $errors->has('rank') ? ' is-invalid' : '' }} " name="rank" required>
                                                        <option value="">Select Staff Rank</option>

                                                </select>
                                                @if ($errors->has('rank'))
                                                    <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('rank') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div id="con___parent" class="col-md-3">
                                            <div id="conpcass" class="form-group">
                                                <label id="con_label">{{ __('CONPCASS') }}</label>
                                                <select class="form-control {{ $errors->has('con___') ? ' is-invalid' : '' }} " name="con___" required>

                                                    @for ($i = 1; $i < 10; $i++)
                                                        <option {{old('con___')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>
                                                @if ($errors->has('con___'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('con___') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Category') }}</label>
                                                <select class="form-control {{ $errors->has('category') ? ' is-invalid' : '' }} " name="category" required>
                                                    <option {{old('category') =="JS"? 'selected="selected"' : ''}} value="JS" >Junior Staff</option>
                                                    <option {{old('category')=="SS"? 'selected="selected"' : ''}} value="SS" >Senior Staff</option>
                                                </select>

                                                @if($errors->has('category'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('category') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('GPZone') }}</label>
                                                <select class="form-control {{ $errors->has('gpzone') ? ' is-invalid' : '' }} " name="gpzone" required>

                                                    @foreach($gpzone as $eachGPZone)
                                                        <option value="{{$eachGPZone->id}}">{{$eachGPZone->gpzone}}</option>
                                                    @endforeach


                                                </select>
                                                @if ($errors->has('gpzone'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('gpzone') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Status') }}</label>
                                                <select class="form-control {{ $errors->has('status') ? ' is-invalid' : '' }} " name="status" required>
                                                    @foreach($status as $eachStatus)
                                                        <option value="{{$eachStatus->id}}">{{$eachStatus->status}}</option>
                                                    @endforeach
                                                </select>

                                                @if($errors->has('status'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('status') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Address 1</label>
                                                <input name="address1" type="text" class="form-control" placeholder="Address 2" value="{{ old('address1') }}"  required="required" >
                                                @if ($errors->has('address1'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('address1') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Address 2</label>
                                                <input name="address2" type="text" class="form-control" placeholder="Address 2" value="{{ old('address2') }}"  required="required" >
                                                @if ($errors->has('address2'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('address2') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend class="title">Qualification</legend>
                                            <div class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select name="qualificationtype[]" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option value="OND">OND</option>
                                                            <option value="HND">HND</option>
                                                            <option value="DEG">Degree</option>
                                                            <option value="PGD">PGD</option>
                                                            <option value="MSC">MSC</option>
                                                            <option value="PHD">PHD</option>
                                                            <option value="OTHERS">Others</option>
                                                        </select>
                                                        @if ($errors->has('qualificationtitle[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtitle[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input name="qualificationtitle[]" type="text" class="form-control" placeholder="Qualification Title" value="{{ old('qualificationtitle[]') }}"  required="required" >
                                                        @if ($errors->has('qualificationtitle[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtitle[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input name="qualificationdesc[]" type="text" class="form-control" placeholder="Qualification Description" value="{{ old('qualificationdesc[]') }}"  required="required" >
                                                        @if ($errors->has('qualificationdesc[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationdesc[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea required="required" name="registeredprobody[]" class="form-control" placeholder="Registered Professional Body" >{{ old('registeredprobody[]', "NONE") }}</textarea>
                                                        @if ($errors->has('registeredprobody[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('registeredprobody[]') }}</strong>
                                                                </span>
                                                        @endif

                                                        <input type="hidden" name="qualificationcount[]" value="1" >
                                                    </div>
                                                </div>

                                            </div>
                                            <hr style="border: 1px solid grey;" />

                                        </fieldset>
                                    </div>

                                    <button id="add_qualification" type="button" class="btn btn-info btn-fill pull-left">Add Another Qualification</button>
                                    <button id="btnsubmit" type="submit" class="btn btn-success btn-fill pull-right">Add New Staff</button>
                                    <div class="clearfix"></div>
                                </form>

                                <div id="conpcass" class="form-group hidden">
                                                <label id="con_label">{{ __('CONPCASS') }}</label>
                                                <select class="form-control {{ $errors->has('con___') ? ' is-invalid' : '' }} " name="con___" required>

                                                    @for ($i = 1; $i < 10; $i++)
                                                        <option {{old('con___')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>
                                                @if ($errors->has('con___'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('con___') }}</strong>
                                                        </span>
                                                @endif
                                </div>
                                <div id="contediss" class="form-group hidden">
                                                <label id="con_label">{{ __('CONTEDISS') }}</label>
                                                <select class="form-control {{ $errors->has('con___') ? ' is-invalid' : '' }} " name="con___" required>

                                                    @for ($i = 1; $i < 16; $i++)
                                                        <option {{old('con___')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>
                                                @if ($errors->has('con___'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('con___') }}</strong>
                                                        </span>
                                                @endif
                                 </div>

                                 <div id="qualificationformcontrols" class="qualificationformcontrols hidden">
                                    <div class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select name="qualificationtype[]" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option value="OND">OND</option>
                                                            <option value="HND">HND</option>
                                                            <option value="DEG">Degree</option>
                                                            <option value="PGD">PGD</option>
                                                            <option value="MSC">MSC</option>
                                                            <option value="PHD">PHD</option>
                                                            <option value="OTHERS">Others</option>
                                                        </select>
                                                        @if ($errors->has('qualificationtype[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtype[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input required="required" name="qualificationtitle[]" type="text" class="form-control" placeholder="Qualification Title" value="{{ old('qualificationtitle[]') }}">
                                                        @if ($errors->has('qualificationtitle[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtitle[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input required="required" name="qualificationdesc[]" type="text" class="form-control" placeholder="Qualification Description" value="{{ old('qualificationdesc[]') }}"  required="required" >
                                                        @if ($errors->has('qualificationdesc[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationdesc[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea required="required" name="registeredprobody[]" class="form-control" placeholder="Registered Professional Body" >{{ old('registeredprobody[]', "NONE") }}</textarea>
                                                        @if ($errors->has('registeredprobody[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('registeredprobody[]') }}</strong>
                                                                </span>
                                                        @endif

                                                        <input type="hidden" name="qualificationcount[]" value="1" >
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <button onclick="this.parentNode.parentNode.remove()" type="button" class="btn-sm btn-danger pull-right btn removebtn">Remove</button>
                                                </div>
                                                <div class="col-md-12" style="padding-top: 1px; padding-left: 1px;">
                                                <hr style="border: 1px solid grey;">
                                                </div>
                                            </div>
                                 </div>


                            </div>
                        </div>
                    </div>


            </div>

            <div class="row">

                    <div class="col-md-6">
                        <div class="card">

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">

                        </div>
                    </div>
            </div>

        @endif

@include('includes.dashboardfooter')
