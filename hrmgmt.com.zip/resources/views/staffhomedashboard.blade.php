@php
    $current_page = 'dashboard';
    $page_title = "Dashboard";
@endphp

@include('includes.dashboardheader')

            <div class="row">
                 <div class="col-md-10 col-sm-8">
                        {{-- <div class="card"> --}}
                            <h5>Last Login: {{ Auth::user()->lastLogin() }}</h5>
                        {{-- </div> --}}
                </div>
                <div class="col-md-2 col-sm-4">
                                            <div class="form-group">
                                                <img class="img-thumbnail" src="{{ Storage::url(\App\Staff::find(Auth::user()->getStaffId())->photo) }}" width="100px" height="100px">
                                            </div>
                                        </div>
            </div>

            <div class="row">
                <h4 class="panel-heading text-primary">
                    Welcome To Your Dashboard Staff: {{Auth::user()->name}}
                </h4>
            </div>

            <div class="row">
                <div class="col-md-3 col-sm-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Your Current Status</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h3>
                                    {{\App\Staff::find(Auth::user()->getStaffId())->getDetails()['status']}}
                                </h3>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Current Rank</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h3>
                                    {{\App\Staff::find(Auth::user()->getStaffId())->getDetails()['rank']}}
                                </h3>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">{{\App\Staff::find(Auth::user()->getStaffId())->getDetails()['con_title']}}</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h3>
                                    {{\App\Staff::find(Auth::user()->getStaffId())->getDetails()['con___']}}
                                </h3>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Category</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h3>
                                    {{\App\Staff::find(Auth::user()->getStaffId())->getDetails()['category'] == "JS"? "JS-Junior Staff" : "SS-Senior Staff"}}
                                </h3>
                            </div>
                        </div>
                </div>
            </div>

            <div class="row">
                {{-- <hr> --}}
                    <div class="col-md-12 col-sm-12">
                        <div class="card">
                        </div>
                    </div>
            </div>
            <div class="row">
                  <div class="col-md-3 col-sm-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Position</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h3>
                                    {{\App\Staff::find(Auth::user()->getStaffId())->getDetails()['position'] }}
                                </h3>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Step</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h3>
                                    {{\App\Staff::find(Auth::user()->getStaffId())->getDetails()['step']}}
                                </h3>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">StaffClass</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h3>
                                    {{\App\Staff::find(Auth::user()->getStaffId())->getDetails()['staffclass'] == "AS" ? "AS-Academic Staff" : "NA-NonAcademic Staff"}}
                                </h3>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-3">
                      
                </div>
            </div>

@include('includes.dashboardfooter')