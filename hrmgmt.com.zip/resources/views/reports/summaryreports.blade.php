@php
    $current_page = 'reports';
    $page_title = "Staff Reports";
@endphp

@include('includes.dashboardheader')

        <div class="row">
                    <div class="col-md-12">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">Get Staff Summary Reports</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ route('leave.store') }}" method="POST">
                                    @csrf
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-3 col-sm-3" style="border-right: 1px solid #333" >
                                            <div class="form-group" >
                                                <label>{{ __('Summary Report') }}</label><br/>
                                                <a href="{{ url('summary_report?act=active') }}" class="btn btn-success {{ $typeact == 'active'? 'btn-fill' : '' }} {{ $typeact == ''? 'btn-fill' : '' }} ">Active Summary Report</a>

                                            </div>
                                            <div class="form-group" >
                                                <label>{{ __('Inactive Summary Report') }}</label><br/>
                                                <a href="{{ url('summary_report?act=inactive') }}" class="btn btn-warning  {{ $typeact == 'inactive'? 'btn-fill' : '' }} ">InActive Summary Report</a>

                                            </div>
                                        </div>
                                    </div>
                                    <hr>

                                    <h5 id="staff_report_title" class="text-center">STAFF REPORTS SUMMARY</h5>
                                    <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group" id="summarysearchResults">
                                           <table id="reportable_staff" class="table table-bordered table-condensed">
                                            @php
                                                $count = 1;
                                                $summation_total = 0;
                                            @endphp
                                                   <thead>
                                                       <tr>
                                                           <td>S/N</td>
                                                           {{-- <td>Department</td> --}}
                                                           <td>RANK</td>
                                                           <td>TOTAL</td>
                                                           <td>STATUS</td>
                                                       </tr>
                                                   </thead>
                                                   <tbody id="summarysearchResultsBody">
                                                    @foreach($department as $eachDepartment)

                                                            @php
                                                                $sub_total = 0;
                                                                $deptReport = \App\SummaryReport::getRecords($eachDepartment->id, $reverse_records);
                                                            @endphp
                                                        <tr>
                                                            <td colspan="" style="text-align:center;"></td>
                                                            <td colspan="" style="text-align:center;"><b>DEPARTMENT OF {{ $eachDepartment->id . ' '. $eachDepartment->description }}</b></td>
                                                            <td colspan="" style="text-align:center;"></td>
                                                            <td colspan="" style="text-align:center;"></td>
                                                        </tr>
                                                        @foreach ($deptReport as $subreport)
                                                        @php
                                                            $sub_total += $subreport->SUMMATION;
                                                        @endphp
                                                        <tr>
                                                            <td>{{ $count++ }}</td>
                                                            {{-- <td>{{ $subreport->description }}</td> --}}
                                                            <td>{{ $subreport->rank }}</td>
                                                            <td>{{ $subreport->SUMMATION }}</td>
                                                            <td>{{ $subreport->status }}</td>
                                                        </tr>
                                                        {{-- {{ var_dump($subreport) }} --}}
                                                    @endforeach
                                                    @php
                                                        $summation_total += $sub_total;
                                                    @endphp
                                                    <tr>
                                                        <td colspan=""  > </td>
                                                        <td colspan="" style="text-align: right;"><b>SUB-TOTAL IS:</b></td>
                                                        <td colspan=""><b>{{ "$sub_total" }}</b></td>
                                                        <td colspan=""></td>
                                                    </tr>
                                                    @endforeach
                                                    <tr>
                                                        <td colspan=""></td>
                                                        <td colspan="" style="text-align: right;"><b>GRAND TOTAL IS:</b></td>
                                                        <td colspan=""><b>{{ "$summation_total" }}</b></td>
                                                        <td colspan=""></td>
                                                    </tr>
                                                   </tbody>
                                               </table>

                                            </div>
                                        </div>
                                    </div>


                                    <h5 id="staff_report_title" class="text-center">HOD REPORTS SUMMARY</h5>
                                    <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group" id="searchResults">

                                            @php
                                                $count = 1;
                                                $summation_total = 0;
                                                $hodRecords = \App\SummaryReport::getHods($reverse_records);
                                            @endphp

                                           <table id="summaryStaffReport" class="table table-bordered table-condensed">
                                                   <thead>
                                                       <tr>
                                                           <td>S/N</td>
                                                           <td>FULLNAME</td>
                                                           <td>RANK</td>
                                                           <td>DEPARTMENT</td>
                                                           <td>POSITION</td>
                                                           <td>STAFFNO</td>
                                                           <td>STATUS</td>
                                                       </tr>
                                                   </thead>
                                                   <tbody id="summaryStaffReportBody">
                                                    @foreach ($hodRecords as $eachHodRecord)
                                                        <tr>
                                                            <td>{{ $count++ }}</td>
                                                            <td>{{ $eachHodRecord->fullname }}</td>
                                                            <td>{{ $eachHodRecord->rank }}</td>
                                                            <td>{{ $eachHodRecord->description }}</td>
                                                            <td>{{ $eachHodRecord->position }}</td>
                                                            <td>{{ $eachHodRecord->staffno }}</td>
                                                            <td>{{ $eachHodRecord->status }}</td>
                                                        </tr>
                                                    @endforeach
                                                   </tbody>
                                               </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                                <hr>
                            </div>
                        </div>
                    </div>

                </div>


                </div>
@include('includes.dashboardfooter')
