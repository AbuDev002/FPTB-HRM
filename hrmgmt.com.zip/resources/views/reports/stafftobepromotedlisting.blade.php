@php
    $current_page = 'reports';
    $page_title = "Staff To Be Promoted";
@endphp

@include('includes.dashboardheader')

        <div class="row">
                    <div class="col-md-12">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">Staff Due For Promotion Listing</h4>
                                <p class="category">List of Staff That Are Due For Promotion</p>
                                <p>
                                    @if(in_array('photo',$hide_columns) || in_array('action', $hide_columns) )
                                        <button src-link-attr="{{url('promotionlist')}}" id="btn_select_staff_promote" class="btn-small btn-fill btn btn-danger">Hide/Show Action & Photo Columns</button>
                                    @else
                                        <button src-link-attr="{{url('promotionlist')}}?hide1=action&hide2=photo" id="btn_select_staff_promote" class="btn-small btn btn-danger">Hide/Show Action & Photo Columns</button>
                                    @endif

                                    &nbsp; 
                                    @if ($quater == 'jan')
                                      <label><input id="jan_quater" checked="checked" class="input input-sm" value="jan" type="radio" name="quater"> JANUARY LISTING</label>  
                                    @else
                                    <label><input id="jan_quater" class="input input-sm" value="jan" type="radio" name="quater"> JANUARY LISTING</label>
                                    @endif


                                    @if ($quater == 'july')
                                    <label>
                                      <input checked="checked" id="july_quater" class="input input-sm" type="radio" value="july" name="quater"> JULY LISTING
                                    </label>
                                    @else
                                    <label>
                                      <input id="july_quater" class="input input-sm" type="radio" value="july" name="quater"> JULY LISTING
                                    </label>
                                    @endif

                                    @if ($quater == 'all')
                                    <label>
                                      <input checked="checked" id="all_quater" class="input input-sm" type="radio" value="all" name="quater"> ALL LISTING
                                    </label>
                                    @else
                                    <label>
                                      <input id="all_quater" class="input input-sm" type="radio" value="all" name="quater"> ALL LISTING
                                    </label>
                                    @endif

                                      &nbsp;  YEAR: 
                                    @if(!empty($quater_year))
                                    <label>
                                     <input name="" id="promotion_year" class="btn btn-primary" type="date" value="{{ $quater_year }}" >
                                    </label>
                                    @else
                                    <label>
                                      <input name="" id="promotion_year" class="btn btn-primary" type="date" value="{{ date('Y-m-d') }}" >
                                    </label>
                                    @endif
                                </p>
                             
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ route('leave.store') }}" method="POST">
                                    @csrf

                                    @php

                                      if($quater_year != 'all')
                                        $carbon_quater_year = \Carbon\Carbon::parse("$quater_year");
                                      else
                                        $carbon_quater_year = \Carbon\Carbon::now();


                                      if($quater_year != 'all' && $quater != 'all'){
                                          $quater_year_only = $carbon_quater_year->year;

                                                          if($quater == 'jan'){
                                                              $title = "JANUARY LIST OF STAFF DUE FOR PROMOTION IN THE YEAR $quater_year_only";
                                                            }elseif($quater == 'july'){
                                                              $title = "JULY LIST OF STAFF DUE FOR PROMOTION IN THE YEAR $quater_year_only";
                                                            }

                                      }elseif($quater_year == 'all' && $quater != 'all'){
                                                            if($quater == 'jan'){
                                                              $title = "JANUARY LIST OF STAFF DUE FOR PROMOTION FOR ALL YEARS";
                                                            }elseif($quater == 'july'){
                                                              $title = "JULY LIST OF STAFF DUE FOR PROMOTION FOR ALL YEARS";
                                                            }
                                                          }elseif($quater_year != 'all' && $quater == 'all'){
                                                            $quater_year_only = $carbon_quater_year->year;
                                                            $title = "ALL STAFF DUE FOR PROMOTION IN YEAR $quater_year_only";
                                                          }else{
                                                            $title = "ALL STAFF DUE FOR PROMOTION FOR ALL YEARS";
                                                          }
                                    @endphp

                                    <script type="text/javascript">
                                      document.title = "REGISTRY REPORT::{{ $title }}";
                                    </script>

                                    <h5 id="staff_report_title" name="staff_report_title_name" class="text-center">{{ $title }}</h5>
                                    <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group" id="searchResults">
                                           <table id="stafftobepromoted" class="table table-bordered table-condensed">
                                                   <thead>
                                                       <tr>
                                                           <td>S/N</td>
                                                           <td>STAFFNO</td>
                                                           <td>FULLNAMES</td>
                                                           @if(!in_array('photo',$hide_columns))
                                                               <th>Staff photo</th>
                                                           @endif
                                                           <td>DEPARTMENT</td>
                                                           <td>GENDER</td>
                                                           <td>SALARY SCALE</td>
                                                           <td>LEVEL</td>
                                                           <td>STEP</td>
                                                           <td>RANK</td>
                                                           <td>CATEGORY</td>
                                                           <td>CLASS</td>
                                                           <td>DATEOB</td>
                                                           <td>POSITION</td>
                                                           <td>PHONENO</td>
                                                           <td>STATE</td>
                                                           <td>LGA</td>
                                                           <td>STATUS</td>
                                                           <td>LAST PROMOTED</td>
                                                           <td>DUE FOR PROMOTION AS AT</td>
                                                           @if(!in_array('action',$hide_columns))
                                                               <th>Action</th>
                                                           @endif
                                                       </tr>
                                                   </thead>
                                                   <tbody id="searchResultsBody">
                                                   @php
                                                       $count_c = 1;

                                                       $chief_ranks = \App\Rank::where('rank', 'like', '%Chief%')->get()->pluck('id')->all();
                                                       
                                                       
                                                       $special_ranks = \App\Rank::where('rank', 'RECTOR')
                                                       ->where('rank', 'BURSAR')
                                                       ->where('rank', 'DEPUTY REGISTRAR')
                                                       ->where('rank', 'POLYTECHNIC LIBRARIAN')
                                                       ->where('rank', 'DEPUTY RECTOR')
                                                       ->get()->pluck('id')->all();

                                                       $permanent_staffs = \App\AppointmentType::where('appointmenttype', 'like', '%PERM%')->pluck('id')->all();

                                                   @endphp

                                                   @foreach ($staff as $eachStaff)

                                                       @php
                                                           $department = \App\Department::find(\App\StaffDepartment::where(['staff_id'=>$eachStaff->id])->first()['dept_id'])['description'];
                                                           $department = $eachStaff->getDepartment();
                                                           $currentPromotion = \App\Promotions::where('status', \App\Promotions::$APPROVED_PROMOTION)
                                                               ->where('promotion_indicator', \App\Promotions::$CURRENT_PROMOTION)->where('staff_id', $eachStaff->id)->get()->first();

                                                           $rank = \App\Rank::find($currentPromotion->rank);
                                                           $status = \App\Status::find($currentPromotion->staff_status)->status;
                                                       $thisDate = $currentPromotion->promotion_date;

                                                       // dump($thisDate); //dd("STOP");
                                                       $datework = \Carbon\Carbon::parse($thisDate);
                                                       
                                                       $considered_year_date = $carbon_quater_year;

                                                       $yearDifferenceNow = ($considered_year_date->year - $datework->year);


                                                      if($quater == 'jan'){
                                                        if( $yearDifferenceNow >= 3 && ($datework->month <= 6) ){

                                                        // If this staff is currently a Chief in Rank
                                                        if(!in_array($currentPromotion->rank, $chief_ranks) && in_array($currentPromotion->appointmenttype, $permanent_staffs) && !in_array($currentPromotion->rank, $special_ranks) && ($currentPromotion->last_promotion_status != \App\Promotions::$IS_LAST_PROMOTED)){

                                                              $isOkToDisplayRecord = true;

                                                          if($isOkToDisplayRecord){

                                                       @endphp

                                                       <tr>
                                                           <td>{{ $count_c++ }}</td>
                                                           <td>{{$eachStaff->staffno}}</td>
                                                           <td>{{"{$eachStaff->fname} {$eachStaff->lname} {$eachStaff->oname}"}}</td>
                                                           @if(!in_array('photo',$hide_columns))
                                                               <td><img class="img" width="100px" height="100px" src="{{\Storage::url("{$eachStaff->photo}")}}"  /> </td>
                                                           @endif
                                                           <td>{{ $department }}</td>
                                                           <td>{{ $eachStaff->gender }}</td>
                                                           <td>{{ $currentPromotion->getSalaryScale() }}</td>
                                                           <td>{{ $currentPromotion->salary_scale_value }}</td>
                                                           <td>{{ $currentPromotion->step }}</td>
                                                           <td>{{ $rank->rank }}</td>
                                                           <td>{{ $currentPromotion->category }}</td>
                                                           <td>{{ $currentPromotion->staffclass }}</td>
                                                           <td>{{ $eachStaff->dateobirth }}</td>
                                                           <td>{{ $currentPromotion->getPosition() }}</td>
                                                           <td>{{ $eachStaff->phoneno }}</td>
                                                           <td>{{ $eachStaff->getDetails()['state'] }}</td>
                                                           <td>{{ $eachStaff->getDetails()['lga'] }}</td>
                                                           <td>{{ $currentPromotion->getStaffStatus() }}</td>
                                                           <td>{{ $currentPromotion->presentappointdate }}</td>
                                                           <td>
                                                               @php

                                                               \App\Http\Controllers\StaffController::getDueDate($datework);

                                                                @endphp
                                                           </td>

                                                           @if(!in_array('action',$hide_columns))
                                                               <td>

                                                                   <form onsubmit="return (confirm('Are you Sure That You Want To Delete This Record? Please Confirm.?'))" action="{{ url("staff/". $eachStaff->id) }}" method="POST" >
                                                                       <input type="hidden" name="_method" value="delete">
                                                                       @csrf
                                                                       <a class="btn btn-sm btn-primary " href="{{url('promote/'.$eachStaff->id)}}">Promote</a>

                                                                   </form>
                                                               </td>
                                                           @endif

                                                       </tr>
                                                       @php
                                                          }
                                                          }
                                                        }
                                                      }elseif($quater == 'july'){
                                                          if( $yearDifferenceNow >= 3 && ($datework->month > 6) ){

                                                        // If this staff is currently a Chief in Rank
                                                        if(!in_array($currentPromotion->rank, $chief_ranks)  && !in_array($currentPromotion->rank, $special_ranks)  && in_array($currentPromotion->appointmenttype, $permanent_staffs) && ($currentPromotion->last_promotion_status != \App\Promotions::$IS_LAST_PROMOTED)){

                                                              $isOkToDisplayRecord = true;

                                                          if($isOkToDisplayRecord){

                                                       @endphp

                                                       <tr>
                                                           <td>{{ $count_c++ }}</td>
                                                           <td>{{$eachStaff->staffno}}</td>
                                                           <td>{{"{$eachStaff->fname} {$eachStaff->lname} {$eachStaff->oname}"}}</td>
                                                           @if(!in_array('photo',$hide_columns))
                                                               <td><img class="img" width="100px" height="100px" src="{{\Storage::url("{$eachStaff->photo}")}}"  /> </td>
                                                           @endif
                                                           <td>{{ $department }}</td>
                                                           <td>{{ $eachStaff->gender }}</td>
                                                           <td>{{ $currentPromotion->getSalaryScale() }}</td>
                                                           <td>{{ $currentPromotion->salary_scale_value }}</td>
                                                           <td>{{ $currentPromotion->step }}</td>
                                                           <td>{{ $rank->rank }}</td>
                                                           <td>{{ $currentPromotion->category }}</td>
                                                           <td>{{ $currentPromotion->staffclass }}</td>
                                                           <td>{{ $eachStaff->dateobirth }}</td>
                                                           <td>{{ $currentPromotion->getPosition() }}</td>
                                                           <td>{{ $eachStaff->phoneno }}</td>
                                                           <td>{{ $eachStaff->getDetails()['state'] }}</td>
                                                           <td>{{ $eachStaff->getDetails()['lga'] }}</td>
                                                           <td>{{ $currentPromotion->getStaffStatus() }}</td>
                                                           <td>{{ $currentPromotion->presentappointdate }}</td>
                                                           <td>
                                                               @php

                                                                \App\Http\Controllers\StaffController::getDueDate($datework);

                                                                @endphp
                                                           </td>

                                                           @if(!in_array('action',$hide_columns))
                                                               <td>

                                                                   <form onsubmit="return (confirm('Are you Sure That You Want To Delete This Record? Please Confirm.?'))" action="{{ url("staff/". $eachStaff->id) }}" method="POST" >
                                                                       <input type="hidden" name="_method" value="delete">
                                                                       @csrf
                                                                       <a class="btn btn-sm btn-primary " href="{{url('promote/'.$eachStaff->id)}}">Promote</a>

                                                                   </form>
                                                               </td>
                                                           @endif

                                                       </tr>
                                                       @php
                                                          }
                                                          }
                                                        }
                                                      }else{
                                                        if( $yearDifferenceNow >= 3 ){

                                                        // If this staff is currently a Chief in Rank
                                                        if(!in_array($currentPromotion->rank, $chief_ranks)  && !in_array($currentPromotion->rank, $special_ranks) && in_array($currentPromotion->appointmenttype, $permanent_staffs) && ($currentPromotion->last_promotion_status != \App\Promotions::$IS_LAST_PROMOTED)){

                                                              $isOkToDisplayRecord = true;

                                                          if($isOkToDisplayRecord){

                                                       @endphp

                                                       <tr>
                                                           <td>{{ $count_c++ }}</td>
                                                           <td>{{$eachStaff->staffno}}</td>
                                                           <td>{{"{$eachStaff->fname} {$eachStaff->lname} {$eachStaff->oname}"}}</td>
                                                           @if(!in_array('photo',$hide_columns))
                                                               <td><img class="img" width="100px" height="100px" src="{{\Storage::url("{$eachStaff->photo}")}}"  /> </td>
                                                           @endif
                                                           <td>{{ $department }}</td>
                                                           <td>{{ $eachStaff->gender }}</td>
                                                           <td>{{ $currentPromotion->getSalaryScale() }}</td>
                                                           <td>{{ $currentPromotion->salary_scale_value }}</td>
                                                           <td>{{ $currentPromotion->step }}</td>
                                                           <td>{{ $rank->rank }}</td>
                                                           <td>{{ $currentPromotion->category }}</td>
                                                           <td>{{ $currentPromotion->staffclass }}</td>
                                                           <td>{{ $eachStaff->dateobirth }}</td>
                                                           <td>{{ $currentPromotion->getPosition() }}</td>
                                                           <td>{{ $eachStaff->phoneno }}</td>
                                                           <td>{{ $eachStaff->getDetails()['state'] }}</td>
                                                           <td>{{ $eachStaff->getDetails()['lga'] }}</td>
                                                           <td>{{ $currentPromotion->getStaffStatus() }}</td>
                                                           <td>{{ $currentPromotion->presentappointdate }}</td>
                                                           <td>
                                                              @php
                                                                  \App\Http\Controllers\StaffController::getDueDate($datework);
                                                              @endphp
                                                           </td>

                                                           @if(!in_array('action',$hide_columns))
                                                               <td>

                                                                   <form onsubmit="return (confirm('Are you Sure That You Want To Delete This Record? Please Confirm.?'))" action="{{ url("staff/". $eachStaff->id) }}" method="POST" >
                                                                       <input type="hidden" name="_method" value="delete">
                                                                       @csrf
                                                                       <a class="btn btn-sm btn-primary " href="{{url('promote/'.$eachStaff->id)}}">Promote</a>

                                                                   </form>
                                                               </td>
                                                           @endif

                                                       </tr>
                                                       @php
                                                          }
                                                          }
                                                        }
                                                      }
                                                      

                                                       @endphp

                                                   @endforeach
                                                   </tbody>
                                               </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                                <hr>

                            </div>
                        </div>
                    </div>

                </div>

                </div>
@include('includes.dashboardfooter')