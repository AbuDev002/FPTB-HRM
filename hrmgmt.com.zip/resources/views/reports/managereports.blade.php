@php
    $current_page = 'reports';
    $page_title = "Staff Reports";
@endphp

@include('includes.dashboardheader')

        <div class="row">
                    <div class="col-md-12">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">Get Staff Reports</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content"> {{-- action="{{ route('leave.store') }}"  --}}
                                <form enctype="multipart/form-data" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-2 col-sm-2" style="border-right: 1px solid #333" >
                                            <div class="form-group" >
                                                <label>{{ __('Filter By Status') }}</label>
                                                <select class="form-control" id="searchByStatus">
                                                    <option selected="selected"   value="all">All Status</option>
                                                    @foreach ($status  as $eachStatus)
                                                        <option value="{{$eachStatus->id}}">{{$eachStatus->status}}</option>
                                                    @endforeach
                                                </select>
                                                @if ($errors->has('status'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('status') }}</strong>
                                                        </span>
                                                @endif

                                            </div>
                                        </div>

                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label>{{ __('FirstName') }}</label>
                                                <input id="fname" type="text" placeholder="{{ __('FirstName') }}" class="form-control {{ $errors->has('firstname') ? ' is-invalid' : '' }}" name="firstname" value="{{ old('firstname') }}" required autofocus>
                                                @if ($errors->has('firstname'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('firstname') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label>{{ __('LastName') }}</label>
                                                <input id="lname" type="text" placeholder="{{ __('LastName') }}" class="form-control {{ $errors->has('lastname') ? ' is-invalid' : '' }}" name="lastname" value="{{ old('lastname') }}" required autofocus>
                                                @if ($errors->has('lastname'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('lastname') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label>{{ __('OtherName') }}</label>
                                                <input id="oname" type="text" placeholder="{{ __('OtherName') }}" class="form-control {{ $errors->has('othername') ? ' is-invalid' : '' }}" name="othername" value="{{ old('othername') }}"  autofocus>
                                                @if ($errors->has('othername'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('othername') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <label>{{ __('Search Action') }}</label>
                                            <button id="btn_names" type="button" class="btn btn-success">Search By Names</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label>{{ __('Staff Number Search') }}</label>
                                                <input id="staffno" type="text" class="form-control" placeholder="{{ __('Staff No Search') }}" class="form-control {{ $errors->has('staffno') ? ' is-invalid' : '' }}" name="staffno" value="{{ old('staffno') }}"  autofocus>
                                                @if ($errors->has('staffno'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('staffno') }}</strong>
                                                        </span>
                                                @endif

                                            </div>
                                        </div>
                                        <div class="col-md-2 col-sm-2">
                                            <label>{{ __('Action') }}</label> <br>
                                            <button id="btn_staffno" type="button" class="btn btn-success">Search By StaffNo</button>
                                        </div>
                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label>{{ __('Staff Class') }}</label>
                                                <select class="form-control" id="searchByStaffClass">
                                                    <option   value="">Search By Staff Class</option>
                                                    <option value="AS">Academic Staff</option>
                                                    <option value="NA">NonAcademic Staff</option>
                                                    <option value="ALL">All</option>
                                                </select>
                                                @if ($errors->has('staffno'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('staffno') }}</strong>
                                                        </span>
                                                @endif

                                            </div>
                                        </div>

                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label>{{ __('Department') }}</label>
                                                <select class="form-control" id="searchByDepartment">
                                                    <option   value="">Search By Department</option>
                                                    <option   value="all">All Department</option>
                                                    @foreach ($department  as $eachDepartment)
                                                        <option value="{{$eachDepartment->id}}">{{$eachDepartment->department}}</option>
                                                    @endforeach
                                                </select>
                                                @if ($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif

                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <label>{{ __('Search Action') }}</label>
                                            <button id="btn_class_department" type="button" class="btn btn-success">Search By Class/Department</button>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-2 col-sm-2" style="border-right: 1px solid #333" >
                                            <div class="form-group" >
                                                <label>{{ __('Summary Report') }}</label>
                                                <a href="{{ url('summary_report') }}" class="btn btn-success">Summary Report</a>

                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3">
                                             <div style="display: none;" class="imgloaderindicator"></div> 
                                        </div>
                                    </div>


                                    <h5 id="staff_report_title" name="staff_report_title_name" class="text-center">STAFF REPORTS</h5>
                                    <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group" id="searchResults">
                                           <table id="staffreporttable" class="table table-bordered table-condensed">
                                                   <thead>
                                                       <tr>
                                                           <td>S/N</td>
                                                           <td>STAFFNO</td>
                                                           <td>FULLNAMES</td>
                                                           <td>DEPARTMENT</td>
                                                           <td>RANK</td>
                                                           <td>CATEGORY</td>
                                                           <td>DATEOB</td>
                                                           <td>GENDER</td>
                                                           <td>POSITION</td>
                                                           <td>ADDED. RESP.</td>
                                                           <td>PHONENO</td>
                                                           <td>STATE</td>
                                                           <td>LGA</td>
                                                           <td>STATUS</td>
                                                       </tr>
                                                   </thead>
                                                   <tbody id="searchResultsBody">

                                                   </tbody>
                                               </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                                <hr>

                                {{-- <form method="POST" action="{{route('leave.store')}}">
                                    <button id="btnsubmit" disabled="" type="submit" class="btn btn-info btn-fill pull-right">Give These Staff Leave</button>
                                    <div class="clearfix"></div>
                                </form> --}}
                            </div>
                        </div>
                    </div>

                </div>


                </div>
@include('includes.dashboardfooter')
