@php
    $current_page = 'departmentunits';
@endphp

@include('includes.dashboardheader')

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                        @isset($displaystate)
                            @if ($displaystate == 'edit')
                            <div class="header">
                                <h4 class="title">Update Department Unit Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ url('units/'.$unit->id )}}" method="POST">

                                    @method('PUT')
                                    @csrf

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Department Unit') }}</label>
                                                <input type="text" placeholder="{{ __('Department Unit') }}" class="form-control {{ $errors->has('unit') ? ' is-invalid' : '' }}" name="unit" value="{{ old('unit', $unit->unit) }}" required autofocus>
                                                @if ($errors->has('unit'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('unit') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                                    
                                                    {{-- @dd($department) --}}
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Department') }}</label>

                                                <select type="text" placeholder="{{ __('Select Department') }}" class="form-control {{ $errors->has('department') ? ' is-invalid' : '' }}" name="department" required autofocus>
                                                    <option value="">Select Department</option>


                                                    @foreach ($department as $eachDeparment)
                                                        @if ($eachDeparment->id == $unit->getDepartment()->id)
                                                            <option selected="selected" value="{{ $eachDeparment->id }}">{{ $eachDeparment->getDepartment("full") }}</option>
                                                        @else
                                                            <option value="{{ $eachDeparment->id }}">{{ $eachDeparment->getDepartment('full') }}</option>
                                                        @endif
                                                @endforeach


                                                </select>
                                                @if ($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <a href="{{ url("units/create")}}" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Department Unit Information</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @elseif($displaystate == 'delete')
                                <div class="header">
                                <h4 class="title text-danger">Delete Department Unit Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ url('unit/'.$unit->id )}}" method="POST">

                                    @method('DELETE')
                                    @csrf

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Department Unit?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Unit') }}</label>
                                                <input disabled="disabled" type="text" placeholder="{{ __('Unit') }}" class="form-control {{ $errors->has('unit') ? ' is-invalid' : '' }}" name="unit" value="{{ old('unit', $unit->unit) }}" required autofocus>
                                                @if($errors->has('unit'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('unit') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Department') }}</label>
                                                
                                                <select type="text" placeholder="{{ __('Select Department') }}" class="form-control {{ $errors->has('department') ? ' is-invalid' : '' }}" name="department" required autofocus>
                                                    <option value="">Select Department</option>


                                                    @foreach ($department as $eachDeparment)
                                                        @if ($eachDeparment->id == $unit->getDepartment()->id)
                                                            <option selected="selected" value="{{ $eachDeparment->id }}">{{ $eachDeparment->getDepartment("full") }}</option>
                                                        @else
                                                            <option value="{{ $eachDeparment->id }}">{{ $eachDeparment->getDepartment('full') }}</option>
                                                        @endif
                                                @endforeach


                                                </select>
                                                @if ($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="{{ url("unit/create")}}" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE department</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @else
                                {{-- Only Display the Information --}}
                                <div class="header">
                                <h4 class="title">View Department Unit Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" >


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Unit') }}</label>
                                                <input readonly="readonly" type="text" placeholder="{{ __('Unit') }}" class="form-control {{ $errors->has('unit') ? ' is-invalid' : '' }}" name="unit" value="{{ old('unit', $unit->unit) }}" required autofocus>
                                                @if ($errors->has('unit'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('unit') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Department') }}</label>
                                                
                                                <select disabled="disabled" type="text" placeholder="{{ __('Select Department') }}" class="form-control {{ $errors->has('department') ? ' is-invalid' : '' }}" name="department" required autofocus>
                                                    <option value="">Select Department</option>


                                                    @foreach ($department as $eachDeparment)
                                                        @if ($eachDeparment->id == $unit->getDepartment()->id)
                                                            <option selected="selected" value="{{ $eachDeparment->id }}">{{ $eachDeparment->getDepartment("full") }}</option>
                                                        @else
                                                            <option value="{{ $eachDeparment->id }}">{{ $eachDeparment->getDepartment('full') }}</option>
                                                        @endif
                                                @endforeach


                                                </select>
                                                @if ($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <a href="{{ url("unit/create") }}" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="{{ url("unit/{$unit->id}").'/edit' }}" class="btn btn-info btn-fill pull-right">Edit Department Information</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            @endif
                        @else
                            
                            <div class="header">
                                <h4 class="title">Add New Units</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ route('units.store') }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Unit') }}</label>
                                                <input type="text" placeholder="{{ __('Unit') }}" class="form-control {{ $errors->has('unit') ? ' is-invalid' : '' }}" name="unit" value="{{ old('unit') }}" required autofocus>
                                                @if ($errors->has('unit'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('unit') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>{{ __('Department') }}</label>
                                                <select type="text" placeholder="{{ __('Select Department') }}" class="form-control {{ $errors->has('department') ? ' is-invalid' : '' }}" name="department" required autofocus>
                                                    <option value="">Select Department</option>
                                                    @foreach ($department as $eachDeparment)

                                                        @if ($eachDeparment->id == old('department'))
                                                            <option selected="selected" value="{{ $eachDeparment->id }}">{{ $eachDeparment->getDepartment('full') }}</option>
                                                        @else
                                                            <option value="{{ $eachDeparment->id }}">{{ $eachDeparment->getDepartment('full') }}</option>
                                                        @endif

                                                    @endforeach
                                                </select>
                                                @if ($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add New Units</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        @endisset
                        </div>
                        <div> 
                            @php 
                                $totalDeptUnitCount = \App\DepartmentUnit::count();

                            @endphp

                            TOTAL DEPARTMENT Units IS: {{ $totalDeptUnitCount }}

                            <script type="text/javascript">
                              document.title = "DEPARTMENT UNIT LISTING::TOTAL DEPARTMENT UNIT {{ $totalDeptUnitCount }}";
                            </script>

                            <table id="stafftobepromoted" class="table table-bordered table-condensed">
                                <thead>
                                    <tr>
                                        <td>Unit</td>
                                        <td>Department</td>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <td>Unit</td>
                                        <td>Department</td>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    @php
                                        $allDeptUnits = \App\DepartmentUnit::all();
                                    @endphp

                                    @foreach ($allDeptUnits as $eachDeptUnits)
                                        
                                    <tr>
                                        <td>{{ $eachDeptUnits->unit }}</td>
                                        <td>{{ $eachDeptUnits->getDepartment()->getDepartment('full') }}</td>
                                    </tr>

                                    @endforeach

                                </tbody>
                            </table>

                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Department Units Available</h4>
                                <p class="category">This is the list of All Department Units Available</p>
                                @if (session('status'))
                                    <div class="alert alert-success">
                                        {{ session('status') }}
                                    </div>
                                @endif
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>Units</th>
                                        <th>Department</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        @php

                                            if(!is_array($department) && !($department instanceof Countable)){
                                                $department = array($department);
                                            }

                                        @endphp

                                        @foreach ($units as $eachDeptUnits)
                                        <tr>
                                            <td>{{ $eachDeptUnits->unit }}</td>
                                            <td>{{ $eachDeptUnits->getDepartment()->getDepartment('full') }}</td>
                                            <td>
                                                <a class="btn btn-sm btn-info" href="{{ url("units/$eachDeptUnits->id").'/edit' }}" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="{{ url("units/$eachDeptUnits->id") }}" >View</a>
                                                <a class="btn btn-sm btn-danger" href="{{ url("units/$eachDeptUnits->id?action=del") }}" >Delete</a>
                                            </td>
                                        </tr>

                                        @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
@include('includes.dashboardfooter')