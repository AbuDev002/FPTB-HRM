@php
    $current_page = 'addstaff';
@endphp

@include('includes.dashboardheader')

        <div class="row">

                    <div class="col-md-10">
                        <div class="card">
                            <div class="header">
                                <p class="text-info">
                                    @if ($errors->any())
                                        @foreach ($errors->all() as $error)
                                            <li class="info text-danger">{{ $error }}</li>
                                        @endforeach
                                    @endif

                                </p>
                                <form enctype="multipart/form-data" action="{{ route('staff.import') }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <input type="file" name="uploadfile" required class="form-control" >
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <input class="btn btn-fill btn-sm btn-primary" type="submit" value="Upload Staff Record(s)">
                                            </div>
                                        </div>

                                    </div>
                                        <hr/>

                                </form>

                                <h4 class="title">Add New Staff</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="{{ route('staff.store') }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Staff No (PFN)') }}</label>
                                                <span id="staffnocheckokmessage"class="hide text-success">Staff No - Available (good!)</span>
                                                <span id="staffnocheckbadmessage" class="hide text-danger">Staff No - Unavailable (try again)</span>
                                                <input id="staffnocheck" type="text" class="form-control control" placeholder="{{ __('staffno (PFN)') }}" class="form-control {{ $errors->has('staffno') ? ' is-invalid' : '' }}" name="staffno" value="{{ old('staffno') }}"  required="required" autofocus>

                                                @if ($errors->has('staffno'))
                                                    <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('staffno') }}</strong>
                                                        </span>
                                                @endif

                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('FirstName') }}</label>
                                                <input type="text" placeholder="{{ __('FirstName') }}" class="form-control {{ $errors->has('firstname') ? ' is-invalid' : '' }}" name="firstname" value="{{ old('firstname') }}" required autofocus>
                                                @if ($errors->has('firstname'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('firstname') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('LastName') }}</label>
                                                <input type="text" placeholder="{{ __('LastName') }}" class="form-control {{ $errors->has('lastname') ? ' is-invalid' : '' }}" name="lastname" value="{{ old('lastname') }}" required autofocus>
                                                @if ($errors->has('lastname'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('lastname') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('OtherName') }}</label>
                                                <input type="text" placeholder="{{ __('OtherName') }}" class="form-control {{ $errors->has('othername') ? ' is-invalid' : '' }}" name="othername" value="{{ old('othername') }}"  autofocus>
                                                @if ($errors->has('othername'))
                                                    <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('othername') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-sm-2 col-md-2">
                                            <div class="form-group">
                                                <label>{{ __('Gender') }}</label>
                                                <select name="gender" class="form-control" required="required">
                                                    <option value="M">{{ __('Male') }}</option>
                                                    <option value="F">{{ __('Female') }}</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('Marital Status') }}</label>
                                                <select id="maritalstatus" class="form-control {{ $errors->has('maritalstatus') ? ' is-invalid' : '' }} " name="maritalstatus" required>

                                                    <option {{old('maritalstatus')=="M"? 'selected="selected"' : ''}} value="M" >Married</option>
                                                    <option {{old('maritalstatus') =="S"? 'selected="selected"' : ''}} value="S" >Single</option>

                                                </select>
                                                @if ($errors->has('maritalstatus'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('maritalstatus') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('PhoneNo') }}</label>
                                                <input type="text" placeholder="{{ __('PhoneNo') }}" class="form-control {{ $errors->has('phoneno') ? ' is-invalid' : '' }}" name="phoneno" value="{{ old('phoneno') }}"  autofocus>
                                                @if ($errors->has('phoneno'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('phoneno') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('Email') }}</label>
                                                <input type="email" placeholder="{{ __('Email') }}" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}"  autofocus>
                                                @if ($errors->has('email'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('email') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('DateOfBirth') }}</label>
                                                <input type="date" class="form-control" placeholder="{{ __('dateobirth') }}" class="form-control {{ $errors->has('dateobirth') ? ' is-invalid' : '' }}" name="dateobirth" value="{{ old('dateobirth') }}" required="required"  autofocus>

                                                @if ($errors->has('dateobirth'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('dateobirth') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('Photo') }}</label>
                                                <input type="file" class="form-control" placeholder="{{ __('photo') }}" class="form-control {{ $errors->has('photo') ? ' is-invalid' : '' }}" name="photo" value="{{ old('photo') }}" autofocus>

                                                @if ($errors->has('photo'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('photo') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6 col-md-6">
                                            <div class="form-group">
                                                <label>Address 1</label>
                                                <input name="address1" type="text" class="form-control" placeholder="Address 2" value="{{ old('address1') }}"  required="required" >
                                                @if ($errors->has('address1'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('address1') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-sm-6 col-md-6">
                                            <div class="form-group">
                                                <label>Address 2</label>
                                                <input name="address2" type="text" class="form-control" placeholder="Address 2" value="{{ old('address2') }}"  required="required" >
                                                @if ($errors->has('address2'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('address2') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('State') }}</label>
                                                <select id="state" name="state" class="form-control" required="required">
                                                    <option value="">Select State Of Origin</option>
                                                    @foreach ($state as $eachState)

                                                    <option {{old('state')==$eachState->id? 'selected="selected"' : ''}} value="{{$eachState->id}}" >{{$eachState->state}}</option>

                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('Lga') }}</label>
                                                <select id="lga" name="lga" class="form-control" required="required">
                                                    <option value="">Select Local Government</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label>{{ __('GPZone') }}</label>
                                                <select class="form-control {{ $errors->has('gpzone') ? ' is-invalid' : '' }} " name="gpzone" required>

                                                    @foreach($gpzone as $eachGPZone)
                                                        <option value="{{$eachGPZone->id}}">{{$eachGPZone->gpzone}}</option>
                                                    @endforeach


                                                </select>
                                                @if ($errors->has('gpzone'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('gpzone') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row" >
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokfname">{{ __('Next Of Kin First Name')}}</label>
                                                <input class="form-control" placeholder="Next Of Kin First Name" type="text" name="nokfname" >
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="noklname">{{ __('Next Of Kin Last Name')}}</label>
                                                <input class="form-control" placeholder="Next Of Kin Last Name" type="text" name="noklname" >
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokoname">{{ __('Next Of Kin Other Name')}}</label>
                                                <input class="form-control" placeholder="Next Of Kin Other Name" type="text" name="nokoname" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" >
                                         <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokaddress">{{ __('Next Of Kin Address')}}</label>
                                                <textarea class="form-control"  name="nokaddress" placeholder="Enter Next Of Kin Address" ></textarea>
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokphoneno">{{ __('Next Of Kin Phone No')}}</label>
                                                <input type="text" class="form-control" name="nokphoneno" placeholder="Enter Next Of Kin PhoneNo" />
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokrelationship">{{ __('Relationship With Next Of Kin')}}</label>
                                                <input type="text" class="form-control" name="nokrelationship" placeholder="Enter Next Of Kin Relationship">
                                                </textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div id="childsection1_div" class="row" style="border-bottom: 2px solid #eee" >
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nameofchild1">{{ __('Child\'s Name  (If Any)')}}</label>
                                                <input type="text" name="nameofchild1" placeholder="Name of Child (If Any)" class="form-control" value="{{old('nameofchild1')}}" >
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2" style="border-right: 2px solid #eee">
                                            <div class="form-group">
                                                <label for="ageofchild1">{{ __('Child\'s Age')}}</label>
                                                <input type="number" min="0" name="ageofchild1" placeholder="Age of Child" value="{{old('ageofchild1')}}" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nameofchild2">{{ __('Child\'s Name  (If Any)')}}</label>
                                                <input type="text" name="nameofchild2" placeholder="Name of Child (If Any)" value="{{old('nameofchild2')}}" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2">
                                            <div class="form-group">
                                                <label for="ageofchild2">{{ __('Child\'s Age')}}</label>
                                                <input type="number" min="0" name="ageofchild2" placeholder="Age of Child" value="{{old('ageofchild2')}}" class="form-control">
                                            </div>
                                        </div>

                                    </div>
                                    <div id="childsection2_div" class="row">
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group bor">
                                                <label for="nameofchild3">{{ __('Child\'s Name  (If Any)')}}</label>
                                                <input type="text" name="nameofchild3" placeholder="Name of Child (If Any)" value="{{old('nameofchild3')}}" class="form-control" value="">
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2" style="border-right: 2px solid #eee">
                                            <div class="form-group">
                                                <label for="ageofchild3">{{ __('Child\'s Age')}}</label>
                                                <input type="number" min="0" name="ageofchild3" placeholder="Age of Child" value="{{old('ageofchild3')}}" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nameofchild4">{{ __('Child\'s Name  (If Any)')}}</label>
                                                <input type="text" name="nameofchild4" placeholder="Name of Child (If Any)" value="{{old('nameofchild4')}}" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2">
                                            <div class="form-group">
                                                <label for="ageofchild4">{{ __('Child\'s Age')}}</label>
                                                <input type="number" min="0" name="ageofchild4" placeholder="Age of Child" value="{{old('ageofchild4')}}" class="form-control">
                                            </div>
                                        </div>

                                    </div>
                                    <hr id="childsection2_hr" class="">

                                    <div class="row">

                                         <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('First Appointment Date') }}</label>
                                                <input type="date" class="form-control" placeholder="{{ __('First Appointment Date') }}" class="form-control {{ $errors->has('firstappointdate') ? ' is-invalid' : '' }}" name="firstappointdate" value="{{ old('firstappointdate') }}"  required="required"  autofocus>

                                                @if ($errors->has('firstappointdate'))
                                                    <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('firstappointdate') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('School') }}</label>
                                                <select id="school" class="form-control {{ $errors->has('school') ? ' is-invalid' : '' }} " name="school" required="required">
                                                    <option selected="selected" >Select School</option>
                                                    @foreach ($school as $eachSchool)

                                                    <option {{old('department')==$eachSchool? $eachSchool : ''}} value="{{$eachSchool->id}}" >{{$eachSchool->school}}</option>
                                                    @endforeach
                                                </select>

                                                @if($errors->has('school'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('school') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Department') }}</label>
                                                <select id="department" class="form-control {{ $errors->has('department') ? ' is-invalid' : '' }} " name="department" required>
                                                    <option value="" >Select Department</option>

                                                   {{--  @foreach ($department as $eachDepartment)

                                                    <option {{old('department')==$eachDepartment? $eachDepartment : ''}} value="{{$eachDepartment->id}}" >{{$eachDepartment->department}} {{ $eachDepartment->description}}</option>
                                                    @endforeach --}}

                                                </select>

                                                @if($errors->has('department'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('department') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Department Unit') }}</label>
                                                <select id="departmentunit" class="form-control {{ $errors->has('departmentunit') ? ' is-invalid' : '' }} " name="departmentunit" required>
                                                    <option value="" >Select Department Unit</option>
                                                </select>

                                                @if($errors->has('departmentunit'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('departmentunit') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">

                                       <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Present Appointment Date') }}</label>
                                                <input type="date" class="form-control" placeholder="{{ __('Present Appointment Date') }}" class="form-control {{ $errors->has('presentappointdate') ? ' is-invalid' : '' }}" name="presentappointdate" value="{{ old('presentappointdate') }}" required="required"  autofocus>

                                                @if ($errors->has('presentappointdate'))
                                                    <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('presentappointdate') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Appointment Type') }}</label>
                                                <select class="form-control {{ $errors->has('appointmenttype') ? ' is-invalid' : '' }} " name="appointmenttype" required>
                                                    @foreach($appointmenttype as $anAppointment)
                                                        <option value="{{$anAppointment->id}}">{{$anAppointment->appointmenttype}}</option>
                                                    @endforeach
                                                </select>

                                                @if($errors->has('appointmenttype'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('appointmenttype') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Position (If Any)') }}</label>
                                                    <select class="form-control {{ $errors->has('position') ? ' is-invalid' : '' }} " name="position" required>

                                                            <option value="">Select Position</option>
                                                        @foreach($position as $eachPosition)
                                                            <option value="{{$eachPosition->id}}">{{$eachPosition->position}}</option>
                                                        @endforeach
                                                    </select>

                                                @if ($errors->has('position'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('position') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="hidden col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Added Responsibilites (If Any)') }}</label>
                                                    <select multiple="multiple" class="form-control {{ $errors->has('additional_responsibility') ? ' is-invalid' : '' }} " name="additional_responsibility[]" required>

                                                            <option value="">Select Position</option>
                                                        @foreach($position as $eachPosition)
                                                            <option {{ $eachPosition->id == 2? 'selected="selected"' : '' }} value="{{$eachPosition->id}}">{{$eachPosition->position}}</option>
                                                        @endforeach
                                                    </select>

                                                @if ($errors->has('additional_responsibility[]'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('additional_responsibility[]') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Staff Class') }}</label>
                                                <select id="staffclass" class="form-control {{ $errors->has('staffclass') ? ' is-invalid' : '' }} " name="staffclass" required>
                                                    <option selected="selected" >Select Staff Class</option>
                                                    <option value="AS">Academic Staff</option>
                                                    <option value="NA">Non-Academic Staff</option>
                                                </select>

                                                @if($errors->has('staffclass'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('staffclass') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div id="salaryscale___parent" class="col-sm-3 col-md-3">
                                            <div id="salaryscale" class="form-group">
                                                <label id="con_label">{{ __('Salary Scale') }}</label>
                                                <select id="salaryscale_select" class="form-control {{ $errors->has('salaryscale') ? ' is-invalid' : '' }} " name="salaryscale" required>
                                                    <option value="">Select Salary Scale...</option>
                                                    @foreach($salaryscale as $eachSalaryScale)
                                                        <option {{old('salaryscale')==$eachSalaryScale->id? 'selected="selected"' : ''}} value="{{$eachSalaryScale->id}}" >{{$eachSalaryScale->salaryscale}}</option>
                                                    @endforeach

                                                </select>
                                                @if ($errors->has('salaryscale'))
                                                    <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('salaryscale') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div id="salaryscalevalue___parent" class="col-sm-3 col-md-3">
                                            <div id="salaryscalevalue" class="form-group">
                                                <label id="con_label">{{ __('Salary Scale Value') }}</label>
                                                <select id="salaryscalevalue_select" class="form-control {{ $errors->has('salaryscalevalue') ? ' is-invalid' : '' }} " name="salaryscalevalue" required>
                                                    <option value="">Select Salary Scale Value ...</option>

                                                </select>
                                                @if ($errors->has('salaryscalevalue'))
                                                    <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('salaryscalevalue') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div id="con___parent" class="col-sm-3 col-md-3">
                                            <div id="conpcass" class="form-group">
                                                <label id="con_label">{{ __('CONPCASS') }}</label>
                                                <select class="form-control {{ $errors->has('con___') ? ' is-invalid' : '' }} " name="con___" required>

                                                    @for ($i = 1; $i < 10; $i++)
                                                        <option {{old('con___')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>
                                                @if ($errors->has('con___'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('con___') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Category') }}</label>
                                                <select class="form-control {{ $errors->has('category') ? ' is-invalid' : '' }} " name="category" required>
                                                    <option {{old('category') =="JS"? 'selected="selected"' : ''}} value="JS" >Junior Staff</option>
                                                    <option {{old('category')=="SS"? 'selected="selected"' : ''}} value="SS" >Senior Staff</option>
                                                </select>

                                                @if($errors->has('category'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('category') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Rank') }}</label>
                                                <select id="rank" class="form-control {{ $errors->has('rank') ? ' is-invalid' : '' }} " name="rank" required>
                                                        <option value="">Select Staff Rank</option>

                                                </select>
                                                @if ($errors->has('rank'))
                                                    <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('rank') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Step') }}</label>

                                                    <select class="form-control {{ $errors->has('step') ? ' is-invalid' : '' }} " name="step" required>

                                                    @for ($i = 1; $i <= 50; $i++)
                                                        <option {{old('step')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>

                                                @if ($errors->has('step'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('step') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>



                                    </div>
                                    <div class="row">

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label>{{ __('Status') }}</label>
                                                <select class="form-control {{ $errors->has('status') ? ' is-invalid' : '' }} " name="status" required>
                                                    @foreach($status as $eachStatus)
                                                        <option value="{{$eachStatus->id}}">{{$eachStatus->status}}</option>
                                                    @endforeach
                                                </select>

                                                @if($errors->has('status'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('status') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend class="title">Qualification</legend>
                                            <div class="row">
                                                <div class="col-sm-1 col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select name="qualificationtype[]" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option value="OND">OND</option>
                                                            <option value="HND">HND</option>
                                                            <option value="DEG">Degree</option>
                                                            <option value="PGD">PGD</option>
                                                            <option value="MSC">MSC</option>
                                                            <option value="PHD">PHD</option>
                                                            <option value="OTHERS">Others</option>
                                                        </select>
                                                        @if ($errors->has('qualificationtitle[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtitle[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-sm-3 col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input name="qualificationtitle[]" type="text" class="form-control" placeholder="Qualification Title" value="{{ old('qualificationtitle[]') }}"  required="required" >
                                                        @if ($errors->has('qualificationtitle[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtitle[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input name="qualificationdesc[]" type="text" class="form-control" placeholder="Qualification Description" value="{{ old('qualificationdesc[]') }}"  required="required" >
                                                        @if ($errors->has('qualificationdesc[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationdesc[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea cols="" required="required" name="registeredprobody[]" class="form-control" placeholder="Registered Professional Body" >{{ old('registeredprobody[]', "NONE") }}</textarea>
                                                        @if ($errors->has('registeredprobody[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('registeredprobody[]') }}</strong>
                                                                </span>
                                                        @endif

                                                        <input type="hidden" name="qualificationcount[]" value="1" >
                                                    </div>
                                                </div>

                                            </div>
                                            <hr style="border: 1px solid grey;" />

                                        </fieldset>
                                    </div>

                                    <button id="add_qualification" type="button" class="btn btn-info btn-fill pull-left">Add Another Qualification</button>
                                    <button id="btnsubmit" type="submit" class="btn btn-success btn-fill pull-right">Add New Staff</button>
                                    <div class="clearfix"></div>
                                </form>

                                <div id="conpcass" class="form-group hidden">
                                                <label id="con_label">{{ __('CONPCASS') }}</label>
                                                <select class="form-control {{ $errors->has('con___') ? ' is-invalid' : '' }} " name="con___" required>

                                                    @for ($i = 1; $i < 10; $i++)
                                                        <option {{old('con___')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>
                                                @if ($errors->has('con___'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('con___') }}</strong>
                                                        </span>
                                                @endif
                                </div>
                                <div id="contediss" class="form-group hidden">
                                                <label id="con_label">{{ __('CONTEDISS') }}</label>
                                                <select class="form-control {{ $errors->has('con___') ? ' is-invalid' : '' }} " name="con___" required>

                                                    @for ($i = 1; $i < 16; $i++)
                                                        <option {{old('con___')=="$i"? 'selected="selected"' : ''}} value="{{$i}}" >{{$i}}</option>
                                                    @endfor

                                                </select>
                                                @if ($errors->has('con___'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('con___') }}</strong>
                                                        </span>
                                                @endif
                                 </div>

                                 <div id="qualificationformcontrols" class="qualificationformcontrols hidden">
                                    <div class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select name="qualificationtype[]" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option value="OND">OND</option>
                                                            <option value="HND">HND</option>
                                                            <option value="DEG">Degree</option>
                                                            <option value="PGD">PGD</option>
                                                            <option value="MSC">MSC</option>
                                                            <option value="PHD">PHD</option>
                                                            <option value="OTHERS">Others</option>
                                                        </select>
                                                        @if ($errors->has('qualificationtype[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtype[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input required="required" name="qualificationtitle[]" type="text" class="form-control" placeholder="Qualification Title" value="{{ old('qualificationtitle[]') }}">
                                                        @if ($errors->has('qualificationtitle[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationtitle[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input required="required" name="qualificationdesc[]" type="text" class="form-control" placeholder="Qualification Description" value="{{ old('qualificationdesc[]') }}"  required="required" >
                                                        @if ($errors->has('qualificationdesc[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('qualificationdesc[]') }}</strong>
                                                                </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea required="required" name="registeredprobody[]" class="form-control" placeholder="Registered Professional Body" >{{ old('registeredprobody[]', "NONE") }}</textarea>
                                                        @if ($errors->has('registeredprobody[]'))
                                                                <span class="has-error invalid-feedback">
                                                                    <strong>{{ $errors->first('registeredprobody[]') }}</strong>
                                                                </span>
                                                        @endif

                                                        <input type="hidden" name="qualificationcount[]" value="1" >
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <button onclick="this.parentNode.parentNode.remove()" type="button" class="btn-sm btn-danger pull-right btn removebtn">Remove</button>
                                                </div>
                                                <div class="col-md-12" style="padding-top: 1px; padding-left: 1px;">
                                                <hr style="border: 1px solid grey;">
                                                </div>
                                            </div>
                                 </div>


                            </div>
                        </div>
                    </div>

                </div>


                </div>
@include('includes.dashboardfooter')
