@include("includes.header")

<section class="login p-fixed d-flex text-center bg-primary common-img-bg">
    <!-- Container-fluid starts -->
    <div class="container-fluid">
        @yield('content')
    </div>
    <!-- end of container-fluid -->
</section>
@include('includes.footer')