<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use \App\Position;

class AdditionalResponsibility extends Model
{
    protected $fillable = [ 'promotion_id', 'staff_id', 'position' ];

    public function getPosition(){
        return Position::find($this->position);
    }

    public static function getStaffAdditionalResponsibilities(int $promotion_id) : array {

        $positions = array();
        $staffsAdditionalResponsibilities = AdditionalResponsibility::where('promotion_id', $promotion_id)->get()->all();

        foreach ($staffsAdditionalResponsibilities as $eachResponsibilities) {
            $positions[] = $eachResponsibilities->getPosition();
        }

        return $positions;
    }

    public static function getStaffAddedResponsibilitiesArray(int $promotion_id) : array{
        $intArrays = [];
        $addedRespArray =  AdditionalResponsibility::getStaffAdditionalResponsibilities($promotion_id);
        foreach ($addedRespArray as $eachRes) {
            $intArrays[] = $eachRes->id;
        }
        return $intArrays;
    }

}
