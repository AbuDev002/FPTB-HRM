<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Leave extends Model
{
    protected $table = "leave";
    protected $fillable = ['from', 'to', 'staff_id', 'status', 'description', 'range_type'];

    public const ACTIVE = 1;
    public const INACTIVE = 2;

    public const RANGE_TWO = 2;
    public const RANGE_ONE = 1;


}
