<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class DepartmentUnit extends Model
{

		protected $fillable = ['department_id', 'unit'];

    public function getDepartment()
    {
    	$department = Department::find($this->department_id);
    	return $department;
    }

}