<?php 
	namespace App\MyClasses;

	// use App\PromotionGradeLevelsSteps;
	use App\SalaryScaleStepPromotionModel;
	use App\Staff;
	use App\Promotions;
	use App\RankPromotionModel;
	use App\SalaryScale;

	/**
	 * This is a Promotion Class To Handle A Single Staff Promotion
	 */
	class PromotionHandler
	{

		private $thisStaffId;
		private $thisStaff;
		private $thisStaffPFN;

		public function __construct($thisStaff_Pfn)
		{
			dump("STAFFNO: $thisStaff_Pfn");
			$this->thisStaff = Staff::Where('staffno', $thisStaff_Pfn)->first();
			$this->thisStaffId = $this->thisStaff->id;
			$this->thisStaffPFN = $thisStaff_Pfn;
		}

		private function getNextPromotion($salaryscale, $scale_value, $step){

    	$current_grade_level = "$scale_value/$step";

    	dump($current_grade_level, $salaryscale);

    	$thisSalaryScaleSPModel = SalaryScaleStepPromotionModel::where('oldgrade', $current_grade_level)
    		->where('salaryscale', $salaryscale)->first();
    		
    		if(is_null($thisSalaryScaleSPModel)){
    			dump("THIS SALARYSCALE DOESN'T EXISTS");
    			return null;
    		}

    		// dump($thisSalaryScaleSPModel->newgrade); die("OK");
    		$outcomeArray =  explode('/', $thisSalaryScaleSPModel->newgrade );
    		return ['salaryscale' => $salaryscale, 'salaryscale_value'=>$outcomeArray[0], 'step' => $outcomeArray[1] ];
    }

    private function getNextRank($salaryscale, $old_rank){

    		$thisRankPromotionModel = RankPromotionModel::where('salaryscale', $salaryscale)->where('old_rank', $old_rank)->first();

    		// var_dump("SALARYSCALE: $salaryscale, OLD_RANK: $old_rank");
    		// dump("FUNC_ARGS: ", func_get_args());
    		// dump($thisRankPromotionModel);
    		// dd("OK");

    		if(is_null($thisRankPromotionModel)) return null;

    		return ['new_rank' => $thisRankPromotionModel->new_rank, 'salaryscale'=>$salaryscale ];
    }

    public function updateStaffPromotion($salaryscale, $SalaryScaleValue, $step){
    		
    		$thisStaff_CurrentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $this->thisStaff->id)->get()->first();

				$thisSalaryScale = SalaryScale::where('salaryscale', $salaryscale)->get()->first();
				
				$newSalaryScale = $thisSalaryScale->id;
				$newSalaryScaleValue = $SalaryScaleValue;
				$newStep = $step;

        //update and save
				$thisStaff_CurrentPromotion->salary_scale = $newSalaryScale;
				$thisStaff_CurrentPromotion->salary_scale_value = $newSalaryScaleValue;
				$thisStaff_CurrentPromotion->con___ = $newSalaryScaleValue;
				$thisStaff_CurrentPromotion->step = $newStep;
           
				$thisStaff_CurrentPromotion->save();

				dump("COMPLETED");

    }

    public function incrementStep()
    {
    		$thisStaff_CurrentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $this->thisStaff->id)->get()->first();

            // copy the model of the current promotion
            $newStaffPromotion = $thisStaff_CurrentPromotion->replicate();

            //update and save
            $newStaffPromotion->step = ( $newStaffPromotion->step + 1 );
						
            $newStaffPromotion->save();
            
            $newStaffPromotion->staff_id = $staff_id;
            $newStaffPromotion->save();

            $thisStaff_CurrentPromotion->promotion_indicator = Promotions::$PAST_PROMOTION;
            $thisStaff_CurrentPromotion->save();
    }

    public function promoteStaff()
    {
    		$thisStaff_CurrentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $this->thisStaff->id)->get()->first();

            // copy the model of the current promotion
            $newStaffPromotion = $thisStaff_CurrentPromotion->replicate();

            $salaryScaleValueRankStep = $this->getNextPromotion(
            																									$newStaffPromotion->salary_scale, 
            																									$newStaffPromotion->salary_scale_value, 
            																									$newStaffPromotion->step);

            $newPromotionRank = $this->getNextRank(
																				$newStaffPromotion->salary_scale, 
																				$newStaffPromotion->rank);

            //update and save
            if(!empty($salaryScaleValueRankStep)){

	            $newStaffPromotion->step = $salaryScaleValueRankStep['step'];
	            $newStaffPromotion->salary_scale = $salaryScaleValueRankStep['salaryscale'];
	            $newStaffPromotion->salary_scale_value = $salaryScaleValueRankStep['salaryscale_value'];
	          }

	          if(!empty($newPromotionRank)){
	            $newStaffPromotion->rank = $newPromotionRank['new_rank'];
	          }
						
            $newStaffPromotion->save();

            $thisStaff_CurrentPromotion->promotion_indicator = Promotions::$PAST_PROMOTION;
            $thisStaff_CurrentPromotion->save();
				dump("COMPLETED");
    }

	}
 ?>