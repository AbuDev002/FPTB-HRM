<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Department;

class StaffDepartment extends Model
{
    protected $table="staff_department";
    protected $fillable=['staff_id', 'dept_id', 'school', 'status'];

    public static $STATUS_CURRENT = 1;
    public static $STATUS_PAST = 2;

    public function getDepartment(bool $show_full = true)
    {
    	return Department::find($this->dept_id)->getDepartment($show_full);
    }

    public function getSchool()
    {
    	return School::find($this->school)->school;
    }

    public static function getCurrentStaffDepartment($staffid)
    {
    	return StaffDepartment::where('status', self::$STATUS_CURRENT)->where('staff_id', $staffid)->get()->first();
    }
    public static function getStaffDepartmentHistory($staffid)
    {
    	return StaffDepartment::where('staff_id', $staffid)->orderBy('created_at', 'desc')->get()->all();
    }
}
