<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RankPromotionModel extends Model
{
    protected $table = 'rank_promotional_model';

    protected $fillable = ['salaryscale', 'old_rank', 'new_rank' ];

    public function getSalaryScale()
    {
    	return SalaryScale::find($this->salaryscale)->salaryscale;
    }

    public function getOldRank()
    {
    	return Rank::find($this->old_rank)->rank;
    }

    public function getNewRank()
    {
    	return Rank::find($this->new_rank)->rank;
    }
    
}
