<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppointmentType extends Model
{
    protected $fillable = ['description', 'appointmenttype'];

    public function getAppointmentType($full = false) : string
    {
    	if($full)
    		return ($this->appointmenttype . " " . $this->description);
    	else
    		return ($this->appointmenttype);
    }
}
