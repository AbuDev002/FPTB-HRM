<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * This StaffExtras Represents the Qualification Of the Staff 
 * which is an extra information that could be added multiple times
 */
class StaffExtras extends Model
{
    protected $fillable = ['staff_id', 'title', 'created_at', 'updated_at', 'description', 'registeredprobody', 'qualificationtype', 'status'];

    // 1 - means approved automatically, 2 - accepted but yet to formalize it, 3 - proposed by staff
                // 4 - rejected
    public static $APPROVED_QUALIFICATION_STATUS = 1;
    public static $ACCEPTED_QUALIFICATION_STATUS = 2;
    public static $PROPOSED_QUALIFICATION_STATUS = 3;
    public static $REJECTED_QUALIFICATION_STATUS = 4;

}
