<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CondolenceMessage extends Model
{
    protected $fillable = ['staff_id', 'condolence'];
    
}
