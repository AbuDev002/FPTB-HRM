<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoginHistory extends Model
{
    protected $table="login_history";

    protected $fillable=[ 'user_id', 'admin_id', 'type', 'session_id', 'user_status', 'username', 'ip', 'browser', 'platform' ];

    public static $LOGIN_TYPE = 1;
    public static $LOGOUT_TYPE = 2;
    public static $LOGIN_ATTEMPT = 3;
    

}
