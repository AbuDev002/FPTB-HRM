<?php

namespace App\Http\Controllers;

use App\Zone;
use Illuminate\Http\Request;

class ZoneController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');//->except('logout');
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
            return redirect('home');
        }

        return redirect('zone/create');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
            return redirect('home');
        }

        return view('zone/addnewzone')->with('zone', Zone::all());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $request->validate([
            'gpzone' => 'required',
            'description' => 'present'
        ]);

        /*Zone::create([
            'gpzone' => $request->input('gpzone'), 
            'description' => $request->input('description')
        ]);*/
        $request->session()->flash('status', 'All Zones Have Already Been Created Successfully!');
        return redirect('zone/create');
        // return redirect('zone/create')->with('status', 'All Zones Have Already Been Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param \App\Zone $zone
     * @return \Illuminate\Http\Response
     */
    public function show(Zone $zone)
    {
        if($this->isNew()==true) return $this->actNew();

        $aZone = Zone::findOrFail($zone);

        $action = isset($_GET['action']) ? ($_GET['action'] == 'del'? 'delete' : 'show') : 'show';

        return view('zone/addnewzone')->with('zone', $aZone )
            ->with('displaystate', $action);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Zone $zone
     * @return \Illuminate\Http\Response
     */
    public function edit(Zone $zone)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $aZone = Zone::findOrFail($zone);
        return view('zone/addnewzone')->with('zone', $aZone )
            ->with('displaystate', 'edit');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param \App\Zone $zone
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Zone $zone)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $request->validate([
            'gpzone' => 'required',
            'description' => 'present'
        ]);



        $thisZone = Zone::findOrFail($zone)->first();

        $thisZone->description = $request->input('description') == null? "":$request->input('description');
        $thisZone->gpzone = $request->input('gpzone');
        $thisZone->save();

        return redirect('zone/'.$thisZone->id)->with('status', 'Zone Updated Successfully');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Zone $zone
     * @return \Illuminate\Http\Response
     */
    public function destroy(Zone $zone)
    {
        if($this->isNew()==true) return $this->actNew();
        
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        // $zone->delete();
        return redirect('zone/create')->with('status', 'Zone At The Moment Cannot Be Deleted');
    }
}
