<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SalaryScale;
use App\SalaryScaleStepPromotionModel;

class StaffSalaryStructureController extends Controller
{

		public function __construct()
		{
			$this->middleware('auth');
		}

		public function create(Request $request)
		{
			       return redirect('salary_structure_setting');
		}

		/**
		 * [Index to showSalaryStructureForm description]
		 * @param  Request $request [description]
		 * @return [type]           [description]
		 */
    public function index(Request $request)
    {

    	if($this->isNew()==true) return $this->actNew();

      if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
         return redirect('home');
      }

      $salaryscale_with_steps = SalaryScaleStepPromotionModel::all();

    	return view('settings.salarypromotionform', ['salaryscale' => SalaryScale::all(), 'salaryscalestructure_with_steps' => $salaryscale_with_steps]);
    }

    /**
		 * [store the showSalaryStructureForm description]
		 * @param  Request $request [description]
		 * @return [type]           [description]
		 */
    public function store(Request $request)
    {

    	if($this->isNew()==true) return $this->actNew();

      if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
         return redirect('home');
      }

      $request->validate([
      	'salaryscale' => 'integer|required',
      	'oldgrade' => 'string|required',
      	'newgrade' => 'string|required'
      ]);

      $oldgrade = $request->input('oldgrade');
      $newgrade = $request->input('newgrade');
      $salaryscale = $request->input('salaryscale');

      try {
	      $salaryScaleStepPM = SalaryScaleStepPromotionModel::create([
	      	'salaryscale' => $salaryscale,
	      	'oldgrade' => $oldgrade,
	      	'newgrade' => $newgrade
	      ]);
      	
      }catch (\Exception $e) {
				return redirect('salary_structure_setting')->with('status', 'Salary Scale With This Old-Grade Already Exists');
      }


      return redirect('salary_structure_setting')->with('status', 'Successfully Added New Grade Level / Steps');

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $salaryScaleStepPromotionId
     * @return \Illuminate\Http\Response
     */
    public function edit(int $salaryScaleStepPromotionId)
    {

        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $thisSalaryScaleSPId = SalaryScaleStepPromotionModel::findOrFail($salaryScaleStepPromotionId);

        $salaryscale_with_steps = SalaryScaleStepPromotionModel::all();

        return view('settings.salarypromotionform', ['salaryscale' => SalaryScale::all(), 'this_salaryscaleSPId' => $thisSalaryScaleSPId, 'salaryscalestructure_with_steps' => $salaryscale_with_steps])
            ->with('displaystate', 'edit');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $salaryScaleStepPromotionId
     * @return \Illuminate\Http\Response
     */
    public function show(int $salaryScaleStepPromotionId)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $thisSalaryScaleSPId = SalaryScaleStepPromotionModel::findOrFail($salaryScaleStepPromotionId);

        $salaryscale_with_steps = SalaryScaleStepPromotionModel::all();

        $action = isset($_GET['action']) ? ($_GET['action'] == 'del'? 'delete' : 'show') : 'show';

        return view('settings.salarypromotionform', ['salaryscale' => SalaryScale::all(), 'this_salaryscaleSPId' => $thisSalaryScaleSPId, 'salaryscalestructure_with_steps' => $salaryscale_with_steps])
            ->with('displaystate', $action);
    }
    

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int $staffSalaryStructureScaleId
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, int $staffSalaryStructureScaleId)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $request->validate([
            'salaryscale' => 'required|integer|min:1',
            'oldgrade' => 'required',
            'newgrade' => 'required'
        ]);

        $oldgrade = $request->input('oldgrade');
        $newgrade = $request->input('newgrade');
        $salaryscale_id = $request->input('salaryscale');

        $thisSalaryScale = SalaryScale::findOrFail($salaryscale_id);
        $thisSalaryScaleStepPromotionModel = SalaryScaleStepPromotionModel::findOrFail($staffSalaryStructureScaleId);

        $anyOtherSalaryScale = SalaryScaleStepPromotionModel::where('salaryscale', $salaryscale_id)->where('oldgrade', $oldgrade)->first();

        $updateModel = false;

        if(is_null($anyOtherSalaryScale)){
        	$updateModel = true;
        }elseif($anyOtherSalaryScale->id == $thisSalaryScaleStepPromotionModel->id){
        	$updateModel = true;
        }

        if($updateModel){
        	$thisSalaryScaleStepPromotionModel->oldgrade = $oldgrade;
        	$thisSalaryScaleStepPromotionModel->newgrade = $newgrade;
        	$thisSalaryScaleStepPromotionModel->salaryscale = $salaryscale_id;
        	$thisSalaryScaleStepPromotionModel->save();
        }

        return redirect('salary_structure_setting/'.$staffSalaryStructureScaleId)->with('salaryscale', "Salary Scale Step Promotional Rules Updated Successfully");
    }

    /**
     * [showRankingSettingsForm description]
     * @param  Request $request [description]
     * @return [type]           [description]
     */
    public function showRankingSettingsForm(Request $request)
    {
    	return view('settings.rankpromotionform');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $staffSalaryStructureScaleId
     * @return \Illuminate\Http\Response
     */
    public function destroy(int $staffSalaryStructureScaleId)
    {
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $thisSalaryScaleStepPromotionModel = SalaryScaleStepPromotionModel::findOrFail($staffSalaryStructureScaleId);

        $thisSalaryScaleStepPromotionModel->delete();

        return redirect('salary_structure_setting')->with('salaryscale', "Staff Salary Scale Structure Deleted Successfully");
    }
}
