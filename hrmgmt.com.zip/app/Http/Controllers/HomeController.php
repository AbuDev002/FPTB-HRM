<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Staff;
use App\Department;
use App\State;
use App\Zone;
use App\Position;
use App\Level;
use App\Rank;
use App\AppointmentType;
use App\Status;
use App\Lga;
use App\StaffDepartment;
use App\Promotions;
use App\StaffExtras;
use App\User;
use DB;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth')->except('showHomePage');
        if($this->isNew()==true) return $this->actNew();
    }

    public function showHomePage()
    {
        if(Auth::check()){
            return redirect('home');
        }
        return view('welcomeindex');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if($this->isNew()==true) return $this->actNew();

        if(Auth::user()->access_level == Staff::$USER_STAFF){
            return redirect('staffhome');
        }

        $sessionsLast = DB::table('sessions')->select('id', 'user_id', 'ip_address', 'user_agent', 'payload', 'last_activity')->where('user_id', '!=', null)->get()->all();

        return view('homedashboard')->with('sessionlast', $sessionsLast);
    }




    public function getStaffHome(Request $request)
    {

        if($this->isNew()==true) return $this->actNew();

        if(Auth::user()->access_level < Staff::$USER_STAFF){
            return redirect('home');
        }


        $deparment = Department::where('is_currently_active', 1)->get()->all();
        $level = Level::all();
        $state = State::all();
        $appointmenttype = AppointmentType::all();
        $rank = Rank::all();
        $status = Status::all();
        $gpzone = Zone::all();
        $position = Position::all();


        $thisStaff = Staff::where('staffno', Auth::user()->username)->get()->first();

        $lga = Lga::find($thisStaff->lga_id);

        $staffDept = StaffDepartment::where('staff_id', $thisStaff->id )->get();

        $promotions = Promotions::where('staff_id', $thisStaff->id)->where('status', 1)->get()->first();

        $staffExtras = StaffExtras::where('staff_id', $thisStaff->id)->where('status', StaffExtras::$APPROVED_QUALIFICATION_STATUS)->get();

        return view('staffhomedashboard', ['department'=>$deparment, 'level' => $level, 'state' => $state, 'appointmenttype'=> $appointmenttype,  'rank'=> $rank, 'status' => $status, 'gpzone' => $gpzone, 'position' => $position , 'staff' => $thisStaff, 'lga' => $lga, 'staffDept' => $staffDept , 'staffExtras' => $staffExtras, 'promotions' => $promotions] );

    }

    /**
     * Show users Online
     *
     * @return \Illuminate\Http\Response
     */
    public function getOnlineActiveUsers(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

         if(Auth::user()->access_level != Staff::$USER_ADMIN){
            return redirect('home');
        }

        $deparment = Department::where('is_currently_active', 1)->get()->all();
        $level = Level::all();
        $state = State::all();
        $appointmenttype = AppointmentType::all();
        $rank = Rank::all();
        $status = Status::all();
        $gpzone = Zone::all();
        $position = Position::all();
        $users = User::all();

        $loginHistory = \App\LoginHistory::where('user_id', Auth::id())->where('created_at', '>=', \Carbon\Carbon::now()->subMonth())->get()->all();

        $sessionsLast = DB::table('sessions')->select('id', 'user_id', 'ip_address', 'user_agent', 'payload', 'last_activity')->where('user_id', '!=', null)->get()->all();

        return view('profile/manageusers', ['department'=>$deparment, 'level' => $level, 'state' => $state, 'appointmenttype'=> $appointmenttype,  'rank'=> $rank, 'status' => $status, 'gpzone' => $gpzone, 'position' => $position, 'loginHistory' => $loginHistory, 'sessionlast' => $sessionsLast, 'users' => $users ]);
    }

    public function changeUserStatus(Request $request)
    {

        if($this->isNew()==true) return $this->actNew();

        if(Auth::user()->access_level != Staff::$USER_ADMIN){
            echo "error";
            return;
        }

        $user_id = $request->input('user_id');
        $action = $request->input('u_a');
        
        if($action == 'enable'){
            $aUser = \App\User::find($user_id);
            if(is_null($aUser))
                echo "error";
            else{

                if($aUser->status == \App\User::$USER_ACCOUNT_STATUS_DISABLED){
                    if($aUser->access_level != 1){
                        $aUser->status = \App\User::$USER_ACCOUNT_STATUS_ENABLED;
                        $aUser->save();
                        echo "success";
                    }else{
                        echo "error";
                    }
                }else{
                    echo "error";
                }
            }
            return;

        }elseif ($action == 'disable') {
            $aUser = \App\User::find($user_id);
            if(is_null($aUser))
                echo "error";
            else{
                if($aUser->status == \App\User::$USER_ACCOUNT_STATUS_ENABLED){
                    if($aUser->access_level != 1){
                        $aUser->status = \App\User::$USER_ACCOUNT_STATUS_DISABLED;
                        $aUser->save();
                        echo "success";
                    }else{
                        echo "error";
                    }
                }else{
                    echo "error";
                }
            }
            return;
        }elseif ($action == 'reset') {
            $aUser = \App\User::find($user_id);
            if(is_null($aUser))
                echo "error";
            else{
                if($aUser->access_level != 1){
                        $aUser->password = bcrypt('password');
                        $requestResetOnLogin = \App\FirstTimeLoginResetModel::setPasswordUpdateRequired($aUser->id);
                        $aUser->save();
                        echo "success";
                }else{
                    $aUser->password = bcrypt('secretpassword');
                    $requestResetOnLogin = \App\FirstTimeLoginResetModel::setPasswordUpdateRequired($aUser->id);
                    $aUser->save();
                    echo "success";
                }
            }
            return;
        }else{
            echo "error";
            return;
        }
    }

    public function logUserOut(Request $request)
    {
        $user_c = $request->input('loguserout');
        $thisUser = \App\User::find($user_c);

        if(Auth::user()->access_level != Staff::$USER_ADMIN){
            return redirect("home");
        }

        if(is_null($thisUser)){
            return redirect("home");
        }else{
            $thisUser->logout($request);
        }

        return redirect("useronline");
    }

    public function createUserAccount(Request $request)
    {

        $request->validate([
            'fullname' => 'string|required|min:2',
            'username' => 'required|unique:users',
            'email' => 'required|email|unique:users',
            'newpassword' => 'required|min:5',
            'confirmnewpassword' => 'required|same:newpassword',
            'photo' => 'file|required'
        ]);

        // default subamdmin

        $fullname = $request->input('fullname');
        $username = $request->input('username');
        $password = $request->input('password');
        $email = $request->input('email');

        $photoPath = "";

        if($request->hasFile('photo')){

            if($request->file('photo')->isValid()){
               $photoPath = $request->photo->store('public');
            }
        
            if(!is_file(public_path(\Storage::url($photoPath)))){
                $photoPath = empty($photoPath)?? $photoPath;
            }

       }

        $thisUser = \App\User::create([
            'name' => $fullname,
            'email' => $email,
            'password' => bcrypt($password),
            'username' => $username,
            'access_level' => \App\Staff::$USER_SUBADMIN,
            'photo' => $photoPath
        ]);
        
        $request->session()->flash('success', "SubAdmin User [$fullname] Created Successfully");
        return redirect('useronline');

    }


}
