<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Lga;
use App\Staff;
use App\Rank;
use App\Department;
use App\DepartmentUnit;

class UtilityController extends Controller
{
    public function getLga(Request $request)
    {
        $localGvtOptions = "<option value=''>Select Local Government</option>";
        $thisStateId = $request->input('stateid');
        $thisLga = Lga::where('stateid', $thisStateId)->get()->all();

        foreach ($thisLga as $eachLga)
            $localGvtOptions = $localGvtOptions ."<option value='{$eachLga->id}'>{$eachLga->lga}</option>";

        echo $localGvtOptions;
    }

    public function getDept(Request $request)
    {
        $deptOptions = "<option value=''>Select Department</option>";
        $thisSchoolId = $request->input('schoolid');
        $thisDept = Department::where('school', $thisSchoolId)->get()->all();

        foreach ($thisDept as $eachDept)
            $deptOptions = $deptOptions ."<option value='{$eachDept->id}'>{$eachDept->department} - {$eachDept->description}</option>";

        echo $deptOptions;
    }

    public function getDeptUnit(Request $request)
    {
        $deptUnitOptions = "<option value=''>Select Department Unit</option>";
        $thisDeptId = $request->input('deptid');
        $depttt = DepartmentUnit::all();

        $thisUnitDept = DepartmentUnit::where('department_id', $thisDeptId)->get()->all();

        foreach ($thisUnitDept as $eachDeptUnit)
            $deptUnitOptions = $deptUnitOptions ."<option value='{$eachDeptUnit->id}'>{$eachDeptUnit->unit}</option>";

        echo $deptUnitOptions;
    }



    public static function getUniqueTempEmailAddress(){

    	$uniqueTempEmail = md5(rand(23, 898989) . time());
    	$tempEmail = "fakemail_" . substr($uniqueTempEmail, rand(0, 5), 10) . time() . "@fptb.edu.ng";
    	return $tempEmail;
    }


    public function checkstaffno(Request $request)
    {
	    	$request->validate([
	    		'staffnovalue' => 'required|string'
	    	]);

	    	$num = Staff::where('staffno', $request->input('staffnovalue'))->count();
	    	if($num > 0){
	    		echo "NO";
	    	}else{
	    		echo "YES";
	    	}
    }

    public function checkstaffnoquickfind(Request $request)
    {
            $request->validate([
                'staffnovalue' => 'required|string'
            ]);

            $staff_reg_no = $request->input('staffnovalue');

            // $staffRecords = Staff::where('staffno', $staff_reg_no)->get();
            $staffRecords = Staff::where('staffno', 'like', "%$staff_reg_no%")->take(4)->get();
            if($staffRecords->count() > 0){
               ?>
               <table class="table table-bordered table-condensed table-hover table-striped" >
                   <thead>
                    <tr>
                      <th>Staff RegNo</th>
                      <th>Staff Name</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($staffRecords as $eachStaffRecord) {
                           
                        ?>
                        <tr>
                           <td><?php echo $eachStaffRecord->staffno; ?></td>
                           <td><?php echo $eachStaffRecord->getFullName(); ?></td>
                           <td><?php echo $eachStaffRecord->getDetails()['status']; ?></td>
                           <td>
                               <form onsubmit="return (confirm('Are you Sure That You Want To Delete This Record? Please Confirm.?'))" action="<?php echo url("staff/". $eachStaffRecord->id); ?>" >
                                                        <a class="btn btn-sm btn-primary " href="<?php echo url('staff/'.$eachStaffRecord->id.''); ?>">View</a>
                                                        <a class="btn btn-sm btn-info " href="<?php echo url('staff/'.$eachStaffRecord->id.'/edit'); ?>">Edit</a>
                                                        <button class="btn btn-sm btn-danger" href="<?php echo url('staff/'.$eachStaffRecord->id.'/delete'); ?>">Delete</button>

                                                    </form>
                           </td>
                        </tr>
                        <?php 
                            } 
                        ?>
                    </tbody>
                </table>

               <?php
            }else{
                echo "NO";
            }
    }
    
    public function searchByStaffNamesQuickSearch(Request $request)
    {
        $fullname = $request->input('fullname');

        if(empty($fullname)) return;

        $fullname_array = explode(' ', $fullname);
        $array_size = count($fullname_array);

        if($array_size <= 1){

            $firstname = $fullname_array[0];
            $lastname = '';
            $othername = '';

            $allStaffRetrieved = \DB::select("select * FROM `staff` WHERE ( fname like ? ) OR (lname like ? ) OR (oname like ? ) ORDER by id desc", ["%$firstname%", "%$firstname%", "%$firstname%" ]);

        }elseif($array_size <= 2){

            $firstname = $fullname_array[0];
            $lastname = $fullname_array[1];
            $othername = '';

            $allStaffRetrieved = \DB::select("select * FROM `staff` WHERE ( fname like ?  OR  fname like ? ) and (lname like ? OR lname like ? ) and (oname like ? OR oname like ? ) ORDER by id desc  LIMIT 5", ["$firstname%", "$lastname%", "$firstname%", "$lastname%", "$firstname%", "$lastname%" ]);
        }else{
            $firstname = $fullname_array[0];
            $lastname = $fullname_array[1];
            $othername = $fullname_array[2];

            $allStaffRetrieved = \DB::select("select * FROM `staff` WHERE ( fname like ?  OR  fname like ?  OR  fname like ? ) and (lname like ? OR lname like ? OR lname like ? ) and (oname like ? OR oname like ? OR oname like ? ) ORDER by id desc LIMIT 5", ["$firstname%", "$lastname%", "$othername%", "$firstname%", "$lastname%", "$othername%", "$firstname%", "$lastname%", "$othername%"]);
        }


        if(count($allStaffRetrieved) > 0){
               ?>
               <table class="table table-bordered table-condensed table-hover table-striped" >
                   <thead>
                    <tr>
                      <th>Staff RegNo</th>
                      <th>Staff Name</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($allStaffRetrieved as $aStaffRecord) {
                           $eachStaffRecord = Staff::find($aStaffRecord->id);
                        ?>
                        <tr>
                           <td><?php echo $eachStaffRecord->staffno; ?></td>
                           <td><?php echo $eachStaffRecord->getFullName(); ?></td>
                           <td><?php echo $eachStaffRecord->getDetails()['status']; ?></td>
                           <td>
                               <form onsubmit="return (confirm('Are you Sure That You Want To Delete This Record? Please Confirm.?'))" action="<?php echo url("staff/". $eachStaffRecord->id); ?>" >
                                                        <a class="btn btn-sm btn-primary " href="<?php echo url('staff/'.$eachStaffRecord->id.''); ?>">View</a>
                                                        <a class="btn btn-sm btn-info " href="<?php echo url('staff/'.$eachStaffRecord->id.'/edit'); ?>">Edit</a>
                                                        <button class="btn btn-sm btn-danger" href="<?php echo url('staff/'.$eachStaffRecord->id.'/delete'); ?>">Delete</button>

                                                    </form>
                           </td>
                        </tr>
                        <?php 
                            } 
                        ?>
                    </tbody>
                </table>

               <?php
            }else{
                echo "NO";
            }

    }

    public function getRank(Request $request)
    {
    		$request->validate([
	    		'staffclass' => 'required|string'
            ]);

	    	$staffClassRankOptions = "<option value=''>Select Staff Rank</option>";

            $staffClassRank = Rank::where('staffclass', $request->input('staffclass'))->get()->all();


	    	foreach ($staffClassRank as $eachRank) {
	    		$staffClassRankOptions = $staffClassRankOptions . "<option value='{$eachRank->id}'>{$eachRank->rank}</option>";
	    	}

	    	echo $staffClassRankOptions;
    }
}
