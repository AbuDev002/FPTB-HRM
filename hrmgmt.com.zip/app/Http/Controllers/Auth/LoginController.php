<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */


    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Show the admin login form
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function showAdminloginForm()
    {
        return view('auth.adminlogin');
    }

    /**
     * Handle a login request to the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response
     */
    public function login(Request $request)
    {

        $this->validateLogin($request);

        // If the class is using the ThrottlesLogins trait, we can automatically throttle
        // the login attempts for this application. We'll key this by the username and
        // the IP address of the client making these requests into this application.
        if ($this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);

            return $this->sendLockoutResponse($request);
        }

        if ($this->attemptLogin($request)) {
            return $this->sendLoginResponse($request);
        }

        // If the login attempt was unsuccessful we will increment the number of attempts
        // to login and redirect the user back to the login form. Of course, when this
        // user surpasses their maximum number of attempts they will get locked out.
        $this->incrementLoginAttempts($request);

        return $this->sendFailedLoginResponse($request);
    }


    /**
     * Validate the user login request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */
    protected function validateLogin(Request $request)
    {
        $this->validate($request, [
            $this->username() => 'required|string',
            'password' => 'required|string',
        ]);
    }


    /**
     * Attempt to log the user into the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
    protected function attemptLogin(Request $request)
    {

        $onlyEnabledUsers = \App\User::where($this->username(), $request->input($this->username()))
            ->where('status', \App\User::$USER_ACCOUNT_STATUS_ENABLED)->get()->first();

            $platformName = \Browser::platformName();
            $browserName = \Browser::browserName();

        if(is_null($onlyEnabledUsers)){
            $thisDisabledUser = \App\User::where($this->username(), $request->input($this->username()))->get()->first();

            if(!is_null($thisDisabledUser)){
                \App\LoginHistory::create([
                    'user_id' => $thisDisabledUser->id,
                    'admin_id' => null,
                    'type' => \App\LoginHistory::$LOGIN_ATTEMPT,
                    'user_status' => $thisDisabledUser->status,
                    'session_id' => session()->getId(),
                    'username' => $request->input($this->username()),
                    'browser' => $browserName,
                    'platform' => $platformName,
                    'ip' => $request->ip()
                ]);
            }

            return false;
        }

        if($onlyEnabledUsers->isOnline()['online']){
            \App\LoginHistory::create([
                'user_id' => $onlyEnabledUsers->id,
                'admin_id' => null,
                'type' => \App\LoginHistory::$LOGIN_ATTEMPT,
                'user_status' => $onlyEnabledUsers->status,
                'session_id' => session()->getId(),
                'username' => $request->input($this->username()),
                'browser' => $browserName,
                'platform' => $platformName,
                'ip' => $request->ip()
            ]);

            return false;
        }

        \App\LoginHistory::create([
                'user_id' => $onlyEnabledUsers->id,
                'admin_id' => null,
                'type' => \App\LoginHistory::$LOGIN_TYPE,
                'user_status' => $onlyEnabledUsers->status,
                'username' => $request->input($this->username()),
                'session_id' => session()->getId(),
                'browser' => $browserName,
                'platform' => $platformName,
                'ip' => $request->ip()
            ]);

        return $this->guard()->attempt(
            $this->credentials($request), $request->has('remember')
        );
    }


    /**
     * Log the user out of the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function logout(Request $request)
    {
        $platformName = \Browser::platformName();
        $browserName = \Browser::browserName();

        \App\LoginHistory::create([
                'user_id' => \Auth::user()->id,
                'admin_id' => null,
                'type' => \App\LoginHistory::$LOGOUT_TYPE,
                'user_status' => \Auth::user()->status,
                'username' => \Auth::user()->username,
                'session_id' => session()->getId(),
                'browser' => $browserName,
                'platform' => $platformName,
                'ip' => $request->ip()
            ]);

        $this->guard()->logout();

        $request->session()->invalidate();

        return redirect('/');
    }


    /**
     * Get the login username to be used by the controller.
     *
     * @return string
     */
    public function username()
    {
        return 'username';
    }


    /**
     * Get the needed authorization credentials from the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected function credentials(Request $request)
    {
        return $request->only($this->username(), 'password');
    }
}
