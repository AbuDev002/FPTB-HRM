<?php

namespace App\Http\Controllers;

use App\SalaryScale;
use App\User;
use App\AppointmentType;
use App\Rank;
use App\Staff;
use App\School;
use App\Department;
use App\Level;
use App\Promotions;
use App\StaffDepartment;
use App\DepartmentUnit;
use App\StaffUnitDepartment;
use App\StaffExtras;
use App\State;
use App\Lga;
use App\Status;
use App\Zone;
use App\Position;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\Storage;
use Log;
use Maatwebsite\Excel\Excel;
use PhpOffice\PhpSpreadsheet\Exception;
use DB;
use App\CondolenceMessage;
use App\AdditionalResponsibility;
use App\FirstTimeLoginResetModel;

class StaffController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');//->except('logout');

        if($this->isNew()==true) return $this->actNew();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

        if(Auth::user()->access_level == Staff::$USER_STAFF){
            return redirect('home');
        }

        $hide1 = $request->query('hide1');
        $hide2 = $request->query('hide2');

        $staff = Staff::all();

        return view('staff/viewstaff', [ 'staff' => $staff, 'display_type' => 'all', 'hide_columns' => [$hide1, $hide2] ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {

        if($this->isNew()==true) return $this->actNew();

        if(Auth::user()->access_level != Staff::$USER_ADMIN){
            return redirect('home');
        }

        $deparment = Department::where('is_currently_active', 1)->get()->all();
        $level = Level::all();
        $state = State::all();
        $appointmenttype = AppointmentType::all();
        $rank = Rank::all();
        $status = Status::all();
        $gpzone = Zone::all();
        $position = Position::all();
        $school = School::all();
        $salaryscale = SalaryScale::all();

        return view('addnewstaff', ['department'=>$deparment, 'level' => $level, 'state' => $state, 'appointmenttype'=> $appointmenttype,  'rank'=> $rank, 'status' => $status, 'gpzone' => $gpzone, 'position' => $position, 'school' => $school, 'salaryscale' => $salaryscale ]);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

        if(Auth::user()->access_level != Staff::$USER_ADMIN){
            return redirect('home');
        }

        // $additional_responsibilities = $request->input('additional_responsibility');

        // dump($additional_responsibilities);
        // dd($request->input());

        $request->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'othername' => 'present',
            'gender' => 'required',
            'staffno' => 'required|unique:staff',
            'email' => 'present',
            'address1' => 'present',
            // 'address2' => 'present',
            'dateobirth' => 'required|date',
            'department' => 'required|integer',
            'departmentunit' => 'required|integer',
//            'photo' => 'file',
            'phoneno' => 'required|unique:staff',
            'state' => 'required|integer',
            'school' => 'required|integer',
            'lga' => 'required|integer',
            'staffclass' => 'required',
            'maritalstatus' => 'required',
            'firstappointdate' => 'required|date',
            'appointmenttype' => 'required|integer',
            'position' => 'required|integer',
            'step'=> 'required|integer',
            'presentappointdate' => 'required|date',
            'rank' => 'required|integer',
            'category' => 'required',
            'status' => 'required|integer',
            'gpzone' => 'required|integer',
            'con___' => 'required|integer',
            'salaryscale' => 'required|integer',
            'salaryscalevalue' => 'required|integer',
            'qualificationtype' => 'required',
            'qualificationtitle' => 'required',
            'qualificationdesc' => 'required',
            'registeredprobody' => 'required',
            'qualificationcount' => 'required',
            'nokfname' => 'present',
            'noklname' => 'present',
            'nokoname' => 'present',
            'nokaddress' => 'present',
            'nokphoneno' => 'present',
            'nokrelationship' => 'present',
            'nameofchild1' => '',
            'ageofchild1' => 'required_with:nameofchild1',
            'nameofchild2' => '',
            'ageofchild2' => 'required_with:nameofchild2',
            'nameofchild3' => '',
            'ageofchild3' => 'required_with:nameofchild3',
            'nameofchild4' => '',
            'ageofchild4' => 'required_with:nameofchild4',
        ]);

        Log::info('CREATEING NEW STAFF');

       if($request->hasFile('photo')){
         if($request->file('photo')->isValid()){
            $photoPath = $request->photo->store('public');
         }
       }

       $photoPath = empty($photoPath)? " " : $photoPath;
       $email = empty($request->input('email'))? " " : $request->input('email');

       $newStaff = Staff::create([
        'fname' => $request->input('firstname'),
        'lname' => $request->input('lastname'),
        'oname' => $request->input('othername') ?? "",
        'email' => $email,
        'gender' => $request->input('gender'),
        'staffno' => $request->input('staffno'),
        'address1' => $request->input('address1'),
        'address2' => "",
        'dateobirth' => $request->input('dateobirth'),
        'status' => $request->input('status'),
        'photo' => $photoPath,
        'state_id' => $request->input('state'),
        'lga_id' => $request->input('lga'),
        'firstappointdate' => $request->input('firstappointdate'),
        'appointmenttype' => $request->input('appointmenttype'),
        'staffclass' => $request->input('staffclass'),
        'maritalstatus' => $request->input('maritalstatus'),
        'phoneno' => $request->input('phoneno') ?? "",
        'gpzone' => $request->input('gpzone'),
        'nok_fname' => $request->input('nokfname') ?? "",
        'nok_lname' => $request->input('noklname') ?? "",
        'nok_oname' => $request->input('nokoname') ?? "",
        'nok_address' => $request->input('nokaddress') ?? "",
        'nok_phoneno' => $request->input('nokphoneno') ?? "",
        'nok_relationship' => $request->input('nokrelationship') ?? "",
        'child1_name' => $request->input('nameofchild1') ?? "",
        'child1_age' => $request->input('ageofchild1') ?? 0,
        'child2_name' => $request->input('nameofchild2') ?? "",
        'child2_age' => $request->input('ageofchild2') ?? 0,
        'child3_name' => $request->input('nameofchild3') ?? "",
        'child3_age' => $request->input('ageofchild3') ?? 0,
        'child4_name' => $request->input('nameofchild4') ?? "",
        'child4_age' => $request->input('ageofchild4') ?? 0
       ]);

       /*Staff::truncate();
       Promotions::truncate();
       StaffDepartment::truncate();
       StaffExtras::truncate();

       User::truncate()*/


       $promotions = Promotions::create([
            'staff_id' => $newStaff->id,
            'promotion_date' => $request->input('presentappointdate'),
            'description' => "First Promotion  Indicator",
            'position' => $request->input('position'),
            'status' => Promotions::$APPROVED_PROMOTION,
            'staff_status' => $request->input('status'),
            'con___' => $request->input('con___'),
            'staffclass' => $request->input('staffclass'),
            'rank' => $request->input('rank'),
            'category' => $request->input('category'),
            'step' => $request->input('step'),
            'promotion_indicator' => Promotions::$CURRENT_PROMOTION,
            'presentappointdate' => $request->input('presentappointdate'),
            'appointmenttype' => $request->input('appointmenttype'),
            'salary_scale_value' => $request->input( 'salaryscalevalue'),
            'salary_scale' => $request->input('salaryscale')
       ]);

        $additional_responsibilities = $request->input('additional_responsibility');

        $additionalResponsibilities = [];

        foreach ($additional_responsibilities as $eachResponsibilitiesPosition) {
            $additionalResponsibilities[] = AdditionalResponsibility::create([
                'staff_id' => $newStaff->id,
                'position' => $eachResponsibilitiesPosition
            ]);
        }


       $staffDept = StaffDepartment::create([
            'staff_id' => $newStaff->id,
            'dept_id' => $request->input('department'),
            'school' => $request->input('school'),
            'status' => StaffDepartment::$STATUS_CURRENT // 1
       ]);

       $staffDeptUnit = StaffUnitDepartment::create([
            'staff_id' => $newStaff->id,
            'dept_id' => $request->input('department'),
            'unit_id' => $request->input('departmentunit'),
            'status' => StaffDepartment::$STATUS_CURRENT // 1
       ]);


       $qualificationtitle = $request->input('qualificationtitle');
       $qualificationtype = $request->input('qualificationtype');
       $qualificationdesc = $request->input('qualificationdesc');
       $registeredprobody = $request->input('registeredprobody');

       $qualificationcount = $request->input('qualificationcount');

       $staff_qualification_extras = [];

       for($i = 0; $i<count($qualificationcount); $i++){
           $staff_qualification_extras[] = StaffExtras::create([
                'staff_id' => $newStaff->id,
                'title' => $qualificationtitle[$i],
                'description' => $qualificationdesc[$i],
                'registeredprobody'  => $registeredprobody[$i],
                'qualificationtype' => $qualificationtype[$i],

                // 1 - means approved automatically, 2 - accepted but yet to formalize it, 3 - proposed by staff
                // 4 - rejected
                'status' => StaffExtras::$APPROVED_QUALIFICATION_STATUS
           ]);
       }

       if(empty(trim($email))){
            $email = UtilityController::getUniqueTempEmailAddress();
       }

       $addStaffToUser = User::create([
            'name' => ($request->input('firstname') . " " . $request->input('lastname') . " " . $request->input('othername')),
            'email' => $email, 'password' => bcrypt('password'), 'username' => $request->input('staffno'),
            'access_level' => Staff::$USER_STAFF,
            'status' => User::$USER_ACCOUNT_STATUS_ENABLED
       ]);

       return redirect('staff')->with('status', 'Successfully Added New Staff. View Staff Records');

    }


/**
 * [addCondolenceMessage description]
 * @param Request $request [description]
 */
    public function addCondolenceMessage(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

        if($request->ajax()){
            $condolence_comment = $request->input('condolence_comment');
            $staff_id = $request->input('staff_id');

            if(CondolenceMessage::where('staff_id', $staff_id)->count() > 0){

                $cond = CondolenceMessage::where('staff_id', $staff_id)->first();
                $cond->condolence = $condolence_comment;
                $cond->save();
            }else{
                $condolence_obj = CondolenceMessage::create([
                    'staff_id' => $staff_id,
                    'condolence_comment' => $condolence_comment
                ]);
            }

            return "success";
        }
        return redirect('home');
    }


    /**
     * [getProfile description]
     * @param  Request $request [description]
     * @return [type]           [description]
     */
    public function getProfile(Request $request)
    {
        $deparment = Department::where('is_currently_active', 1)->get()->all();
        $level = Level::all();
        $state = State::all();
        $appointmenttype = AppointmentType::all();
        $rank = Rank::all();
        $status = Status::all();
        $gpzone = Zone::all();
        $position = Position::all();

        $loginHistory = \App\LoginHistory::where('user_id', Auth::id())->where('created_at', '>=', \Carbon\Carbon::now()->subMonth())->orderBy('created_at', 'desc')->get()->all();

        return view('profile/manageprofile', ['department'=>$deparment, 'level' => $level, 'state' => $state, 'appointmenttype'=> $appointmenttype,  'rank'=> $rank, 'status' => $status, 'gpzone' => $gpzone, 'position' => $position, 'loginHistory' => $loginHistory ]);

    }

    /**
     * [getStaffInfo description]
     * @param  Request $request [description]
     * @return [type]           [description]
     */
    public function getStaffInfo(Request $request)
    {

        if($this->isNew()==true) return $this->actNew();

        if($request->isMethod('post')){
            return $this->getQualification($request);
        }

        if($request->isMethod('get')){

            if(Auth::user()->access_level != Staff::$USER_STAFF){
                return redirect('home');
            }
            //dd(Auth::user()->getStaffId());
            $thisStaff = Staff::findOrFail(Auth::user()->getStaffId());

        if(Auth::user()->access_level == Staff::$USER_STAFF){
            if(Auth::user()->username != $thisStaff->staffno)
                return redirect('home');
        }

        $staffPromotions = Promotions::where('staff_id', $thisStaff->id)->get();
        $staffDept = StaffDepartment::where('staff_id', $thisStaff->id)->get();
        $staffExtras = StaffExtras::where('staff_id', $thisStaff->id)->get()->all();
        $staffUserInfo = User::where('username', $thisStaff->staffno)->get();

        $all_staff = Staff::all();

        $level = Level::all();
        $state = State::all();
        $lga = Lga::where('stateid', $thisStaff->state_id)->get()->all();
        $appointmenttype = AppointmentType::all();
        $status = Status::all();
        $gpzone = Zone::all();
        $position = Position::all();
        $school = School::all();
        $staffDepartment = StaffDepartment::where('staff_id', $thisStaff->id)->where('status', StaffDepartment::$STATUS_CURRENT)->get()->first();
        $department = Department::where('school', $staffDepartment->school)->get()->all();
        $currentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $thisStaff->id)->get()->first();

        $rank = Rank::where('staffclass', $currentPromotion->staffclass )->get()->all();

        return view('profile/staffinfo', [ 'staff' => $all_staff, 'displayType' => 'show', 'thisStaff' => $thisStaff,
                                        'staffPromotions' => $staffPromotions, 'staffDept' => $staffDept,
                                        'staffExtras' => $staffExtras, 'staffUserInfo' => $staffUserInfo,
                                        'department'=>$department, 'level' => $level, 'state' => $state,
                                        'appointmenttype'=> $appointmenttype,  'rank'=> $rank, 'status' => $status,
                                        'gpzone' => $gpzone, 'position' => $position, 'school' => $school, 'lga' => $lga, 'staffdepartment' => $staffDepartment, 'currentPromotion' => $currentPromotion ]);

        }

    }

    /**
     * Get Staff Summary Report
     * @param  Request $request [description]
     * @return [type]           [description]
     */
    public function getStaffSummaryReport(Request $request){

        if($this->isNew()==true) return $this->actNew();

        if(Auth::user()->access_level == Staff::$USER_STAFF){
            return redirect('home');
        }

        $action = $request->query('act');

        switch($action){
            case 'inactive':
                $reverse_records = true;
            break;
            case 'active':
                $reverse_records = false;
            break;
            default:
                $reverse_records = false;
        }

        $department = Department::where('is_currently_active', 1)->get()->all();
        $status = Status::all();

        return view('reports.summaryreports', ['department'=>$department, 'status'=>$status, 'reverse_records'=>$reverse_records, 'typeact'=>$action]);
    }


    /**
     * [getStaffReports description]
     * @param  Request $request [server request object]
     * @return [view]           [managereport view]
     */
    public function getStaffReports(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

        if(Auth::user()->access_level == Staff::$USER_STAFF){
            return redirect('home');
        }

        $department = Department::where('is_currently_active', 1)->get();

        $status = Status::all();
        return view('reports.managereports', ['department'=>$department, 'status'=>$status]);
    }

    /**
     * get the Due Date with the difference with respect to todays date
     * @param  \Carbon\Carbon $datework
     * @return string                  
     */
    public static function getDueDate(\Carbon\Carbon $datework)
    {
        $now = \Carbon\Carbon::now();

        $dueDate = $datework->copy()->addYear(3);
        $dueDateString = $dueDate->toDateString();

        $dateDiff = $dueDate->diffForHumans($now);
        $toDateArray = explode(" ", $dateDiff);
        array_pop($toDateArray);
        $dateSinceWhen = implode($toDateArray, "");
        if($dueDate->gt($now)){
            echo $dueDateString . " Exactly " . $dateSinceWhen . ' From Now.';
        }else{
            echo $dueDateString . " Exactly " . $dateSinceWhen . ' Ago.';
        }
    }

    /**
     * [getPromotionList description]
     * @param  Request $request [server request object]
     * @return [view]           [managereport view]
     */
    public function getPromotionList(Request $request)
    {

        if($this->isNew()==true) return $this->actNew();

        if(Auth::user()->access_level == Staff::$USER_STAFF){
            return redirect('home');
        }

        $hide1 = $request->query('hide1');
        $hide2 = $request->query('hide2');
        $quater = $request->query('quater');
        $year = $request->query("year");

        // $year = isset($year) ? $year :  date('Y');
        $year = isset($year) ? $year :  'all';

        switch ($quater) {
            case 'jan':
                $quater = 'jan';
                break;
            case 'july':
                $quater = 'july';
                break;
            default:
                $quater = 'all';
                break;
        }

        $department = Department::where('is_currently_active', 1)->get();

        //$staffLastPromoted = Promotions::where('promotion_date', '>', \Carbon\Carbon::now())->where($->get();
        $staff = Staff::all();

        return view('reports.stafftobepromotedlisting', ['department'=>$department, 'staff' => $staff, 'display_type' => 'all', 'quater'=>$quater,  'quater_year'=>$year, 'hide_columns' => [$hide1, $hide2] ]);

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function show(Staff $staff)
    {
        if($this->isNew()==true) return $this->actNew();

        $thisStaff = Staff::findOrFail($staff->id);

        if(Auth::user()->access_level == Staff::$USER_STAFF){
            if(Auth::user()->username != $thisStaff->staffno)
                return redirect('home');
        }

        $staffPromotions = Promotions::where('staff_id', $thisStaff->id)->get();
        $staffDept = StaffDepartment::where('staff_id', $thisStaff->id)->get();
        $staffExtras = StaffExtras::where('staff_id', $thisStaff->id)->get()->all();
        $staffUserInfo = User::where('username', $thisStaff->staffno)->get();

        $all_staff = Staff::all();

        $level = Level::all();
        $state = State::all();
        $lga = Lga::where('stateid', $thisStaff->state_id)->get()->all();
        $appointmenttype = AppointmentType::all();
        $status = Status::all();
        $gpzone = Zone::all();
        $position = Position::all();
        $school = School::all();
        $staffDepartment = StaffDepartment::where('staff_id', $thisStaff->id)->where('status', StaffDepartment::$STATUS_CURRENT)->get()->first();
        $department = Department::where('school', $staffDepartment->school)->get()->all();
        $currentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $thisStaff->id)->get()->first();

        $salaryscale = SalaryScale::all();


        $rank = Rank::where('staffclass', $currentPromotion->staffclass )->get()->all();

        return view('staff/viewstaff', [ 'staff' => $all_staff, 'displayType' => 'show', 'thisStaff' => $thisStaff,
                                        'staffPromotions' => $staffPromotions, 'staffDept' => $staffDept,
                                        'staffExtras' => $staffExtras, 'staffUserInfo' => $staffUserInfo,
                                        'department'=>$department, 'level' => $level, 'state' => $state,
                                        'appointmenttype'=> $appointmenttype,  'rank'=> $rank, 'status' => $status,
                                        'gpzone' => $gpzone, 'position' => $position, 'school' => $school, 'lga' => $lga, 'staffdepartment' => $staffDepartment, 'currentPromotion' => $currentPromotion, 'staff_dc_print' => true, 'salaryscale' => $salaryscale ]);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function edit(Staff $staff, Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

        if(Auth::user()->access_level != Staff::$USER_ADMIN){
            return redirect('home');
        }

        $act = $request->query('act');

        $thisStaff = Staff::findOrFail($staff->id);

        if($act == 'dcprint'){
            if(strtolower($thisStaff->getDetails()['status']) == strtolower('DECEASED')){
                $output_yeah = true;
             }else{
                $output_yeah = false;
             }
        }else{
            $output_yeah = false;
        }


        if(Auth::user()->access_level == Staff::$USER_STAFF){
            if(Auth::user()->username != $thisStaff->staffno)
                return redirect('home');
        }

        $staffPromotions = Promotions::where('staff_id', $thisStaff->id)->get();
        $staffDept = StaffDepartment::where('staff_id', $thisStaff->id)->get();
        $staffExtras = StaffExtras::where('staff_id', $thisStaff->id)->get()->all();
        $staffUserInfo = User::where('username', $thisStaff->staffno)->get();

        $all_staff = Staff::all();

        $level = Level::all();
        $state = State::all();
        $lga = Lga::where('stateid', $thisStaff->state_id)->get()->all();
        $appointmenttype = AppointmentType::all();
        $status = Status::all();
        $gpzone = Zone::all();
        $position = Position::all();
        $school = School::all();
        $staffDepartment = StaffDepartment::where('staff_id', $thisStaff->id)->where('status', StaffDepartment::$STATUS_CURRENT)->get()->first();
        $staffDepartmentUnit = StaffUnitDepartment::where('staff_id', $thisStaff->id)->where('status', StaffUnitDepartment::$STATUS_CURRENT)->get()->first();

        $department = Department::where('school', $staffDepartment->school)->get()->all();
        $units = DepartmentUnit::where('department_id', $staffDepartment->dept_id)->get()->all();

        $currentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $thisStaff->id)->get()->first();

        $rank = Rank::where('staffclass', $currentPromotion->staffclass )->get()->all();

        $salaryscale = SalaryScale::all();

        return view('staff/viewstaff', [ 'staff' => $all_staff, 'displayType' => 'edit', 'thisStaff' => $thisStaff,
                                        'staffPromotions' => $staffPromotions, 'staffDept' => $staffDept,
                                        'staffExtras' => $staffExtras, 'staffUserInfo' => $staffUserInfo,
                                        'department'=>$department, 'unit'=>$units, 'level' => $level, 'state' => $state,
                                        'appointmenttype'=> $appointmenttype,  'rank'=> $rank, 'status' => $status,
                                        'gpzone' => $gpzone, 'position' => $position, 'school' => $school, 'lga' => $lga, 'staffdepartment' => $staffDepartment, 'staffdepartmentunit' => $staffDepartmentUnit, 'currentPromotion' => $currentPromotion, 'show_dc_print'=>$output_yeah, 'salaryscale' => $salaryscale ]);

        // StaffDepartment::STATUS_CURRENT
        /*Staff::truncate();
       Promotions::truncate();
       StaffDepartment::truncate();
       StaffExtras::truncate();

       User::truncate()*/
    }


    /**
     * [getQualification description]
     * @param  Request $request [description]
     * @return [type]           [description]
     */
    public function getQualification(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

        $extra_id = $request->input('extra_id');
        $extra_act = $request->input('extra_act');

        $thisStaffExtra = StaffExtras::find($extra_id);

        if($extra_act == 'modify'){

            $options = '';

            if($thisStaffExtra->qualificationtype == "OND"){
                $options .= '<option selected="selected" value="OND">OND</option>';
            }else{
                $options .= '<option value="OND">OND</option>';
            }

            if($thisStaffExtra->qualificationtype == "HND"){
                $options .= '<option selected="selected" value="HND">HND</option>';
            }else{
                $options .= '<option value="HND">HND</option>';
            }

            if($thisStaffExtra->qualificationtype == "DEG"){
                $options .= '<option selected="selected" value="DEG">Degree</option>';
            }else{
                $options .= '<option value="DEG">Degree</option>';
            }

            if($thisStaffExtra->qualificationtype == "PGD"){
                $options .= '<option selected="selected" value="PGD">PGD</option>';
            }else{
                $options .= '<option value="PGD">PGD</option>';
            }

            if($thisStaffExtra->qualificationtype == "MSC"){
                $options .= '<option selected="selected" value="MSC">MSC</option>';
            }else{
                $options .= '<option value="MSC">MSC</option>';
            }

            if($thisStaffExtra->qualificationtype == "PHD"){
                $options .= '<option selected="selected" value="PHD">PHD</option>';
            }else{
                $options .= '<option value="PHD">PHD</option>';
            }

            if($thisStaffExtra->qualificationtype == "OTHERS"){
                $options .= '<option selected="selected" value="OTHERS">OTHERS</option>';
            }else{
                $options .= '<option value="OTHERS">OTHERS</option>';
            }



        $htmlcontent = <<<QF
            <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select id="qualificationtype" name="qualificationtype" required="required" class="form-control">
                                                            <option>Select</option>
                                                            $options
                                                        </select>
                                                    </div>
                                                    <input type="hidden" name="extra_id" value="$extra_id" />
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input id="qualificationtitle" name="qualificationtitle" type="text" class="form-control" placeholder="Qualification Title" value="$thisStaffExtra->title"  required="required" >
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input id="qualificationdesc" name="qualificationdesc" type="text" class="form-control" placeholder="Qualification Description" value="$thisStaffExtra->description"  required="required" >

                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea id="registeredprobody" required="required" name="registeredprobody" class="form-control" placeholder="Registered Professional Body" >$thisStaffExtra->registeredprobody</textarea>
                                                        <input type="hidden" name="qualificationcount" value="1" >
                                                    </div>
                                                </div>
QF;

                                                echo $htmlcontent;
        }elseif ($extra_act == "approve") {
            $thisStaffExtra = StaffExtras::find($extra_id);
            $thisStaffExtra->status = StaffExtras::$APPROVED_QUALIFICATION_STATUS;
            $thisStaffExtra->save();
            echo "success";
        }elseif( $extra_act == "reject"){
            $thisStaffExtra = StaffExtras::find($extra_id);
            $thisStaffExtra->status = StaffExtras::$REJECTED_QUALIFICATION_STATUS;
            $thisStaffExtra->save();
            echo "success";
        }elseif( $extra_act == "accept"){
            $thisStaffExtra = StaffExtras::find($extra_id);
            $thisStaffExtra->status = StaffExtras::$ACCEPTED_QUALIFICATION_STATUS;
            $thisStaffExtra->save();
            echo "success";
        }
    }

    /**
     * Update the Staff Level information
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateStaffLevelInfo(Request $request)
    {   
        if($this->isNew()==true) return $this->actNew();

        $request->validate([
            'presentappointdate' => 'required|date',
            'appointmenttype' => 'required|integer',
            'position' => 'required|integer',
            'staffclass' => 'required',
            'salaryscale' => 'required|integer',
            'salaryscalevalue' => 'required|integer',
            'category' => 'required',
            'rank' => 'required|integer',
            'step' => 'required|integer'
        ]);

        $staff_id = $request->input('this_staff');
        $presentappointdate = $request->input('presentappointdate');
        $appointmenttype = $request->input('appointmenttype');
        $position = $request->input('position');
        $staffclass = $request->input('staffclass');
        $salaryscale = $request->input( 'salaryscale');
        $salaryscalevalue = $request->input( 'salaryscalevalue');
        $con___ = $salaryscalevalue;
        $category = $request->input('category');
        $rank = $request->input('rank');
        $step = $request->input('step');

        $thisStaff = Staff::findOrFail($staff_id);

        $thisStaff_CurrentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $thisStaff->id)->get()->first();

        // copy the model of the current promotion
        $newStaffPromotion = $thisStaff_CurrentPromotion->replicate();

        //update and save
        $newStaffPromotion->presentappointdate = $presentappointdate;
        $newStaffPromotion->appointmenttype = $appointmenttype;
        $newStaffPromotion->salary_scale = $salaryscale;
        $newStaffPromotion->salary_scale_value = $salaryscalevalue;
        $newStaffPromotion->con___ = $con___;
        $newStaffPromotion->position = $position;
        $newStaffPromotion->staffclass = $staffclass;
        $newStaffPromotion->category = $category;
        $newStaffPromotion->rank = $rank;
        $newStaffPromotion->step = $step;
        $newStaffPromotion->staff_id = $staff_id;
        $newStaffPromotion->save();

        $additional_responsibilities = $request->input('additional_responsibility');

        $additionalResponsibilities = [];

        foreach ($additional_responsibilities as $eachResponsibilitiesPosition) {
            $additionalResponsibilities[] = AdditionalResponsibility::create([
                'promotion_id' => $newStaffPromotion->id,
                'staff_id' => $thisStaff->id,
                'position' => $eachResponsibilitiesPosition
            ]);
        }


        //change the promotion to past
        $thisStaff_CurrentPromotion->promotion_indicator = Promotions::$PAST_PROMOTION;
        $thisStaff_CurrentPromotion->save();

        $thisStaff->appointmenttype = $appointmenttype;
        $thisStaff->staffclass = $staffclass;
        $thisStaff->save();

        return redirect(request()->headers->get('referer'))->with('success', 'Staff Level Information Updated Successfully');
    }

    public function viewPromoteStaffView(Request $request, $the_staffId){

        if($this->isNew()==true) return $this->actNew();

        if (Auth::user()->access_level != Staff::$USER_ADMIN) {
            return redirect('home');
        }

        $act = $request->query('act');

        $thisStaff = Staff::findOrFail($the_staffId);

        if ($act == 'dcprint') {
            if (strtolower($thisStaff->getDetails()['status']) == strtolower('DECEASED')) {
                $output_yeah = true;
            } else {
                $output_yeah = false;
            }
        } else {
            $output_yeah = false;
        }


        if (Auth::user()->access_level == Staff::$USER_STAFF) {
            if (Auth::user()->username != $thisStaff->staffno)
                return redirect('home');
        }

        $staffPromotions = Promotions::where('staff_id', $thisStaff->id)->get();
        $staffDept = StaffDepartment::where('staff_id', $thisStaff->id)->get();
        $staffExtras = StaffExtras::where('staff_id', $thisStaff->id)->get()->all();
        $staffUserInfo = User::where('username', $thisStaff->staffno)->get();

        $all_staff = Staff::all();

        $level = Level::all();
        $state = State::all();
        $lga = Lga::where('stateid', $thisStaff->state_id)->get()->all();
        $appointmenttype = AppointmentType::all();
        $status = Status::all();
        $gpzone = Zone::all();
        $position = Position::all();
        $school = School::all();
        $staffDepartment = StaffDepartment::where('staff_id', $thisStaff->id)->where('status', StaffDepartment::$STATUS_CURRENT)->get()->first();
        $department = Department::where('school', $staffDepartment->school)->get()->all();
        $currentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $thisStaff->id)->get()->first();

        $staffPromotionHistory = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
        ->where('staff_id', $thisStaff->id)->orderBy('promotion_indicator', "asc" )->get()->all();

        $salaryscale = SalaryScale::all();

        $rank = Rank::where('staffclass', $currentPromotion->staffclass)->get()->all();

        return view('staff.viewstaff_promotion', [
            'staff' => $all_staff, 'displayType' => 'edit', 'thisStaff' => $thisStaff,
            'staffPromotions' => $staffPromotions, 'staffDept' => $staffDept,
            'staffExtras' => $staffExtras, 'staffUserInfo' => $staffUserInfo,
            'department' => $department, 'level' => $level, 'state' => $state,
            'appointmenttype' => $appointmenttype, 'rank' => $rank, 'status' => $status,
            'gpzone' => $gpzone, 'position' => $position, 'school' => $school, 'lga' => $lga, 'staffdepartment' => $staffDepartment, 'currentPromotion' => $currentPromotion, 'staffPromotionHistory' => $staffPromotionHistory, 'show_dc_print' => $output_yeah, 'salaryscale' => $salaryscale
        ]);
    }

    public function promoteStaff(Request $request){

        if($this->isNew()==true) return $this->actNew();

        if(Auth::user()->access_level != Staff::$USER_ADMIN || Auth::user()->access_level != Staff::$USER_SUBADMIN){
             return redirect('home');
        }

        $staff_id = $request->input('this_staff');

        $thisStaff = Staff::findOrFail($staff_id);

         $request->validate([
            'presentappointdate' => 'required|date',
            'appointmenttype' => 'required|integer',
            'position' => 'required|integer',
            'staffclass' => 'required',
            'con___' => 'required|integer',
            'salaryscale' => 'required|integer',
            'salaryscalevalue' => 'required|integer',
            'category' => 'required',
            'rank' => 'required|integer',
            'step' => 'required|integer'
        ]);

        $staff_id = $request->input('this_staff');
        $presentappointdate = $request->input('presentappointdate');
        $appointmenttype = $request->input('appointmenttype');
        $position = $request->input('position');
        $staffclass = $request->input('staffclass');
        $con___ = $request->input('con___');
        $salary_scale = $request->input('salaryscale');
        $salary_scale_value = $request->input('salaryscalevalue');
        $category = $request->input('category');
        $rank = $request->input('rank');
        $step = $request->input('step');
        $promotion_description = $request->input('description');

        $thisStaff = Staff::findOrFail($staff_id);

        $thisStaff_CurrentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $thisStaff->id)->get()->first();


        $chief_ranks = \App\Rank::where('rank', 'like', '%Chief%')->get()->pluck('id')->all();

        // If this staff is currently a Chief in Rank
        if(in_array($thisStaff_CurrentPromotion->rank, $chief_ranks)){
            return redirect(request()->headers->get('referer'))->with('success', 'Staff At This Rank Level Cannot be Promoted');
        }

            // Promotions::where('status', Promotions::$APPROVED_PROMOTION)->where('promotion_indicator', Promotions::$PAST_PROMOTION)->where('staff_id', 11)->get();

        // copy the model of the current promotion
        $newStaffPromotion = $thisStaff_CurrentPromotion->replicate();

        //update and save
        $newStaffPromotion->presentappointdate = $presentappointdate;
        $newStaffPromotion->appointmenttype = $appointmenttype;
        $newStaffPromotion->con___ = $con___;
        // $newStaffPromotion->con___ = $salary_scale_value;
        $newStaffPromotion->description = $salary_scale_value;
        $newStaffPromotion->salary_scale = $salary_scale;
        $newStaffPromotion->salary_scale_value = $salary_scale_value;
        $newStaffPromotion->position = $position;
        $newStaffPromotion->staffclass = $staffclass;
        $newStaffPromotion->category = $category;
        $newStaffPromotion->rank = $rank;
        $newStaffPromotion->step = $step;
        $newStaffPromotion->staff_id = $staff_id;
        $newStaffPromotion->save();

        //change the promotion to past
        $thisStaff_CurrentPromotion->promotion_indicator = Promotions::$PAST_PROMOTION;
        $thisStaff_CurrentPromotion->save();

        $thisStaff->appointmenttype = $appointmenttype;
        $thisStaff->staffclass = $staffclass;
        $thisStaff->save();

        return redirect(request()->headers->get('referer'))->with('success', 'Staff Promoted Successfully');

    }


    /**
     * Update the Staff Dept information
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateStaffDeptInfo(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

        $request->validate([
            'firstappointdate' => 'required|date',
            'school' => 'required|integer',
            'department' => 'required|integer',
            'departmentunit' => 'required|integer'
        ]);

        $staff_id = $request->input('this_staff');

        $firstappointdate = $request->input('firstappointdate');
        $school = $request->input('school');
        $department = $request->input('department');
        $departmentunit = $request->input('departmentunit');

        $thisStaff = Staff::findOrFail($staff_id);

        $thisStaff_CurrentDept = StaffDepartment::where('status', StaffDepartment::$STATUS_CURRENT)
            ->where('staff_id', $thisStaff->id)->get()->first();

        $thisStaff_CurrentDeptUnit = StaffUnitDepartment::where('status', StaffUnitDepartment::$STATUS_CURRENT)
            ->where('staff_id', $thisStaff->id)->get()->first();

         


        // copy the model of the department and departmentunit
        $newStaffDepartment = $thisStaff_CurrentDept->replicate();

        if(is_null($thisStaff_CurrentDeptUnit)){
            
            //create a new record and 
            $newStaffDepartmentUnit = StaffUnitDepartment::create([
                'staff_id' => $thisStaff->id,
                'dept_id' => $department,
                'unit_id' => $departmentunit,
                'status' => StaffUnitDepartment::$STATUS_CURRENT // 1
           ]);

        }else{

            $newStaffDepartmentUnit = $thisStaff_CurrentDeptUnit->replicate();
            $newStaffDepartmentUnit->dept_id = $department;
            $newStaffDepartmentUnit->unit_id = $departmentunit;
            $newStaffDepartmentUnit->save();

            $thisStaff_CurrentDeptUnit->status = StaffUnitDepartment::$STATUS_PAST;
            $thisStaff_CurrentDeptUnit->save();
        }


        //update and save
        $newStaffDepartment->school = $school;
        $newStaffDepartment->dept_id = $department;
        // $newStaffDepartment->staff_id = $staff_id;
        $newStaffDepartment->save();

        //change the promotion to past
        $thisStaff_CurrentDept->status = StaffDepartment::$STATUS_PAST;
        $thisStaff_CurrentDept->save();

        $thisStaff->firstappointdate = $firstappointdate;
        $thisStaff->save();

        return redirect(request()->headers->get('referer'))->with('success', 'Staff Level Information Updated Successfully');
    }

    /**
     * Update the staff status
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateStaffStatus(Request $request)
    {

        if($this->isNew()==true) return $this->actNew();

        $request->validate([
            'status' => 'required|integer'
        ]);

        $staff_id = $request->input('this_staff');
        $staff_status = $request->input('status');

        $thisStaff = Staff::findOrFail($staff_id);


        return redirect(url('leave/create').'/?staff_id='.$staff_id.'&status='.$staff_status);
        exit;

        //TODO - IMPLEMENT THE STATUS CHANGE FUNCTIONALITY
        /*
        $thisStaff_CurrentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $thisStaff->id)->get()->first();


        // copy the model of the current promotion
        $newStaffPromotion = $thisStaff_CurrentPromotion->replicate();

        //update and save
        $newStaffPromotion->staff_status = $staff_status;
        $newStaffPromotion->save();


        //change the promotion to past
        $thisStaff_CurrentPromotion->promotion_indicator = Promotions::$PAST_PROMOTION;
        $thisStaff_CurrentPromotion->save();

        $thisStaff->status = $staff_status;
        $thisStaff->save();

        return redirect(request()->headers->get('referer'))->with('success', 'Staff Status Updated Successfully');

        */
    }

    /**
     * Add the new qualification
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addQualification(Request $request)
    {
        $staff_qualification_extras = StaffExtras::create([
                'staff_id' => $request->input('this_staff'),
                'title' => $request->input('qualificationtitle'),
                'description' => $request->input('qualificationdesc'),
                'registeredprobody'  => $request->input('registeredprobody'),
                'qualificationtype' => $request->input('qualificationtype'),
                'status' => StaffExtras::$PROPOSED_QUALIFICATION_STATUS
           ]);

        return redirect(request()->headers->get('referer'))->with('success', 'Qualification Added Successfully');
    }

    /**
     * Update the qualification
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateQualification(Request $request)
    {

        if($this->isNew()==true) return $this->actNew();

        $extra_id = $request->input('extra_id');

        $thisStaffExtra = StaffExtras::findOrFail($extra_id);

        //only allow an admin to update
        if(Auth::user()->access_level != Staff::$USER_ADMIN){

            // and the staff if it is still in proposal status or rejected status
            if(Auth::user()->access_level == Staff::$USER_STAFF){
                if(Auth::user()->getStaffId() == $request->input('this_staff')){
                    if($thisStaffExtra->status != StaffExtras::$PROPOSED_QUALIFICATION_STATUS && $thisStaffExtra->status != StaffExtras::$REJECTED_QUALIFICATION_STATUS){
                        return redirect('home');
                    }
                }else{
                    return redirect('home');
                }
            }else{
                return redirect('home');
            }
        }


        $thisStaffExtra->qualificationtype = $request->input('qualificationtype');
        $thisStaffExtra->title = $request->input('qualificationtitle');
        $thisStaffExtra->description = $request->input('qualificationdesc');
        $thisStaffExtra->registeredprobody = $request->input('registeredprobody');
        $thisStaffExtra->staff_id = $request->input('this_staff');
        // $thisStaffExtra->status = StaffExtras::$ACCEPTED_QUALIFICATION_STATUS;
        $thisStaffExtra->save();

        return redirect(request()->headers->get('referer'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Staff $staff)
    {
        if($this->isNew()==true) return $this->actNew();

        //only allow an admin to update
        if(Auth::user()->access_level != Staff::$USER_ADMIN){
            return redirect('home');
        }

        $staff_id = $request->input('this_staff');

        $request->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'othername' => 'present',
            'gender' => 'required',
            'staffno' => 'required|unique:staff,staffno,'.$staff_id,
            'phoneno' => 'required|unique:staff,phoneno,'.$staff_id,
            'photo' => 'file',
            'dateobirth' => 'required|date',
            'address1' => 'required',
            // 'address2' => 'present',
            'state' => 'required|integer',
            'lga' => 'required|integer',
            'gpzone' => 'required|integer',
            'nokfname' => 'required',
            'noklname' => 'required',
            'nokoname' => 'required',
            'nokaddress' => 'required',
            'nokphoneno' => 'required',
            'nokrelationship' => 'required',
            'nameofchild1' => '',
            'ageofchild1' => 'required_with:nameofchild1',
            'nameofchild2' => '',
            'ageofchild2' => 'required_with:nameofchild2',
            'nameofchild3' => '',
            'ageofchild3' => 'required_with:nameofchild3',
            'nameofchild4' => '',
            'ageofchild4' => 'required_with:nameofchild4'
        ]);

        // dd($staff_id);
        $thisStaff = Staff::findOrFail($staff_id);

        // dd($thisStaff);
        
        if(!empty($request->input('email'))){
            $request->validate([
            'email' => 'email|unique:staff,email,'.$staff_id
            ]);

            $thisStaff->email = $request->input('email');
        }else{
            $thisStaff->email = $thisStaff->email;
        }

        


        $thisStaff->fname = $request->input('firstname');
        $thisStaff->lname = $request->input('lastname');
        $thisStaff->oname = $request->input('othername');
        $thisStaff->gender = $request->input('gender');
        // $thisStaff->staffno = $request->input('staffno');
        $thisStaff->maritalstatus = $request->input('maritalstatus');
        $thisStaff->phoneno = $request->input('phoneno');



        $photoPath = "";

        if($request->hasFile('photo')){
         if($request->file('photo')->isValid()){
            $photoPath = $request->photo->store('public');
         }
        }

       if(!is_file(public_path(\Storage::url($photoPath)))){
            $photoPath = empty($photoPath)? $thisStaff->photo : $photoPath;
       }else{
            if(($photoPath != $thisStaff->photo) && is_file(public_path(\Storage::url($photoPath))))
                \Storage::delete($thisStaff->photo);
       }

        $thisStaff->photo = $photoPath;
        $thisStaff->dateobirth = $request->input('dateobirth');
        $thisStaff->address1 = $request->input('address1');
        $thisStaff->address2 = $request->input('address2') ?? "";
        $thisStaff->state_id = $request->input('state');
        $thisStaff->lga_id = $request->input('lga');
        $thisStaff->gpzone = $request->input('gpzone');
        $thisStaff->nok_fname = $request->input('nokfname');
        $thisStaff->nok_lname = $request->input('noklname');
        $thisStaff->nok_oname = $request->input('nokoname');
        $thisStaff->nok_address = $request->input('nokaddress');
        $thisStaff->nok_phoneno = $request->input('nokphoneno');
        $thisStaff->nok_relationship = $request->input('nokrelationship');
        $thisStaff->child1_name = $request->input('nameofchild1') ?? "" ;
        $thisStaff->child2_name = $request->input('nameofchild2') ?? "" ;
        $thisStaff->child3_name = $request->input('nameofchild3') ?? "" ;
        $thisStaff->child4_name = $request->input('nameofchild4') ?? "" ;
        $thisStaff->child1_age = $request->input('ageofchild1') ?? 0 ;
        $thisStaff->child2_age = $request->input('ageofchild2') ?? 0 ;
        $thisStaff->child3_age = $request->input('ageofchild3') ?? 0 ;
        $thisStaff->child4_age = $request->input('ageofchild4') ?? 0 ;

        $thisStaff->save();

        return redirect(request()->headers->get('referer'))->with('success', 'Staff Basic Information Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function destroy(Staff $staff)
    {
        if($this->isNew()==true) return $this->actNew();

        $staff_id = $staff->id;

        $staffExtras = StaffExtras::where('staff_id', $staff_id)->get();
        $staffPromotions = Promotions::where('staff_id', $staff_id)->get();
        $staffDepartments = StaffDepartment::where('staff_id', $staff_id)->get();
        $staff_user_account = User::where('username', $staff->staffno)->first();

        try {
            \DB::beginTransaction(); // Begin Transaction

            //Deleting Extras
            foreach ($staffExtras as $staffExtra) {
                $staffExtra->delete();
            }

            //Deleting Promotions
            foreach ($staffPromotions as $staffPromotion) {
                $staffPromotion->delete();
            }

            //Deleting Staff Departments
            foreach ($staffDepartments as $staffDepartment) {
                $staffDepartment->delete();
            }

            //Deleting Staff User Account
            $staff_user_account->delete();

            //Finally Deleting Staff Records
            $staff->delete();

            \DB::commit(); // commit completed Transaction
        }catch(\Exception $e){
            \DB::rollback(); // Rollback Incase of any issue;
        }

        return redirect(request()->headers->get('referer'))->with('success', 'Staff Records Deleted Successfully');
    }

    public function manageQualification(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

        if($request->isMethod('post')){
            return $this->getQualification($request);
        }

        if($request->isMethod('get')){

            if(Auth::user()->access_level != Staff::$USER_STAFF){
            return redirect('home');
        }
            //dd(Auth::user()->getStaffId());
            $thisStaff = Staff::findOrFail(Auth::user()->getStaffId());

        if(Auth::user()->access_level == Staff::$USER_STAFF){
            if(Auth::user()->username != $thisStaff->staffno)
                return redirect('home');
        }

        $staffPromotions = Promotions::where('staff_id', $thisStaff->id)->get();
        $staffDept = StaffDepartment::where('staff_id', $thisStaff->id)->get();
        $staffExtras = StaffExtras::where('staff_id', $thisStaff->id)->get()->all();
        $staffUserInfo = User::where('username', $thisStaff->staffno)->get();

        $all_staff = Staff::all();

        $level = Level::all();
        $state = State::all();
        $lga = Lga::where('stateid', $thisStaff->state_id)->get()->all();
        $appointmenttype = AppointmentType::all();
        $status = Status::all();
        $gpzone = Zone::all();
        $position = Position::all();
        $school = School::all();
        $staffDepartment = StaffDepartment::where('staff_id', $thisStaff->id)->where('status', StaffDepartment::$STATUS_CURRENT)->get()->first();
        $department = Department::where('school', $staffDepartment->school)->get()->all();
        $currentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $thisStaff->id)->get()->first();

        $rank = Rank::where('staffclass', $currentPromotion->staffclass )->get()->all();

        return view('qualification/create', [ 'staff' => $all_staff, 'displayType' => 'edit', 'thisStaff' => $thisStaff,
                                        'staffPromotions' => $staffPromotions, 'staffDept' => $staffDept,
                                        'staffExtras' => $staffExtras, 'staffUserInfo' => $staffUserInfo,
                                        'department'=>$department, 'level' => $level, 'state' => $state,
                                        'appointmenttype'=> $appointmenttype,  'rank'=> $rank, 'status' => $status,
                                        'gpzone' => $gpzone, 'position' => $position, 'school' => $school, 'lga' => $lga,
                                        'staffdepartment' => $staffDepartment, 'currentPromotion' => $currentPromotion ]);
        }

    }

    /**
     * [processUpdateBasicInformation description]
     * @param  Request $request [description]
     * @return [type]           [description]
     */
    public function processUpdateBasicInformation(Request $request)
    {

        if($this->isNew()==true) return $this->actNew();

        //only allow an admin to update
        if(Auth::user()->access_level != Staff::$USER_STAFF){
            return redirect('home');
        }

        $staff_id = $request->input('this_staff');

        $request->validate([
            'email' => 'required|email|unique:staff,email,'.$staff_id,
            'phoneno' => 'required|unique:staff,phoneno,'.$staff_id,
            'address1' => 'required',
            // 'address2' => 'present',
            'state' => 'required|integer',
            'lga' => 'required|integer',
            'gpzone' => 'required|integer',
            'nokfname' => 'required',
            'noklname' => 'required',
            'nokoname' => 'required',
            'nokaddress' => 'required',
            'nokphoneno' => 'required',
            'nokrelationship' => 'required',
            'nameofchild1' => '',
            'ageofchild1' => 'required_with:nameofchild1',
            'nameofchild2' => '',
            'ageofchild2' => 'required_with:nameofchild2',
            'nameofchild3' => '',
            'ageofchild3' => 'required_with:nameofchild3',
            'nameofchild4' => '',
            'ageofchild4' => 'required_with:nameofchild4'
        ]);

        // dd($staff_id);
        $thisStaff = Staff::findOrFail($staff_id);

        // dd($thisStaff);

        // $thisStaff->fname = $request->input('firstname');
        // $thisStaff->lname = $request->input('lastname');
        // $thisStaff->oname = $request->input('othername');
        // $thisStaff->gender = $request->input('gender');
        // $thisStaff->staffno = $request->input('staffno');

        $thisStaff->maritalstatus = $request->input('maritalstatus');
        $thisStaff->phoneno = $request->input('phoneno');

        $thisStaff->email = $request->input('email');


        $photoPath = "";

        if($request->hasFile('photo')){
         if($request->file('photo')->isValid()){
            $photoPath = $request->photo->store('public');
         }
        }

       if(!is_file(public_path(\Storage::url($photoPath)))){
            $photoPath = empty($photoPath)? $thisStaff->photo : $photoPath;
       }else{
            if(($photoPath != $thisStaff->photo) && is_file(public_path(\Storage::url($photoPath))))
                \Storage::delete($thisStaff->photo);
       }

        $thisStaff->photo = $photoPath;
        // $thisStaff->dateobirth = $request->input('dateobirth');
        $thisStaff->address1 = $request->input('address1');
        // $thisStaff->address2 = $request->input('address2') ?? "";
        $thisStaff->state_id = $request->input('state');
        $thisStaff->lga_id = $request->input('lga');
        $thisStaff->gpzone = $request->input('gpzone');
        $thisStaff->nok_fname = $request->input('nokfname');
        $thisStaff->nok_lname = $request->input('noklname');
        $thisStaff->nok_oname = $request->input('nokoname');
        $thisStaff->nok_address = $request->input('nokaddress');
        $thisStaff->nok_phoneno = $request->input('nokphoneno');
        $thisStaff->nok_relationship = $request->input('nokrelationship');
        $thisStaff->child1_name = $request->input('nameofchild1') ?? "" ;
        $thisStaff->child2_name = $request->input('nameofchild2') ?? "" ;
        $thisStaff->child3_name = $request->input('nameofchild3') ?? "" ;
        $thisStaff->child4_name = $request->input('nameofchild4') ?? "" ;
        $thisStaff->child1_age = $request->input('ageofchild1') ?? 0 ;
        $thisStaff->child2_age = $request->input('ageofchild2') ?? 0 ;
        $thisStaff->child3_age = $request->input('ageofchild3') ?? 0 ;
        $thisStaff->child4_age = $request->input('ageofchild4') ?? 0 ;

        $thisStaff->save();

        return redirect(request()->headers->get('referer'))->with('success', 'Your Basic Information Has Been Updated Successfully');
    }

    public function toggleStaffUpdate(Request $request){
        
        if($this->isNew()==true) return $this->actNew();

        //only allow an admin to update
        if(Auth::user()->access_level != Staff::$USER_ADMIN){
            return redirect('home');
        }
        \App\GenSettings::toggleEnable();
    }

    /**
     * Display form to Update Staff Basic Information
     * @param Request $request
     */
    public function updateBasicInformation(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

        if(!\App\GenSettings::showEnable()){
            return redirect('home');
        }

        if($request->isMethod('post')){
            return $this->processUpdateBasicInformation($request);
        }

        if($request->isMethod('get')){

            if(Auth::user()->access_level != Staff::$USER_STAFF){
            return redirect('home');
        }
            //dd(Auth::user()->getStaffId());
            $thisStaff = Staff::findOrFail(Auth::user()->getStaffId());

        if(Auth::user()->access_level == Staff::$USER_STAFF){
            if(Auth::user()->username != $thisStaff->staffno)
                return redirect('home');
        }

        $staffPromotions = Promotions::where('staff_id', $thisStaff->id)->get();
        $staffDept = StaffDepartment::where('staff_id', $thisStaff->id)->get();
        $staffExtras = StaffExtras::where('staff_id', $thisStaff->id)->get()->all();
        $staffUserInfo = User::where('username', $thisStaff->staffno)->get();

        $all_staff = Staff::all();

        $level = Level::all();
        $state = State::all();
        $lga = Lga::where('stateid', $thisStaff->state_id)->get()->all();
        $appointmenttype = AppointmentType::all();
        $status = Status::all();
        $gpzone = Zone::all();
        $position = Position::all();
        $school = School::all();
        $staffDepartment = StaffDepartment::where('staff_id', $thisStaff->id)->where('status', StaffDepartment::$STATUS_CURRENT)->get()->first();
        $department = Department::where('school', $staffDepartment->school)->get()->all();
        $currentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $thisStaff->id)->get()->first();

        $rank = Rank::where('staffclass', $currentPromotion->staffclass )->get()->all();

        return view('staff/add_staff_qualification', [ 'staff' => $all_staff, 'displayType' => 'edit', 'thisStaff' => $thisStaff,
                                        'staffPromotions' => $staffPromotions, 'staffDept' => $staffDept,
                                        'staffExtras' => $staffExtras, 'staffUserInfo' => $staffUserInfo,
                                        'department'=>$department, 'level' => $level, 'state' => $state,
                                        'appointmenttype'=> $appointmenttype,  'rank'=> $rank, 'status' => $status,
                                        'gpzone' => $gpzone, 'position' => $position, 'school' => $school, 'lga' => $lga,
                                        'staffdepartment' => $staffDepartment, 'currentPromotion' => $currentPromotion ]);
        }
    }

    public function updateAccountAccess(Request $request)
    {

      if(null !== $request->input('photo_update') && $request->input('photo_update') == TRUE){

        $request->validate([
            'photo' => 'file|required',
          ]);

        if($request->hasFile('photo')){
            $photoPath = "";

             if($request->file('photo')->isValid()){
                $photoPath = $request->photo->store('public');
             }

           if(!is_file(public_path(\Storage::url($photoPath)))){
                $photoPath = empty($photoPath)? Auth::user()->photo ?? $photoPath : "" ;
           }else{
                if(($photoPath != Auth::user()->photo) && is_file(public_path(\Storage::url($photoPath))))
                    \Storage::delete(Auth::user()->photo);
           }

           $user = \App\User::find(\Auth::id());
           $user->photo = $photoPath;
           $user->save();

           return redirect('/accountprofile')->with('status', 'Photo Updated Successfully');

       }else{
            return redirect('/accountprofile')->with('status', 'Photo Is Required');
       }

      }else{
        $request->validate([
            'oldpassword' => 'required',
            'newpassword' => 'required|same:confirmnewpassword',
          ]);
      }

      if(!\Hash::check($request->input('oldpassword'), \Auth::user()->password)){
          return back()->withErrors(['Invalid Old Password']);
      }else{
        $user = \App\User::find(\Auth::id());
        $user->password = bcrypt($request->newpassword);
        
        FirstTimeLoginResetModel::setPasswordUpdated($user->id);

        $user->save();
      }

      return redirect('/accountprofile')->with('status', 'Password Updated Successfully');

    }

    public function importStaffInfo(Request $request)
    {
        $filePath = "";
        if($request->hasFile('uploadfile')){
            if($request->file('uploadfile')->isValid()) {
                $filePath = $request->uploadfile->store('datafile');
                printf("\n%s\n", "FILE UPLOADED SUCCESSFULLY, WAITING FOR PROCESSING OR IMPORTING DATA");
                var_dump($filePath);
                printf("\n%s\n", "PROCESSING FILES AND IMPORTING DATA DELEGATED TO CRON JOB");
            }
        }
    }


    public function setLastPromotionStaff(Request $request){
        $staff_id = $request->query( 'staff_id');

        $thisStaff = Staff::find($staff_id);
        $currentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
            ->where('staff_id', $thisStaff->id)->get()->first();

            if($currentPromotion->last_promotion_status == Promotions::$IS_LAST_PROMOTED){
                $currentPromotion->last_promotion_status = Promotions::$IS_NOT_YET_LAST_PROMOTED;
                $currentPromotion->save();
            }else{
                $currentPromotion->last_promotion_status = Promotions:: $IS_LAST_PROMOTED   ;
                $currentPromotion->save();
            }
            return redirect( url('staff/' . $staff_id . '/edit'));


    }


}
