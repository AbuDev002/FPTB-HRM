<?php

namespace App\Http\Controllers;

use App\SalaryScale;
use Illuminate\Http\Request;

class SalaryScaleController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');//->except('logout');
    }

    /**
     * @param Request $request
     */
    public function create(Request $request){
        
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
            return redirect('home');
        }

        return view('salaryscale/addnewsalaryscale', ['salaryscale' => SalaryScale::all()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $request->validate([
            'salaryscale' => 'required|unique:salary_scales,salaryscale',
            'maxvalue' => 'required|numeric'
        ]);

        SalaryScale::create([
            'salaryscale' => $request->input('salaryscale'),
            'maxvalue' => $request->input('maxvalue')
        ]);

        return redirect('salaryscale/create')->with('salaryscale', 'Salary Scale Created Successfully');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $salaryscale
     * @return \Illuminate\Http\Response
     */
    public function show(int $salaryScale)
    {
        if($this->isNew()==true) return $this->actNew();

        $thisSalaryScale = SalaryScale::findOrFail($salaryScale);

        $action = isset($_GET['action']) ? ($_GET['action'] == 'del'? 'delete' : 'show') : 'show';

        return view('salaryscale/addnewsalaryscale', ['salaryscale' => SalaryScale::all()])
            ->with('this_salaryscale', $thisSalaryScale)
            ->with('displaystate', $action);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SalaryScale  $salaryScale
     * @return \Illuminate\Http\Response
     */
    public function edit(int $salaryScale)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $thisSalaryScale = SalaryScale::findOrFail($salaryScale);
//        dd($thisSalaryScale->salaryscale);

        return view('salaryscale/addnewsalaryscale', ['salaryscale' => SalaryScale::all()])->with('this_salaryscale', $thisSalaryScale)
            ->with('displaystate', 'edit');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int $salaryScale
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, int $salaryScale)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $request->validate([
            'salaryscale' => 'required',
            'maxvalue' => 'present'
        ]);

        $thisSalaryScale = SalaryScale::findOrFail($salaryScale);

        $thisSalaryScale = $thisSalaryScale->first();

        $thisSalaryScale->salaryscale = $request->input('salaryscale');
        $thisSalaryScale->maxvalue = $request->input('maxvalue');

        $thisSalaryScale->save();

        return redirect('salaryscale/'.$thisSalaryScale->id)->with('salaryscale', "Salary Scale Updated Successfully");
    }

    /**
     * getSalaryScaleValues
     * @param Request $request
     */
    public function getSalaryScaleValues(Request $request){

        if($this->isNew()==true) return $this->actNew();
        
        $selected_salary_scale = (int)($request->input('salaryscale'));

        $thisSalaryScale = SalaryScale::find($selected_salary_scale);

        if($thisSalaryScale  != null) {
            $salary_values = '<option value="">Select Salary Scale (' . $thisSalaryScale->salaryscale . ') Value ...</option>';

            for($i = 1; $i <= $thisSalaryScale->maxvalue; $i++){
                $salary_values .= '<option value="' . $i . '">' . $i . '</option>';
            }
        }else {
            $salary_values = '<option value="">Select Salary Scale Value ...</option>';
        }

        return $salary_values;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $salaryscale
     * @return \Illuminate\Http\Response
     */
    public function destroy(int $salaryScale)
    {
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }
        $thisSalaryScale = SalaryScale::findOrFail($salaryScale);

       // $thisSalaryScale->delete();

        return redirect('salaryscale/create')->with('salaryscale', "Salary Scale Delete Has Been Restricted. You Can Only Update.");
    }

}
