<?php

namespace App\Http\Controllers;

use App\Department;
use App\School;
use Illuminate\Http\Request;

class DepartmentController extends Controller
{
    private $schools;


    public function __construct()
    {
        $this->middleware('auth');
        $this->schools = School::all()->pluck("school", "id")->all();
        if($this->isNew()==true) return $this->actNew();
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
            return redirect('home');
        }

        return redirect('department/create');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if($this->isNew()==true) return $this->actNew();
        if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
            return redirect('home');
        }

        return view('department/addnewdepartment')->with('department', Department::where('is_currently_active', 1)->get())->with('school', $this->schools);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $request->validate([
            'department' => 'required|unique:department',
            'school' => 'required',
            'description' => 'present'
        ]);

        Department::create([
            'department' => $request->input('department'), 
            'school' => $request->input('school'), 
            'description' => $request->input('description')
        ]);

        return redirect('department/create')->with('status', 'Department Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function show(Department $department)
    {

        if($this->isNew()==true) return $this->actNew();

        $aDepartment = Department::findOrFail($department->id);
        $action = isset($_GET['action']) ? ($_GET['action'] == 'del'? 'delete' : 'show') : 'show';

        return view('department/addnewdepartment')->with('department', $aDepartment )
            ->with('school', $this->schools)->with('displaystate', $action);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function edit(Department $department)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $aDepartment = Department::findOrFail($department->id);
        
        return view('department/addnewdepartment')->with('department', $aDepartment )
            ->with('school', $this->schools)->with('displaystate', 'edit');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Department $department)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $thisDepartment = Department::findOrFail($department->id);

        $request->validate([
            'department' => 'required|unique:department,id,'.$thisDepartment->id,
            'school' => 'required',
            'description' => 'present'
        ]);

        $thisDepartment->department = $request->input('department');
        $thisDepartment->school = $request->input('school');
        $thisDepartment->description = $request->input('description') == null? "":$request->input('description');
        $thisDepartment->save();

        return redirect('department/'.$thisDepartment->id)->with('status', 'Department Updated Successfully');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function destroy(Department $department)
    {
        if($this->isNew()==true) return $this->actNew();
        
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }
        
        $department->delete();
        return redirect('department/create')->with('status', 'Department Deleted Successfully');
    }
}
