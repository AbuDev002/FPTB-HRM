<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\AppointmentType;
use App\Rank;
use App\Staff;
use App\Department;
use App\Level;
use App\Promotions;
use App\StaffDepartment;
use App\StaffExtras;
use App\State;
use App\Status;
use App\Zone;
use App\Position;
use App\Lga;
use Auth;
use DB;

class SearchController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');//->except('logout');
    }


    public function searchByClassDept(Request $request)
    {
        $nn = $request->query('nn');

        // dd($nn);

        //when our script started to run.
        $executionStartTime = microtime(true);

    	$staffclass = $request->input('staffclass');
    	$department = $request->input('dept');
    	$status = $request->input('status');

    	if(strtolower($status) != "all"){
    		$status = (int)$status;
    	}

    	// Get All Staff Id Only That Are Active For All Department
    	if(strtolower($department) == 'all' ){
    		// Get All Staff Id Only That Are Active For A Particular Department

    		// $staffInDepartmentArray = StaffDepartment::where('status', 1)->get(); // FIRST
            // $staffId_In_DepartmentArray = $staffInDepartmentArray->pluck('staff_id')->toArray(); // SECOND
	    	$staffId_In_DepartmentArray = StaffDepartment::select('staff_id')->where('status', 1)->get()->pluck('staff_id'); // SECOND

    	}else{
	    	// Get All Staff Id Only That Are Active For A Particular Department
	    	// $staffInDepartmentArray = StaffDepartment::where('status', 1)->where('dept_id', (int)$department)->get(); // FIRST
            // $staffId_In_DepartmentArray = $staffInDepartmentArray->pluck('staff_id')->toArray(); // SECOND
		    $staffId_In_DepartmentArray = StaffDepartment::select('dept_id', 'staff_id')->where('status', 1)->where('dept_id', (int)$department)->get()->pluck('staff_id'); // SECOND
		  }

	    $outcome = "";

	    // $allDept = Department::all()->pluck('department', 'id')->toArray();
	    // $departmentIdArray = $staffInDepartmentArray->pluck('dept_id', 'staff_id')->toArray();

    	if(strtolower($staffclass) == "all"){
    		if(strtolower($status) == "all"){
    			$allStaffInDeparmentArray_ForAll_StaffClass = Staff::whereIn('id', $staffId_In_DepartmentArray)->get();
    		}
    		else{
    			$allStaffInDeparmentArray_ForAll_StaffClass = Staff::whereIn('id', $staffId_In_DepartmentArray)->where('status', $status)->get();
    		}
    	}else if(strtolower($staffclass) == "as"){
    		if(strtolower($status) == "all"){
    			$allStaffInDeparmentArray_ForAll_StaffClass = Staff::whereIn('id', $staffId_In_DepartmentArray)->where('staffclass', "AS")->get();
    		}
    		else{
    			$allStaffInDeparmentArray_ForAll_StaffClass = Staff::whereIn('id', $staffId_In_DepartmentArray)->where('staffclass', "AS")->where('status', $status)->get();
    		}
    	}else if(strtolower($staffclass) == "na"){
    		if(strtolower($status) == "all"){
					$allStaffInDeparmentArray_ForAll_StaffClass = Staff::whereIn('id', $staffId_In_DepartmentArray)->where('staffclass', "NA")->get();
    		}else{
					$allStaffInDeparmentArray_ForAll_StaffClass = Staff::whereIn('id', $staffId_In_DepartmentArray)->where('staffclass', "NA")->where('status', $status)->get();
				}
			}else{
                // header('Content-Type: application/json');
                $array_data = [ "data" => [
                     [
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        ""
                    ]
                ] ];
                // echo json_encode($array_data);
                echo json_encode($array_data);
                exit;
				return $outcome;
			}

            $icount = 1;

            $outcome2 = array();


                foreach($allStaffInDeparmentArray_ForAll_StaffClass as $aStaff) {

                            // $position = Position::find(Promotions::where('staff_id', $aStaff->id)->where('status', 1)->get()->first()->position)->position ?? "NONE";

                        $position_array = DB::select("SELECT positions.position from positions, promotions WHERE positions.id = promotions.position AND promotions.staff_id = {$aStaff->id} AND promotions.status = 1 ORDER by promotions.id DESC LIMIT 1 ");

                        $position = count($position_array) == 0 ? "NONE" : $position_array[0]->position;

                        $addedresponsibilities = '';

                        foreach($aStaff->getDetails()['addedresponsibilities'] as $eachRes){
                            $addedresponsibilities .= $eachRes->position . ', ';
                        }
                            

                        $outcome2[] = [
                            $icount,
                            $aStaff->staffno,
                            "{$aStaff->fname} {$aStaff->lname} {$aStaff->oname}",
                            $aStaff->getDepartment(),
                            $aStaff->getDetails()['rank'],
                            $aStaff->getDetails()['category'],
                            $aStaff->dateobirth,
                            $aStaff->gender,
                            $position,
                            $addedresponsibilities,
                            $aStaff->phoneno,
                            $aStaff->getDetails()['state'],
                            $aStaff->getDetails()['lga'],
                            $aStaff->getDetails()['status']
                          ];

	    					$icount++;
                    }

                    $final_outcome2 = array( "data" => $outcome2 );

                    echo json_encode($final_outcome2);
                    return;
	    			// echo $outcome;

                //Compare the currentmicrotime to the microtime that we stored
        //at the beginning of the script.
        $executionEndTime = microtime(true);

        //The result will be in seconds and milliseconds.
        $seconds = $executionEndTime - $executionStartTime;

        //Print it out
        echo "<br/>This script took $seconds to execute. " .  count($allStaffInDeparmentArray_ForAll_StaffClass);

	    			return;

    }

    public function searchByStaffNo(Request $request)
    {

    	$staffno = $request->input('staffno');
    	$status = $request->input('status');

    	if(empty($staffno)) return;

    	if(strtolower($status) == "all")
    		$allStaffRetrieved = Staff::where("staffno", "like", "%$staffno%")->get();
    	else
    		$allStaffRetrieved = Staff::where("staffno", "like", "%$staffno%")->where('status', $status)->get();

    	$icount = 1;

    	$staffInDepartmentArray = StaffDepartment::where('status', 1)->get(); // FIRST
    	$allDept = Department::all()->pluck('department', 'id')->toArray();
        $departmentIdArray = $staffInDepartmentArray->pluck('dept_id', 'staff_id')->toArray();

        $outcome2 = array();

	    			foreach ($allStaffRetrieved as $aStaff) {

                            /* $promotions = Promotions::where('staff_id', $aStaff->id)->where('status', 1)->get()->first();
                            $position = $promotions == null? "NO_POSITION_ID_OR_PROMOSTION_NULL": Position::find($promotions->position)->position ?? "NONE"; */

                        $position_array = DB::select("SELECT positions.position from positions, promotions WHERE positions.id = promotions.position AND promotions.staff_id = {$aStaff->id} AND promotions.status = 1 ORDER by promotions.id DESC LIMIT 1 ");

                        $position = count($position_array) == 0? "NONE" : $position_array[0]->position;

                        $addedresponsibilities = '';

                        foreach($aStaff->getDetails()['addedresponsibilities'] as $eachRes){
                            $addedresponsibilities .= $eachRes->position . ', ';
                        }

                        $outcome2[] = [
                            $icount,
                            $aStaff->staffno,
                            "{$aStaff->fname} {$aStaff->lname} {$aStaff->oname}",
                            $aStaff->getDepartment(),
                            $aStaff->getDetails()['rank'],
                            $aStaff->getDetails()['category'],
                            $aStaff->dateobirth,
                            $aStaff->gender,
                            $position,
                            $addedresponsibilities,
                            $aStaff->phoneno,
                            $aStaff->getDetails()['state'],
                            $aStaff->getDetails()['lga'],
                            $aStaff->getDetails()['status']
                        ];

                            $icount++;

                    }

                    $final_outcome2 = array("data" => $outcome2);

                    echo json_encode($final_outcome2);

	    			return;

    }

    public function searchByStaffNames(Request $request)
    {

    	$firstname = $request->input('fname');
    	$lastname = $request->input('lname');
        $othername = $request->input('oname');
        $status = $request->input('status');

    	if(empty($firstname) && empty($lastname) && empty($othername)) return;

    	if(strtolower($status) == "all"){
            $allStaffRetrieved = DB::select("select * FROM `staff` WHERE fname like ? and lname like ? and oname like ? ORDER by id desc", ["%$firstname%", "%$lastname%", "%$othername%"]);
        }else{
            $allStaffRetrieved = DB::select("select * FROM `staff` WHERE fname like ? and lname like ? and oname like ? and status=? ORDER by id desc", ["%$firstname%", "%$lastname%", "%$othername%", "$status"]);
        }

	    	$outcome = "";
            $icount = 1;

            $outcome2 = array();

	    	$staffInDepartmentArray = StaffDepartment::where('status', 1)->get(); // FIRST
	    	$allDept = Department::all()->pluck('department', 'id')->toArray();
		    $departmentIdArray = $staffInDepartmentArray->pluck('dept_id', 'staff_id')->toArray();

	    			foreach ($allStaffRetrieved as $aStaffDB) {

	    					$aStaff = Staff::find($aStaffDB->id);

	    					$promotions = Promotions::where('staff_id', $aStaff->id)->where('status', 1)->get()->first();

	    					$position = $promotions == null? "NO_POSITION_ID_OR_PROMOSTION_NULL": Position::find($promotions->position)->position ?? "NONE";

                            $addedresponsibilities = '';

                            foreach($aStaff->getDetails()['addedresponsibilities'] as $eachRes){
                                $addedresponsibilities .= $eachRes->position . ', ';
                            }

                        $outcome2[] = [
                            $icount,
                            $aStaff->staffno,
                            "{$aStaff->fname} {$aStaff->lname} {$aStaff->oname}",
                            $aStaff->getDepartment(),
                            $aStaff->getDetails()['rank'],
                            $aStaff->getDetails()['category'],
                            $aStaff->dateobirth,
                            $aStaff->gender,
                            $position,
                            $addedresponsibilities,
                            $aStaff->phoneno,
                            $aStaff->getDetails()['state'],
                            $aStaff->getDetails()['lga'],
                            $aStaff->getDetails()['status']
                        ];

	    					$icount++;
                    }

                    $final_outcome2 = array("data" => $outcome2);

                    echo json_encode($final_outcome2);

	    			// echo $outcome;
	    			return;

    }
}
