<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\School;
use App\Department;
use App\DepartmentUnit;

class UnitController extends Controller
{
    private $schools;


    public function __construct()
    {
        $this->middleware('auth');
        $this->schools = School::all()->pluck("school", "id")->all();
        if($this->isNew()==true) return $this->actNew();
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
            return redirect('home');
        }

        return redirect('units/create');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if($this->isNew()==true) return $this->actNew();
        if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
            return redirect('home');
        }

        return view('units/addnewunit')->with('department', Department::where('is_currently_active', 1)->get())->with('units', DepartmentUnit::all());
    }

    /**
     * Store new Department Unit
     * @param  Request $request [description]
     * @return [type]           [description]
     */
    public function store(Request $request)
    {
    	if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $request->validate([
            'unit' => 'required|unique:department_units',
            'department' => 'required|integer'
        ]);

        DepartmentUnit::create([
            'unit' => $request->input('unit'), 
            'department_id' => $request->input('department')
        ]);

        return redirect('units/create')->with('status', 'Department Unit Created Successfully');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DepartmentUnit  $departmentunit
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $department_unit)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $deparmtmentUnit = DepartmentUnit::findOrFail($department_unit);
        
        return view('units/addnewunit')->with('department', Department::where('is_currently_active', 1)->get())->with('school', $this->schools)->with('unit', $deparmtmentUnit)->with('units', DepartmentUnit::all())->with('school', $this->schools)->with('displaystate', 'edit');
    }


    public function update(Request $request, $unit_id)
    {
    	if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $thisDepartmentUnit = DepartmentUnit::findOrFail($unit_id);
        
        $request->validate([
            'department' => 'required|integer',
            'unit' => 'required|string'
        ]);
        
        $thisDepartmentUnit->unit = $request->input('unit');
        $thisDepartmentUnit->department_id = $request->input('department');
        $thisDepartmentUnit->save();

        return redirect('units/'.$thisDepartmentUnit->id)->with('status', 'Department Unit Updated Successfully');
    }

    /**
     * Display the specified resource.
     * @param  Request $request 
     * @param  [type]  $unit_id 
     * @return [type]           
     */
    public function show(Request $request, $unit_id)
    {
    		if($this->isNew()==true) return $this->actNew();

        $deparmtmentUnit = DepartmentUnit::findOrFail($unit_id);


        $action = isset($_GET['action']) ? ($_GET['action'] == 'del'? 'delete' : 'show') : 'show';

        return view('units/addnewunit')->with('department', Department::where('is_currently_active', 1)->get())->with('unit', $deparmtmentUnit)->with('units', DepartmentUnit::all())->with('displaystate', $action);
    }


     /**
     * Remove the specified resource from storage.
     *
     * @param  int $unit_id
     * @return \Illuminate\Http\Response
     */
    public function destroy(int $unit_id)
    {
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }
        $thisDepartmentUnit = DepartmentUnit::findOrFail($unit_id);

        $thisDepartmentUnit->delete();

        return redirect('units/create')->with('status', 'Department Unit Has Been Deleted Successfully');
    }

}
