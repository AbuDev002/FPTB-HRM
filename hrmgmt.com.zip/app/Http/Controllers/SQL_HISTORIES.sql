#HOD
SELECT promotions.rank, promotions.staff_id, staff_department.staff_id, staff_department.dept_id, staff.staffno FROM promotions, staff_department, staff WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id AND promotions.position=1 AND staff.id = promotions.staff_id


#RANK
SELECT COUNT(promotions.rank), promotions.staff_id, staff_department.staff_id, staff_department.dept_id, staff.staffno FROM promotions, staff_department, staff WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id AND promotions.rank=1 AND staff.id = promotions.staff_id

#RANK
SELECT COUNT(promotions.rank), promotions.staff_id, staff_department.staff_id, staff_department.dept_id, staff.staffno FROM promotions, staff_department, staff WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id AND staff.id = promotions.staff_id
GROUP BY promotions.rank



#SELECT SUMMATION OF ALL RECORS FROM
SELECT SUM(pp.SUMMATION) FROM (
SELECT COUNT(promotions.rank) as SUMMATION, promotions.staff_id, staff_department.dept_id, staff.staffno FROM promotions, staff_department, staff WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id AND staff.id = promotions.staff_id
GROUP BY promotions.rank
    ) as pp


#SELECT SUMMATION OF ALL RECORS FROM WITH RANKS
SELECT SUM(pp.SUMMATION) FROM (
SELECT COUNT(promotions.rank) as SUMMATION, promotions.staff_id, staff_department.dept_id, staff.staffno, ranks.rank FROM promotions, ranks,  staff_department, staff WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id AND staff.id = promotions.staff_id AND ranks.id = promotions.rank
GROUP BY promotions.rank
    ) as pp




SELECT COUNT(promotions.rank) as SUMMATION, promotions.staff_id, staff_department.dept_id, staff.staffno, ranks.rank FROM promotions, ranks,  staff_department, staff WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id AND staff.id = promotions.staff_id AND ranks.id = promotions.rank AND staff_department.dept_id=3
GROUP BY promotions.rank


#WITH DEPARMENT
SELECT COUNT(promotions.rank) as SUMMATION, promotions.staff_id, staff_department.dept_id, staff.staffno, ranks.rank FROM promotions, ranks,  staff_department, staff WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id AND staff.id = promotions.staff_id AND ranks.id = promotions.rank AND staff_department.dept_id=3
GROUP BY promotions.rank

SELECT SUM(pp.SUMMATION) FROM ( SELECT COUNT(promotions.rank) as SUMMATION, promotions.staff_id, staff_department.dept_id, staff.staffno, ranks.rank FROM promotions, ranks,  staff_department, staff WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id AND staff.id = promotions.staff_id AND ranks.id = promotions.rank AND staff_department.dept_id=3
GROUP BY promotions.rank) as pp

#FULL DEFINITION
SELECT COUNT(hrdb.promotions.rank) as SUMMATION, hrdb.promotions.staff_id, hrdb.staff_department.dept_id, hrdb.staff.staffno, hrdb.ranks.rank FROM hrdb.promotions, hrdb.ranks,  hrdb.staff_department, hrdb.staff WHERE hrdb.promotions.promotion_indicator = 1 AND hrdb.staff_department.staff_id = hrdb.promotions.staff_id AND hrdb.staff.id = hrdb.promotions.staff_id AND hrdb.ranks.id = hrdb.promotions.rank AND hrdb.staff_department.dept_id=3
GROUP BY hrdb.promotions.rank

SELECT COUNT(hrdb.promotions.rank) as SUMMATION, hrdb.promotions.staff_id, hrdb.staff_department.dept_id, hrdb.staff.staffno, hrdb.ranks.rank FROM hrdb.promotions, hrdb.ranks,  hrdb.staff_department, hrdb.staff WHERE hrdb.promotions.promotion_indicator = 1 AND hrdb.staff_department.staff_id = hrdb.promotions.staff_id AND hrdb.staff.id = hrdb.promotions.staff_id AND hrdb.ranks.id = hrdb.promotions.rank
GROUP BY hrdb.promotions.rank ORDER BY hrdb.staff_department.dept_id

SELECT COUNT(hrdb.promotions.rank) as SUMMATION, hrdb.staff_department.dept_id, hrdb.staff.staffno, hrdb.ranks.rank FROM hrdb.promotions INNER JOIN hrdb.ranks on, hrdb.staff_department, hrdb.staff WHERE (hrdb.promotions.promotion_indicator = 1 AND hrdb.staff_department.staff_id = hrdb.promotions.staff_id AND hrdb.staff.id = hrdb.promotions.staff_id AND hrdb.ranks.id = hrdb.promotions.rank AND hrdb.staff_department.dept_id=3) GROUP BY hrdb.promotions.rank;


SELECT COUNT(hrdb.promotions.rank) as SUMMATION, hrdb.ranks.rank FROM hrdb.promotions INNER JOIN hrdb.ranks on hrdb.promotions.rank = hrdb.ranks.id INNER JOIN hrdb.staff_department on hrdb.promotions.staff_id = staff_department.staff_id INNER JOIN hrdb.staff ON hrdb.promotions.staff_id = staff.id WHERE (hrdb.promotions.promotion_indicator = 1 AND hrdb.staff_department.staff_id = hrdb.promotions.staff_id AND hrdb.staff.id = hrdb.promotions.staff_id AND hrdb.ranks.id = hrdb.promotions.rank AND hrdb.staff_department.dept_id=3) GROUP BY hrdb.promotions.rank;


SELECT COUNT(hrdb.promotions.rank) as SUMMATION, hrdb.promotions.staff_id, hrdb.staff_department.dept_id, hrdb.staff.staffno, hrdb.ranks.rank FROM hrdb.promotions, hrdb.ranks,  hrdb.staff_department, hrdb.staff WHERE hrdb.promotions.promotion_indicator = 1 AND hrdb.staff_department.staff_id = hrdb.promotions.staff_id AND hrdb.staff.id = hrdb.promotions.staff_id AND hrdb.ranks.id = hrdb.promotions.rank
GROUP BY hrdb.promotions.rank ORDER BY hrdb.staff_department.dept_id

SELECT COUNT(hrdb.promotions.rank) as SUMMATION, hrdb.promotions.staff_id, hrdb.staff_department.dept_id, hrdb.department.description, hrdb.staff.staffno, hrdb.ranks.rank FROM hrdb.promotions, hrdb.ranks,  hrdb.staff_department, department, hrdb.staff WHERE hrdb.promotions.promotion_indicator = 1 AND hrdb.staff_department.staff_id = hrdb.promotions.staff_id AND hrdb.staff.id = hrdb.promotions.staff_id AND hrdb.ranks.id = hrdb.promotions.rank AND department.id= staff_department.dept_id AND staff.status=1 GROUP BY hrdb.promotions.rank ORDER BY hrdb.staff_department.dept_id;