<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\RankPromotionModel;
use App\SalaryScale;
use App\Rank;

class RankPromotionStructureController extends Controller
{
    public function __construct()
    {
    	$this->middleware('auth');
    }

    public function index(Request $request)
    {
    	if($this->isNew()==true) return $this->actNew();

      if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
         return redirect('home');
      }

      $rank_promotion_model = RankPromotionModel::all();
      $ranks = Rank::all();

    	return view('settings.rankpromotionform', ['salaryscale' => SalaryScale::all(), 'rank_promotion_model' => $rank_promotion_model, 'rank' => $ranks ]);
    }

    public function create(Request $request)
    {
    	return redirect('rank_promotion_setting');
    }

    /**
		 * [store the showSalaryStructureForm description]
		 * @param  Request $request [description]
		 * @return [type]           [description]
		 */
    public function store(Request $request)
    {

    	if($this->isNew()==true) return $this->actNew();

      if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
         return redirect('home');
      }

      $request->validate([
      	'salaryscale' => 'integer|required',
      	'old_rank' => 'integer|required',
      	'new_rank' => 'integer|required'
      ]);

      $old_rank = $request->input('old_rank');
      $new_rank = $request->input('new_rank');
      $salaryscale = $request->input('salaryscale');

      try {
	      $salaryScaleStepPM = RankPromotionModel::create([
	      	'salaryscale' => $salaryscale,
	      	'old_rank' => $old_rank,
	      	'new_rank' => $new_rank
	      ]);
      }catch (\Exception $e) {
				return redirect('rank_promotion_setting')->with('status', 'Salary Scale With This Old-Rank Already Exists');
      }

      return redirect('rank_promotion_setting')->with('status', 'Successfully Added New Rank Promotion Rules');

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $rankPromotionModelId
     * @return \Illuminate\Http\Response
     */
    public function edit(int $rankPromotionModelId)
    {

        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $thisRankPromotionModel = RankPromotionModel::findOrFail($rankPromotionModelId);

        $rank_promotion_model = RankPromotionModel::all();
      	$ranks = Rank::all();

	    	return view('settings.rankpromotionform', ['salaryscale' => SalaryScale::all(), 'rank_promotion_model' => $rank_promotion_model, 'rank' => $ranks, 'this_rankpromotionId' => $thisRankPromotionModel ])->with('displaystate', 'edit');
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int $rankPromotionRuleId
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, int $rankPromotionRuleId)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $request->validate([
            'salaryscale' => 'required|integer|min:1',
            'old_rank' => 'required',
            'new_rank' => 'required'
        ]);

        $old_rank = $request->input('old_rank');
        $new_rank = $request->input('new_rank');
        $salaryscale_id = $request->input('salaryscale');

        $thisSalaryScale = SalaryScale::findOrFail($salaryscale_id);
        $thisRankPromotionModel = RankPromotionModel::findOrFail($rankPromotionRuleId);

        $anyOtherRankPromotionModel = RankPromotionModel::where('salaryscale', $salaryscale_id)->where('old_rank', $old_rank)->first();

        $updateModel = false;

        if(is_null($anyOtherRankPromotionModel)){
        	$updateModel = true;
        }elseif($anyOtherRankPromotionModel->id == $thisRankPromotionModel->id){
        	$updateModel = true;
        }

        if($updateModel){
        	$thisRankPromotionModel->old_rank = $old_rank;
        	$thisRankPromotionModel->new_rank = $new_rank;
        	$thisRankPromotionModel->salaryscale = $salaryscale_id;
        	$thisRankPromotionModel->save();
        }

        return redirect('rank_promotion_setting/'.$rankPromotionRuleId)->with('salaryscale', "Rank Promotion Rules Updated Successfully");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $salaryScaleStepPromotionId
     * @return \Illuminate\Http\Response
     */
    public function show(int $salaryScaleStepPromotionId)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $thisRankPromotionModel = RankPromotionModel::findOrFail($salaryScaleStepPromotionId);

        $rank_promotion_model = RankPromotionModel::all();

        $ranks = Rank::all();

        $action = isset($_GET['action']) ? ($_GET['action'] == 'del'? 'delete' : 'show') : 'show';

        return view('settings.rankpromotionform', ['salaryscale' => SalaryScale::all(), 'rank_promotion_model' => $rank_promotion_model, 'rank' => $ranks, 'this_rankpromotionId' => $thisRankPromotionModel ])->with('displaystate', $action);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $salaryScaleStepPromotionId
     * @return \Illuminate\Http\Response
     */
    public function destroy(int $salaryScaleStepPromotionId)
    {
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }
        $thisRankPromotionModel = RankPromotionModel::findOrFail($salaryScaleStepPromotionId);

        $thisRankPromotionModel->delete();

        return redirect('rank_promotion_setting')->with('salaryscale', "Rank Promotion Rule Deleted Successfully");
    }


}
