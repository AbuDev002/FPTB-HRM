<?php

namespace App\Http\Controllers;

use App\Position;
use Illuminate\Http\Request;

class PositionController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');//->except('logout');
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
            return redirect('home');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
            return redirect('home');
        }
        return view('position/addnewposition')->with('position', Position::all());}

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }
        $position = $request->input('position');

        $request->validate([
            'position' => 'required|unique:positions,position,'.$position,
            'description' => 'present'
        ]);

        Position::create([
            'position' => $request->input('position'),
            'description' => $request->input('description')
        ]);

        return redirect('position/create')->with('status', 'Position Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Position  $position
     * @return \Illuminate\Http\Response
     */
    public function show(Position $position)
    {
        $aPosition = Position::findOrFail($position);
        $action = isset($_GET['action']) ? ($_GET['action'] == 'del'? 'delete' : 'show') : 'show';

        return view('position/addnewposition')->with('position', $aPosition )
            ->with('displaystate', $action);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Position  $position
     * @return \Illuminate\Http\Response
     */
    public function edit(Position $position)
    {
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $aPosition = Position::findOrFail($position);
        return view('position/addnewposition')->with('position', $aPosition )
            ->with('displaystate', 'edit');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Position  $position
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Position $position)
    {
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $request->validate([
            'position' => 'required',
            'description' => 'present'
        ]);

        $thisPosition = Position::findOrFail($position)->first();

        $thisPosition->position = $request->input('position');
        $thisPosition->description = $request->input('description') == null? "":$request->input('description');
        $thisPosition->save();

        return redirect('position/'.$thisPosition->id)->with('status', 'Position Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Position  $position
     * @return \Illuminate\Http\Response
     */
    public function destroy(Position $position)
    {
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }
        
        $position->delete();
        return redirect('position/create')->with('status', 'Position Deleted Successfully');
    }
}
