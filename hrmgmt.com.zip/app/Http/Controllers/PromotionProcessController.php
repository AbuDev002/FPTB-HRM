<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SalaryScaleStepPromotionModel;
use App\SalaryScale;
use \PDF;
use App\Staff;

class PromotionProcessController extends Controller
{
    public function __construct()
		{
			$this->middleware('auth');
		}

		public function create(Request $request)
		{
			       return redirect('promotion_upload_process');
		}

		/**
		 * [Index to showSalaryStructureForm description]
		 * @param  Request $request [description]
		 * @return [type]           [description]
		 */
    public function index(Request $request)
    {

    	if($this->isNew()==true) return $this->actNew();

      if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
         return redirect('home');
      }

      $salaryscale_with_steps = SalaryScaleStepPromotionModel::all();



    	return view('settings.promotionuploadprocessform', ['salaryscale' => SalaryScale::all(), 'salaryscalestructure_with_steps' => $salaryscale_with_steps]);
    }


    public function store(Request $request)
    {
        $filePath = "";
        if($request->hasFile('uploadfile')){
            if($request->file('uploadfile')->isValid()) {
                $filePath = $request->uploadfile->store('promotefile');
                printf("\n%s\n", "FILE UPLOADED SUCCESSFULLY, WAITING FOR PROCESSING OR PROMOTING STAFF DATA");
                
                var_dump($filePath);
                printf("\n%s\n", "PROCESSING STAFF PROMOTION DELEGATED TO CRON JOB");

                return redirect('promotion_upload_process')->with('status', 'FILE UPLOADED SUCCESSFULLY, WAITING FOR PROCESSING OR PROMOTING STAFF DATA');

            }
        }else{
        	return redirect('promotion_upload_process')->with('status', 'ERROR UPLOADING FILE');
        }
    }

    public function correctStaffRecordUpload(Request $request)
    {
        $filePath = "";
        if($request->hasFile('uploadfile')){
            if($request->file('uploadfile')->isValid()) {
                $filePath = $request->uploadfile->store('staffgradelevelupdate');
                printf("\n%s\n", "FILE UPLOADED SUCCESSFULLY, WAITING FOR PROCESSING OR UPDATING STAFF DATA");
                
                var_dump($filePath);
                printf("\n%s\n", "PROCESSING STAFF DATA CORRECTION PROCESS DELEGATED TO CRON JOB");

                return redirect('promotion_upload_process')->with('status', 'FILE UPLOADED SUCCESSFULLY, WAITING FOR PROCESSING OR CORRECTING STAFF DATA');

            }
        }else{
        	return redirect('promotion_upload_process')->with('status', 'ERROR UPLOADING FILE');
        }
    }

    public function generatePDF( Request $request )
    {
    	$promotedstaff = Staff::whereIn('staffno', ['1060SS', '1988JS'])->get()->all();

    	$cd = \Carbon\Carbon::now();

    	$ccd = $cd->toDateString();


    	//==========================
 $path = 'storage/app/public/signsample.png';
                            $path = 'signsample.png';
                            $path = Storage::disk('public')->url('signsample.png');

                            $full_path = $path;
                            $base64 = base64_encode($path);
                            $image_data = 'data:'.mime_content_type($full_path) . ';base64,' . $base64;
                            die($image_data);
    	//==========================

    	$data = ['title' => 'Welcome To Staff Promotion Report', 'staffs' => $promotedstaff , 'council_count' => '88th', 'registrar' => 'Haj. Rakiya U. Maleka', 'todays_date' => $ccd ];

    	$pdf =  PDF::loadView('myPDF', $data);

    	$rand = rand(450, 898989);
    	$pdf->save(storage_path("app/public/promotions/promotionletters.pdf"));
    	
    	return $pdf->download('testitsolution.pdf');

    }

    public function getPromotionLetters(Request $request)
    {
    	$path =  storage_path("app/public/promotions/promotionletters.pdf");
    	echo "$path";

    	if(file_exists($path)){
    		return response()->download($path, 'Staff Promotional Letters.pdf');
    	}else
    	return redirect('home');

    }
}
