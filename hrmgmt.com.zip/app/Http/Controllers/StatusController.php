<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Status;

class StatusController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');//->except('logout');
        if($this->isNew()==true) return $this->actNew();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if($this->isNew()==true) return $this->actNew();
        if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
            return redirect('home');
        }

        return redirect('status/create');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if($this->isNew()==true) return $this->actNew();
        if(\Auth::user()->access_level == \App\Staff::$USER_STAFF){
            return redirect('home');
        }

        return view('status/addnewstatus', ['status' => Status::all()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if($this->isNew()==true) return $this->actNew();
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $request->validate([
            'status' => 'required|unique:statuses,status',
            'description' => 'present'
        ]);

        Status::create([
            'status' => $request->input('status'), 
            'description' => $request->input('description')
        ]);

        return redirect('status/create')->with('status', 'Status Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Status  $status
     * @return \Illuminate\Http\Response
     */
    public function show(Status $status)
    {
        if($this->isNew()==true) return $this->actNew();

        $thisStatus = Status::findOrFail($status);

        $action = isset($_GET['action']) ? ($_GET['action'] == 'del'? 'delete' : 'show') : 'show';

        return view('status/addnewstatus')->with('status', $thisStatus)
            ->with('displaystate', $action);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Status  $status
     * @return \Illuminate\Http\Response
     */
    public function edit(Status $status)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $thisStatus = Status::findOrFail($status);

        return view('status/addnewstatus')->with('status', $thisStatus)
            ->with('displaystate', 'edit');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Status $status
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Status $status)
    {
        if($this->isNew()==true) return $this->actNew();

        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }

        $request->validate([
            'status' => 'required',
            'description' => 'present'
        ]);

        $thisStatus = Status::findOrFail($status);

        $thisStatus = $thisStatus->first();

        $thisStatus->status = $request->input('status');
        $thisStatus->description = $request->input('description');

        $thisStatus->save();

        return redirect('status/'.$thisStatus->id)->with('status', "Status Updated Successfully");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Status $status
     * @return \Illuminate\Http\Response
     */
    public function destroy(Status $status)
    {
        if($this->isNew()==true) return $this->actNew();
        
        if(\Auth::user()->access_level != \App\Staff::$USER_ADMIN ){
            return redirect(request()->headers->get('referer'));
        }
        
        $status->delete();
        return redirect('status/create')->with('status', "Status Deleted Successfully");
    }
}
