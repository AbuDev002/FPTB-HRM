<?php

namespace App\Http\Controllers;

use DB;
use App\Leave;
use App\Department;
use App\Level;
use Illuminate\Http\Request;
use App\Staff;
use App\Status;
use \Carbon\Carbon;
use \App\Promotions;

class LeaveController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');//->except('logout');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {

        $staff_id = $request->query('staff_id');
        $staff_status = $request->query('status');

        $thisStaff = Staff::find($staff_id);

        $thisStatus = Status::find($staff_status);

        $allLeave = DB::table('leave')->get()->all();

        $department = Department::where('is_currently_active', 1)->get()->all();
        $level = Level::all();
        // dd($thisStatus);
        return view('leave.manageleave', ['department'=>$department, 'level' => $level, 'staff'=>$thisStaff, 'status'=> $thisStatus, 'allLeave'=> $allLeave]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $fromDate = $request->input('leavefrom');
        $toDate = $request->input('leaveto');
        $onDate = $request->input('leaveon');
        $staffno = $request->input('staffno');
        $staff_id = $request->input('staff_id');
        $leave_desc = $request->input('statusdescription');
        $status = $request->input('status_id');
        $range_type = $request->input('daterangetype');

        if($range_type == Leave::RANGE_TWO){

            $request->validate([
                'leavefrom' => 'required|date',
                'leaveto' => 'required|date',
                'statusdescription' => 'required',
                'daterangetype' => 'required'
                ]);


            $leave_exists = Leave::where('staff_id', $staff_id)->where('status', Leave::ACTIVE)->get();
            // $leave_exists = Leave::where('staff_id', $staff_id)->where('status', Leave::ACTIVE)->where('range_type', Leave::RANGE_TWO)->get();

            if($leave_exists->count() == 0){ // no existing active leave for this staff
                // add new leave record
                $thisLeave = Leave::create([
                    'from' => $fromDate,
                    'to' => $toDate,
                    'staff_id' => $staff_id,
                    'description' => $leave_desc,
                    'created_at' => Carbon::now(),
                    'updated_at' => Carbon::now(),
                    'status' => Leave::ACTIVE,
                    'range_type' => Leave::RANGE_TWO
                    ]);

                    $thisStaff_CurrentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
                    ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
                    ->where('staff_id', $staff_id)->get()->first();

                    // copy the model of the current promotion
                    $newStaffPromotion = $thisStaff_CurrentPromotion->replicate();
                    //update and save
                    $newStaffPromotion->staff_status = $status;
                    $newStaffPromotion->description = $leave_desc;
                    $newStaffPromotion->save();

                    //change the promotion to past
                    $thisStaff_CurrentPromotion->promotion_indicator = Promotions::$PAST_PROMOTION;
                    $thisStaff_CurrentPromotion->save();

                    $thisStaff = Staff::find($staff_id);
                    $thisStaff->status = $status;
                    $thisStaff->save();

                    return redirect('leave/create')->with('success', "Staff Status Has Been Updated");

                }else{
                    return redirect('leave/create')->with('error', "Staff Status Already Exists");
                }
            }else{
                // dd($request->input());
                $request->validate([
                    'leaveon' => 'required|date',
                    'statusdescription' => 'required',
                    'daterangetype' => 'required'
                ]);

                $thisStaff_CurrentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
                    ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
                    ->where('staff_id', $staff_id)->get()->first();

                        // copy the model of the current promotion
                $newStaffPromotion = $thisStaff_CurrentPromotion->replicate();
                        //update and save
                $newStaffPromotion->staff_status = $status;
                $newStaffPromotion->description = $leave_desc;
                // $newStaffPromotion->updated_at = $onDate;
                $newStaffPromotion->save();

                        //change the promotion to past
                $thisStaff_CurrentPromotion->promotion_indicator = Promotions::$PAST_PROMOTION;
                $thisStaff_CurrentPromotion->save();

                $thisStaff = Staff::find($staff_id);
                $thisStaff->status = $status;
                $thisStaff->save();

                return redirect('staff/'.$thisStaff->id)->with('success', "Staff Status Has Been Updated");
            }

    }

    public function resolver(Request $request)
    {
        $resolver = Leave::where('to', '<=', now())->where('status', Leave::ACTIVE)->get()->all();
        foreach($resolver as $each_resolver){

            $each_resolver->status = \App\Leave::INACTIVE;
            $each_resolver->save();

            $thisStaff = Staff::find($each_resolver->staff_id);
            $thisStaff->status = 1; // This means now active
            $thisStaff->save();

            // ===========================
            $thisStaff_CurrentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
                ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
                ->where('staff_id', $thisStaff->id)->get()->first();


        // copy the model of the current promotion
            $newStaffPromotion = $thisStaff_CurrentPromotion->replicate();

        //update and save
            $newStaffPromotion->staff_status = 1; // Now ACTIVE
            $newStaffPromotion->save();

        //change the promotion to past
            $thisStaff_CurrentPromotion->promotion_indicator = Promotions::$PAST_PROMOTION;
            $thisStaff_CurrentPromotion->save();

            $thisStaff->status = 1;
            $thisStaff->save();
            // ==========================

           dd("ALL LEAVE HAS DONE");
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function show(Leave $leave)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function edit(Leave $leave)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Leave $leave)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function destroy(Leave $leave)
    {
        //
    }
}
