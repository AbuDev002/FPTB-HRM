<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    protected $table = "department";
    protected $fillable = ['department', 'school', 'description'];


    public function getDepartment($full = false)
    {
    	if($full)
    		return ($this->department . " - " . $this->description);
    	else
    		return $this->department;
    }

    public function getSchool()
    {
    		return School::find($this->school)->school;
    }

}
