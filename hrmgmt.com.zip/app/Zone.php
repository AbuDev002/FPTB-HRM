<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Zone extends Model
{
    protected $fillable = [ 'gpzone', 'description' ];

    public function getZone() : string
    {
    	return $this->gpzone . " - " . $this->description;
    }
}
