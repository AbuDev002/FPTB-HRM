<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalaryScaleStepPromotionModel extends Model
{
    protected $table = 'promotion_grade_levels_steps';
    public $timestamps = false;

    protected $fillable = ['salaryscale', 'oldgrade', 'newgrade'];

    public function getSalaryScale()
    {
    	return SalaryScale::find($this->salaryscale)->salaryscale;
    }
}
