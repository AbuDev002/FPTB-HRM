<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use \App\SalaryScale;
use \App\AdditionalResponsibility;

class Promotions extends Model
{
    protected $table="promotions";
    protected $fillable=[ 'staff_id', 'promotion_date', 'status', 'description',
    	'position', 'con___', 'staffclass', 'rank', 'category', 'step', 'promotion_indicator', 'presentappointdate', 'appointmenttype', 'staff_status', 'salary_scale_value', 'salary_scale', 'date_of_status_update' ];

    public static $CURRENT_PROMOTION = 1;
    public static $PAST_PROMOTION = 2;

    public static $APPROVED_PROMOTION = 1;
    public static $DISAPPROVED_PROMOTION = 2;

    public static $IS_LAST_PROMOTED = 1;
    public static $IS_NOT_YET_LAST_PROMOTED = 0;



    public function getRank():string
    {
    	$rank = \App\Rank::find($this->rank);
    	return $rank->rank;
    }

    public function getStaffStatus():string
    {
			$status = \App\Status::find($this->staff_status)->status;
			return $status;
    }

    public function getCon__Title()
    {
        $con_title = $this->staffclass == "AS"? "CONPCASS" : "CONTEDISS";
        $salary_scale = $this->getSalaryScale();
    	return $salary_scale;
    }

    public function getStaffClass()
    {
    	$staffclass_ = $this->staffclass == "AS"? "AS - Academic Staff" : "NA - Non-Academic Staff";
    	return $staffclass_;
    }

    public function getCon__()
    {
    	return $this->con___;
    }

    public function getSalaryScale(){
        if(empty($this->salary_scale))
            return '';
        else
            return SalaryScale::find($this->salary_scale)->salaryscale;
    }

    public function getPosition():string
    {
    	$position = Position::find($this->position)->position ?? "NONE";
    	return $position;
    }

    public function getAddedResponsibilities():array
    {
        $additionalResponsibilities = AdditionalResponsibility::getStaffAdditionalResponsibilities($this->id);
        $additionalResponsibilitiesArray = AdditionalResponsibility::getStaffAddedResponsibilitiesArray($this->id);

        return [
            'additionalResponsibilities'=> $additionalResponsibilities,
            'additionalResponsibilitiesArray' => $additionalResponsibilitiesArray
        ];
    }

    public function getAppointmentType():string
    {
    	$appointmenttype = \App\AppointmentType::find($this->appointmenttype)->getAppointmentType();
    	return $appointmenttype;
    }

}
