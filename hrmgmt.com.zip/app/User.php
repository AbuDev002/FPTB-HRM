<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use DB;
use App\LoginHistory;
use Auth;
use App\Staff;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use Notifiable;
    use HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'access_level', 'username', 'status', 'photo'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public static $USER_ACCOUNT_STATUS_ENABLED = 1;
    public static $USER_ACCOUNT_STATUS_DISABLED = 2;

    public function isOnline()
    {
        $res = [];
        
        $sessionsLast = DB::table('sessions')->select('id', 'user_id', 'ip_address', 'user_agent', 'payload', 'last_activity')->where('user_id', '=', $this->id)->orderBy('last_activity', 'desc')->get();

        $loginHistory = LoginHistory::where('user_id', $this->id)->orderBy('created_at', 'desc');
        $last_loginLH = $loginHistory->limit(1)->get();

        if($sessionsLast->count() > 0){
            $thisSession = $sessionsLast->first();
            $thisSession->last_activity;

            $cT = \Carbon\Carbon::createFromTimestamp($thisSession->last_activity);

            $diff_in_minutes = $cT->diffInMinutes(\Carbon\Carbon::now());


            if($diff_in_minutes <= 10){
                return [ 'online'=>true, 'active'=>true, 'last_activity' => $cT->diffForHumans() ];
            }elseif ($diff_in_minutes > 10 && $diff_in_minutes <= 30) {
                return [ 'online'=>true, 'active'=>false, 'last_activity' => $cT->diffForHumans() ];
            }else{
                return [ 'online'=>false, 'active'=>false, 'last_activity' => $cT->diffForHumans() ];
            }
        }else{
            return [ 'online'=>false, 'active'=>false, 'last_activity' => 'long time ago' ];
        }
        
    }

    public function lastLogin()
    {

        $loginHistory = LoginHistory::where('user_id', $this->id)->orderBy('created_at', 'desc');
        $last_loginLH = $loginHistory->limit(1)->get();
        $lastLogin = "";

        if($last_loginLH->count() == 0){
            $lastLogin = "Yet To Login";
        }else{
           
           $last_loginLHTime = \Carbon\Carbon::parse($last_loginLH->first()->created_at); 
           $lastLogin = $last_loginLHTime->diffForHumans();
           
        }

        return $lastLogin;

    }

    public function loginHistory()
    {
        // $this->logout();
        $loginHistory = LoginHistory::where('user_id', $this->id)->where('created_at', '>=', \Carbon\Carbon::now()->subMonth())->orderBy('created_at', 'desc')->get()->all();
        return $loginHistory;
    }

    public function logout($request)
    {
        if(Auth::user()->access_level != \App\Staff::$USER_ADMIN){
            return redirect("home");
        }

        // $sessionsLast = DB::table('sessions')->select('id', 'user_id', 'ip_address', 'user_agent', 'payload', 'last_activity')->where('user_id', '=', $this->id)->orderBy('last_activity', 'desc')->get()->all();

        $platformName = \Browser::platformName();
        $browserName = \Browser::browserName();
        
        \App\LoginHistory::create([
                'user_id' => $this->id,
                'admin_id' => Auth::id(),
                'type' => \App\LoginHistory::$LOGOUT_TYPE,
                'user_status' => $this->status,
                'session_id' => session()->getId(),
                'username' => $this->username,
                'browser' => $browserName,
                'platform' => $platformName,
                'ip' => $request->ip()
            ]);

        $sessionsLast = DB::table('sessions')->where('user_id', '=', $this->id)->delete();
    }

    public function getStaffId() : int
    {
        try{
            $staff_id = Staff::where('staffno', $this->username)->get()->first()->id;
            return $staff_id;
        }catch(\Exception $ex){
            return 0;
        }
    }

    public function isAdmin() : bool
    {
        if($this->access_level == Staff::$USER_ADMIN){
            return true;
        }
        return false;
    }

    public function isSubAdmin() : bool
    {
        if($this->access_level == Staff::$USER_SUBADMIN){
            return true;
        }
        return false;
    }

    public function isStaff() : bool
    {
        if($this->access_level == Staff::$USER_STAFF){
            return true;
        }
        return false;
    }
}