<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;

class FirstTimeLoginResetModel extends Model
{
        protected $fillable=[ 'user_id', 'reset_status' ];

        public const FIRST_TIME_LOGIN = 0;
        public const PASSWORD_RESET_REQUIRED = 1;
        public const PASSWORD_UPDATED = 2;

        public static function isPasswordUpdateRequired($user_id): bool {
        	$thisUser = User::find($user_id);
        	if($thisUser){
        		$firstTimeLogin = FirstTimeLoginResetModel::where('user_id', $user_id)->get();
        		if($firstTimeLogin->count() > 0){
        			$firstLogin = $firstTimeLogin->first();
        			if($firstLogin->reset_status == FirstTimeLoginResetModel::PASSWORD_RESET_REQUIRED){
        				return true;
        			}
        		}else{
        			return true;
        		}
        	}
        	return false;
        }

        public static function setPasswordUpdateRequired($user_id)
        {
        		$firstTimeLogin = FirstTimeLoginResetModel::where('user_id', $user_id)->get();
        		if($firstTimeLogin->count() > 0){
	        			$firstLogin = $firstTimeLogin->first();
	        			if($firstLogin->reset_status == FirstTimeLoginResetModel::PASSWORD_RESET_REQUIRED){
	        				return true;
	        			}else{
	        				$firstLogin->reset_status = FirstTimeLoginResetModel::PASSWORD_RESET_REQUIRED;
	        				$firstLogin->save();
	        				return true;
	        			}
	        	}else{
	        		$firstTimeLogin = FirstTimeLoginResetModel::create([
	        			'user_id' => $user_id,
	        			'reset_status' => FirstTimeLoginResetModel::PASSWORD_RESET_REQUIRED
	        		]);
	        		$firstTimeLogin->save();
	        		return true;
	        	}
        }

        public static function setPasswordUpdated($user_id)
        {
        	$firstTimeLogin = FirstTimeLoginResetModel::where('user_id', $user_id)->get();
        		if($firstTimeLogin->count() > 0){
	        			$firstLogin = $firstTimeLogin->first();
	        			if($firstLogin->reset_status == FirstTimeLoginResetModel::PASSWORD_UPDATED){
	        				return true;
	        			}else{
	        				$firstLogin->reset_status = FirstTimeLoginResetModel::PASSWORD_UPDATED;
	        				$firstLogin->save();
	        				return true;
	        			}
	        	}
	        	elseif(FirstTimeLoginResetModel::isPasswordUpdateRequired($user_id)){
	        		try{
		        		$firstTimeLogin = FirstTimeLoginResetModel::create([
		        			'user_id' => $user_id,
		        			'reset_status' => FirstTimeLoginResetModel::PASSWORD_UPDATED
		        		]);

		        		$firstTimeLogin->save();
		        		return true;
		        	}catch(\Exception $ex){
		        		Log::warning('Unable To Set PASSWORD_UPDATED for this User ' . $user_id);
		        		return false;
		        	}
	        		return true;
	        	}
	        	
	        	return false;
        }
}
