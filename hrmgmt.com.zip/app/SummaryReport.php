<?php

namespace App;
use \DB;

class SummaryReport
{
    /**
     * Gets the Summary Record for a given department
     * With Staff Having a Particular Status
     * @param  int    $department # This is the department Under Consideration
     * @param  int    $status     # This is the status of the staff
     * @return array
     */
    public static function getRecords(int $department, bool $status_inverse = false, int $status = 1):array
    {
        if(!$status_inverse){
            $qqq = DB::select("SELECT COUNT(promotions.rank) as SUMMATION, promotions.staff_id, staff_department.dept_id, statuses.status, department.description, staff.staffno, ranks.rank FROM promotions, ranks,  staff_department, department, staff, statuses WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id AND staff_department.status=1 AND staff.id = promotions.staff_id AND ranks.id = promotions.rank AND department.id= staff_department.dept_id AND staff_department.dept_id = $department AND staff.status=$status AND staff.status = statuses.id GROUP BY promotions.rank ORDER BY staff_department.dept_id");
        }else{

            $qqq = DB::select("SELECT COUNT(promotions.rank) as SUMMATION, promotions.staff_id, staff_department.dept_id, statuses.status, department.description, staff.staffno, ranks.rank FROM promotions, ranks,  staff_department, department, staff, statuses WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id AND staff_department.status=1 AND staff.id = promotions.staff_id AND ranks.id = promotions.rank AND department.id= staff_department.dept_id AND staff_department.dept_id = $department AND staff.status!=$status AND staff.status = statuses.id GROUP BY promotions.rank ORDER BY staff_department.dept_id");

        }
        return $qqq;
    }

    /**
     * Gets the Summary HOD Record for all department
     * With Staff Having a Particular Status
     * @param  int    $status     # This is the status of the staff
     * @return array
     */
    public static function getHods(bool $status_inverse = false, int $status = 1):array
    {
        if (!$status_inverse) {
            $qqq = DB::select("SELECT ranks.rank, promotions.rank as rankId, promotions.staff_id, concat(staff.fname,' ', staff.lname, ' ', staff.oname) as fullname, positions.position, department.description, staff_department.staff_id, staff_department.dept_id, statuses.status, staff.staffno FROM promotions, ranks, staff_department, staff, department, positions, statuses WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id  AND staff_department.status=1  AND promotions.position=1 AND positions.id=promotions.position AND staff.id = promotions.staff_id AND department.id=staff_department.dept_id AND promotions.rank=ranks.id AND staff.status=$status AND staff.status = statuses.id ORDER BY staff_department.dept_id");
        }else{
            $qqq = DB::select("SELECT ranks.rank, promotions.rank as rankId, promotions.staff_id, concat(staff.fname,' ', staff.lname, ' ', staff.oname) as fullname, positions.position, department.description, staff_department.staff_id, staff_department.dept_id, statuses.status, staff.staffno FROM promotions, ranks, staff_department, staff, department, positions, statuses WHERE promotions.promotion_indicator = 1 AND staff_department.staff_id = promotions.staff_id  AND staff_department.status=1  AND promotions.position=1 AND positions.id=promotions.position AND staff.id = promotions.staff_id AND department.id=staff_department.dept_id AND promotions.rank=ranks.id AND staff.status!=$status AND staff.status = statuses.id ORDER BY staff_department.dept_id");

        }

        return $qqq;
    }

    /**
     * Returns the staff Count
     * @param string $status
     *
     * @return mixed
     */
    public static function getStaffCount(string $status = 'leave') : int{
        $status_obj = \App\Status::where('status', 'like', $status)->get()->first();
        return \App\Staff::where('status', $status_obj != null? $status_obj->id : 0  )->get()->count();
    }

    public static function getPromotionNotification(){

        $chief_ranks = \App\Rank::where('rank', 'like', '%Chief%')->get()->pluck('id')->all();

        $contract_staffs = \App\AppointmentType::where('appointmenttype', 'like', '%CONTR%')->pluck('id')->all();

        $special_ranks = \App\Rank::where('rank', 'RECTOR')
            ->where('rank', 'BURSAR')
            ->where('rank', 'DEPUTY REGISTRAR')
            ->where('rank', 'POLYTECHNIC LIBRARIAN')
            ->where('rank', 'DEPUTY RECTOR')
            ->get()->pluck('id')->all();

        $staff = Staff::all();
        $count = 0;
        foreach ($staff as $eachStaff) {
            $currentPromotion = \App\Promotions::where('status', \App\Promotions::$APPROVED_PROMOTION)
                ->where('promotion_indicator', \App\Promotions::$CURRENT_PROMOTION)->where('staff_id', $eachStaff->id)->get()->first();

            $rank = \App\Rank::find($currentPromotion->rank);
            $status = \App\Status::find($currentPromotion->staff_status)->status;
            $thisDate = $currentPromotion->presentappointdate;
            $datework = \Carbon\Carbon::parse($thisDate);
            $now = \Carbon\Carbon::now();

            $yearDifference = ($now->year - $datework->year);
            // $yearDifference = ($datework->year + 3);
            $permanent_staffs = \App\AppointmentType::where('appointmenttype', 'like', '%PERM%')->pluck('id')->all();

            if ($yearDifference >= 3) {
                if(!in_array($currentPromotion->rank, $chief_ranks)  && !in_array($currentPromotion->rank, $special_ranks) && in_array($currentPromotion->appointmenttype, $permanent_staffs) && ($currentPromotion->last_promotion_status != \App\Promotions::$IS_LAST_PROMOTED)){
                    $count++;
                }
            }
        }
        return $count;
    }

}