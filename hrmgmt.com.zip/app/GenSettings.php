<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GenSettings extends Model
{
    protected $table = "gen_settings";

    protected $fillable = [
        'name', 'value'
    ];

    public static function showEnable(): bool
    {
    	$first = GenSettings::first();
    	if(is_null($first)){
	    	$gen = GenSettings::create([
	    		"name" => "staff_edit",
	    		"value"=> "true"
	    	]);
	    	return true;
    	}else{
    		if($first->value == "true"){
    			return true;
    		}else{
    			return false;
    		}
    	}
    }

    public static function toggleEnable():bool
    {
    	if(self::showEnable()){
    		$first = GenSettings::first();
    		$first->value = "false";
    		$first->save();
    	}else{
    		$first = GenSettings::first();
    		$first->value = "true";
    		$first->save();
    	}

    	return true;
    }
}
