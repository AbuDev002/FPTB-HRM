<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use \App\Promotions;
use \App\State;
use \App\Lga;
use \App\Status;
use \App\Zone;
use \App\Department;
use \App\StaffUnitDepartment;
use \App\DepartmentUnit;

class Staff extends Model
{

    protected $fillable = ['fname', 'lname', 'oname', 'email', 'gender'
    	,'photo', 'staffno', 'dateobirth', 'address1', 'address2', 'status',
    	'state_id', 'lga_id', 'firstappointdate', 'staffclass', 'maritalstatus', 'phoneno', 'gpzone',
    	'nok_fname',	'nok_lname',	'nok_oname',	'nok_address',	'nok_phoneno',	'nok_relationship',	'child1_name',	'child1_age',	'child2_name',	'child2_age',	'child3_name',	'child3_age',	'child4_name',	'child4_age', 'appointmenttype'
    ];

    public static $USER_ADMIN = 1;
    public static $USER_SUBADMIN = 2;
    public static $USER_STAFF = 3;

    public static $NONE_ADDED_RESPONSIBLITY = 2;

   /* public static $USER_STATUS_ACTIVE = 1;
    public static $USER_STATUS_INACTIVE = 2;
    public static $USER_STATUS_LEAVE = 3;
    public static $USER_STATUS_DISMISSED = 4;
    public static $USER_STATUS_TRANSFERED = 5;*/

    public function getDetails()
    {

    	$state = State::find($this->state_id)->state ?? "NO STATE SET YET";
	    $lga = Lga::find($this->lga_id)->lga ?? "NO LGA YET";
	    $status = Status::find($this->status)->status ?? "NO STATUS YET";

        // get the current promotion for this staff
        // status = APPROVED
        // promotion_indicator = CURRENT_PROMOTION
	    $currentPromotion = \App\Promotions::where('status', \App\Promotions::$APPROVED_PROMOTION)
                                                ->where('promotion_indicator', \App\Promotions::$CURRENT_PROMOTION)->where('staff_id', $this->id)->orderBy('created_at', 'desc')->get()->first();

                $position = $currentPromotion->getPosition();
        $additionalResponsibilities = $currentPromotion->getAddedResponsibilities()['additionalResponsibilities'];
        $additionalResponsibilitiesArray = $currentPromotion->getAddedResponsibilities()['additionalResponsibilitiesArray'];

                $rank = $currentPromotion->getRank();
                $status = $currentPromotion->getStaffStatus();
                $con___ = $currentPromotion->con___;
                $salary_scale = $currentPromotion->getSalaryScale();
                $salary_scale_value = $currentPromotion->salary_scale_value;
                $gpzone = $this->getZone();
                $con_title = $currentPromotion->getCon__Title();
                $appointmenttype = $currentPromotion->getAppointmentType();

	    					return ['position'=> $position, 'lga'=>$lga, 'state'=>$state, 'status'=>$status, 'staffclass' =>$currentPromotion->staffclass,
	    							'category' => $currentPromotion->category, 'step'=>$currentPromotion->step, 'rank'=>$rank, 'con___' => $con___, 'con_title'=>$con_title, 'gpzone' => $gpzone, 'appointmenttype' => $appointmenttype, 'current_promotion_date'=>$currentPromotion->promotion_date, 'addedresponsibilities'=>$additionalResponsibilities, 'addedresponsibilitiesarray'=>$additionalResponsibilitiesArray, 'salary_scale' => $salary_scale, 'salary_scale_value' => $salary_scale_value ];

    }

    public function getAllPromotionHistory(){
    	/*$currentPromotion = \App\Promotions::where('status', \App\Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', \App\Promotions::$CURRENT_PROMOTION)->where('staff_id', $this->id)->orderBy('created_at', 'desc')->get();*/

      /*$allAprovedPromotions = \App\Promotions::where('status', \App\Promotions::$APPROVED_PROMOTION)
            ->where('staff_id', $this->id)->orderBy('created_at', 'desc')->get()->all();*/

      $allApprovedPromotions = \App\Promotions::where('staff_id', $this->id)->orderBy('created_at', 'desc')->get()->all();

      return $allApprovedPromotions;

    }

    public function getUnVerifiedPromotionHistory(){
    	/*$currentPromotion = \App\Promotions::where('status', \App\Promotions::$APPROVED_PROMOTION)
            ->where('promotion_indicator', \App\Promotions::$CURRENT_PROMOTION)->where('staff_id', $this->id)->orderBy('created_at', 'desc')->get();*/

      $allUnAprovedPromotions = \App\Promotions::where('status', \App\Promotions::$DISAPPROVED_PROMOTION)
            ->where('staff_id', $this->id)->orderBy('created_at', 'desc')->get()->all();

      return $allUnAprovedPromotions;

    }

    public function getFullName():string
    {
    	return $this->fname . " " . $this->lname . " " . $this->oname;
    }

    public function getZone(): string
    {
    	return Zone::find($this->gpzone)->getZone();
    }

    public function getDepartment($short = false)
    {
    	return StaffDepartment::getCurrentStaffDepartment($this->id)->getDepartment($short);
    }

    public function getDepartmentUnit()
    {
        $staffUnitDept = StaffUnitDepartment::getCurrentStaffUnitDepartment($this->id);

        if(!is_null($staffUnitDept)){
            return $staffUnitDept->getDepartmentUnit();
        }else{
            return "";
        }
    }

    public function getDepartmentHistory()
    {
    	return StaffDepartment::getStaffDepartmentHistory($this->id);
    }

    public static function exists($staff_no): bool{
        if(Staff::where('staffno', $staff_no)->get()->count() == 1 ){
            return true;
        }
        return false;
    }

    public function getPromotion()
    {
        $currentPromotion = \App\Promotions::where('status', \App\Promotions::$APPROVED_PROMOTION)
                                                ->where('promotion_indicator', \App\Promotions::$CURRENT_PROMOTION)->where('staff_id', $this->id)->orderBy('created_at', 'desc')->get()->first();
        return $currentPromotion;
    }


}
