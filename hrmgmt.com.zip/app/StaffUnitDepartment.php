<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Department;
use App\DepartmentUnit;
use App\StaffDepartment;

class StaffUnitDepartment extends Model
{
    protected $fillable=['staff_id', 'dept_id', 'unit_id', 'status'];


    public static $STATUS_CURRENT = 1;
    public static $STATUS_PAST = 2;

    public function getDepartment(bool $show_full = true)
    {
    	return Department::find($this->dept_id)->getDepartment($show_full);
    }

    public function getDepartmentUnit()
    {
    	return DepartmentUnit::find($this->unit_id)->unit;
    }

    public function getSchool()
    {
    	return Department::find($this->dept_id)->getSchool();
    }

    public static function getCurrentStaffUnitDepartment($staffid)
    {
    	return StaffUnitDepartment::where('status', self::$STATUS_CURRENT)->where('staff_id', $staffid)->get()->first();
    }

    public static function getStaffUnitDepartmentHistory($staffid)
    {
    	return StaffUnitDepartment::where('staff_id', $staffid)->orderBy('created_at', 'desc')->get()->all();
    }
}
