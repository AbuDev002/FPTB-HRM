<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PromotionGradeLevelsSteps extends Model
{
    protected $fillable = ['oldgrade', 'newgrade'];

}
