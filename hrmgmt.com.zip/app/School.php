<?php

namespace App;
use \App\Department;

use Illuminate\Database\Eloquent\Model;

class School extends Model
{
    protected $fillable = ['school'];

    public function getAllDepartment()
    {
    	$schoolDepartmets = Department::where('school', $this->id)->get()->all();
    	return $schoolDepartmets;
    }
}