<?php

namespace App\Console\Commands;

use App\Http\Controllers\UtilityController;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

use App\User;
use App\Staff;
use App\Promotions;
use App\StaffDepartment;
use App\StaffExtras;
use App\Position;
use Carbon\Carbon;
use PhpOffice\PhpSpreadsheet\Exception;
use App\SalaryScale;

class DataimportCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:staff';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Imports Staff Records From Excel Sheets';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info('Starting Out');

        echo "==================================================================================================";
        echo "==================================================================================================";
        echo "==================================================================================================";

        // $this->processTest("");
        $this->diffFormatProcessTest("");

        $this->info('Completed Successfully');
    }

    public function processTest($filesname = null){
        $this->info('++++++++');
        $files = Storage::files("datafile");

        $this->info("Files To Be Processed: " . implode(", ", $files));

        if(count($files) > 0){
            $filesname = $files[0];
        }

        $this->info("File Being Processed: $filesname");

        if(empty($filesname)) return;
        var_dump($filesname);
        $filename_local = Storage::disk('local')->exists($filesname);

        var_dump($filename_local);
        $filestoragepath = storage_path("app/$filesname");
        $spreadSheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($filestoragepath);

        $worksheet = $spreadSheet->getActiveSheet();

        echo "COLINDEX\n";
        $highestRow = $worksheet->getHighestRow(); // e.g. 10
        $highestColumn = $worksheet->getHighestColumn(); // e.g 'F'
        $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn); // e.g. 5
        printf("<br/>HIGHEST ROW   %s<br/>HIGHEST COLUMN  %s<br/>HIGHEST COLUMN INDEX %s<br/>", $highestRow, $highestColumn, $highestColumnIndex);
        echo "\nCOLINDEX\n";



        $count = 0;
        $staff_category = 1; //academic 2 - non-academic

        echo '<table>' . PHP_EOL;
        foreach ($worksheet->getRowIterator() as $row) {
            if($count == 0) {
                echo "FIRST";
                echo '<tr>' . PHP_EOL;
                $cellIterator = $row->getCellIterator();
                try {
                    $cellIterator->setIterateOnlyExistingCells(FALSE);
                } catch (Exception $e) {
                }
                // This loops through all cells,

                foreach ($cellIterator as $key => $cell) {
                    echo '<td>' .
                        $cell->getValue() . "   KEY: $key".
                        '</td>' . PHP_EOL;
                }
                echo '</tr>' . PHP_EOL;
                $count++;
            }else{
                echo "REMAINING";
                echo '<tr>' . PHP_EOL;
                $cellIterator = $row->getCellIterator();
                try {
                    $cellIterator->setIterateOnlyExistingCells(FALSE);
                } catch (Exception $e) {
                } // This loops through all cells


                foreach ($cellIterator as $key => $cell) {
                    switch ($key){
                        case 'A':
                            $exc_sn = $cell->getFormattedValue();
                            break;
                        case 'B':
                            $exc_pfn = $cell->getFormattedValue();
                            break;
                        case 'C':
                            $exc_surname = $cell->getFormattedValue();
                            break;
                        case 'D':
                            $exc_othername = $cell->getFormattedValue();
                            break;
                        case 'E':
                            $exc_sex = $cell->getFormattedValue();
                            break;
                        case 'F':
                            $exc_gpzone  = $cell->getFormattedValue();
                            break;
                        case 'G':
                            $exc_state   = $cell->getFormattedValue();
                            break;
                        case 'H':
                            $exc_lga = $cell->getFormattedValue();
                            break;
                        case 'I':
                            $exc_prev_dept  = $cell->getFormattedValue();
                            break;
                        case 'J':
                            $exc_dept  = $cell->getFormattedValue();
                            break;
                        case 'K':
                            $exc_qualifications  = $cell->getFormattedValue();
                            break;
                        case 'L':
                            $exc_rank    = $cell->getFormattedValue();
                            break;
                        case 'M':
                            $exc_compcas = $cell->getFormattedValue(); // CON__ -> This could be compcas or contediss
                            break;
                        case 'N':
                            $exc_step    = $cell->getFormattedValue(); // STEP
                            break;
                        case 'O':
                            $exc_birthdate    = $cell->getFormattedValue();
                            break;
                        case 'P':
                            $exc_firstappt    = $cell->getFormattedValue();
                            break;
                        case 'Q':
                            $exc_pres_apt     = $cell->getFormattedValue();
                            break;
                        case 'R':
                            $exc_type_appt    = $cell->getFormattedValue();
                            break;
                        case 'S':
                            $exc_class    = $cell->getFormattedValue();
                            break;
                        case 'T':
                            $exc_category   = $cell->getFormattedValue();
                            break;
                        case 'U':
                            $exc_status   = $cell->getFormattedValue();
                            break;
                        case 'V':
                            $exc_mstatus  = $cell->getFormattedValue();
                            break;
                        case 'W':
                            $exc_position   = $cell->getFormattedValue();
                            break;
                        case 'X':
                            $exc_added_responsibility   = $cell->getFormattedValue();
                            break;
                        case 'Y':
                            $exc_phone_no   = $cell->getFormattedValue();
                            break;

                    }

                    echo '<td>' .
                       $key .
                       // $cell->getValue() .
                        $cell->getFormattedValue() . "   |==|  KEY: $key".
                        '</td>' . PHP_EOL;
                }

                echo '</tr>' . PHP_EOL;

                // Adding the records
                echo "ADDING RECORDS -PFN- $exc_pfn - $count<br/>";
               $this->addRecords($exc_sn, $exc_pfn, $exc_surname, $exc_othername, $exc_sex,  $exc_gpzone, $exc_state, $exc_lga, $exc_prev_dept,  $exc_dept, $exc_qualifications, $exc_rank, $exc_compcas, $exc_step, $exc_birthdate,  $exc_firstappt,  $exc_pres_apt,  $exc_type_appt,  $exc_class, $exc_category,  $exc_status, $exc_mstatus, $exc_position, $exc_added_responsibility, $exc_phone_no );

                //Adding Records


                $count++;
            }

//            if($count > 100) break;
        }
        echo '</table>' . PHP_EOL;

        $this->info("TOTAL-RECORDS: $count");

        if($count == $highestRow){
            ECHO "Deleted file $filesname\n";
          //  Storage::disk('local')->delete($filesname);
            echo "\n";
        }

    }

    /**
     * diffFormatProcessTest Excel Processing
     * @param  [type] $filesname [description]
     * @return [type]            [description]
     */
    public function diffFormatProcessTest($filesname = null){
        $this->info('++++++++');
        $files = Storage::files("datafile");

        $this->info("Files To Be Processed: " . implode(", ", $files));

        if(count($files) > 0){
            $filesname = $files[0];
        }

        $this->info("File Being Processed: $filesname");

        if(empty($filesname)) return;
        var_dump($filesname);
        $filename_local = Storage::disk('local')->exists($filesname);

        var_dump($filename_local);
        $filestoragepath = storage_path("app/$filesname");
        $spreadSheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($filestoragepath);

        $worksheet = $spreadSheet->getActiveSheet();

        // var_dump($worksheet);
        // die("OK");

        echo "COLINDEX\n";
        $highestRow = $worksheet->getHighestRow(); // e.g. 10
        $highestColumn = $worksheet->getHighestColumn(); // e.g 'F'
        $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn); // e.g. 5
        printf("<br/>HIGHEST ROW   %s<br/>HIGHEST COLUMN  %s<br/>HIGHEST COLUMN INDEX %s<br/>", $highestRow, $highestColumn, $highestColumnIndex);
        echo "\nCOLINDEX\n";



        $count = 0;
        $staff_category = 1; //academic 2 - non-academic

        $cccc = 0;
        echo '<table>' . PHP_EOL;
        foreach ($worksheet->getRowIterator() as $row) {
            echo $cccc++;
            if($count == 0) {
                echo "FIRST";
                echo '<tr>' . PHP_EOL;
                $cellIterator = $row->getCellIterator();
                try {
                    $cellIterator->setIterateOnlyExistingCells(FALSE);
                } catch (Exception $e) {
                }
                // This loops through all cells,

                foreach ($cellIterator as $key => $cell) {

                    echo '<td>' .
                        $cell->getValue() . "   KEY: $key".
                        '</td>' . PHP_EOL;
                    if($key == 'T') break;
                }
                echo '</tr>' . PHP_EOL;
                $count++;
            }else{
                echo "REMAINING";
                echo '<tr>' . PHP_EOL;
                $cellIterator = $row->getCellIterator();
                try {
                    $cellIterator->setIterateOnlyExistingCells(FALSE);
                } catch (Exception $e) {
                } // This loops through all cells

                $exec_sn_increment = 1;


                $exc_sn = $exec_sn_increment++;

                foreach ($cellIterator as $key => $cell) {
                    switch ($key){
                        case 'A':
                            $exc_pfn = $cell->getFormattedValue();
                            echo $exc_pfn;
                            break;
                        case 'B':
                            $exc_surname = $cell->getFormattedValue();
                            break;
                        case 'C':
                            $exc_firstname = $cell->getFormattedValue();
                            break;
                        case 'D':
                            $exc_othername = $cell->getFormattedValue();
                            break;
                        case 'E':
                            $exc_sex = $cell->getFormattedValue();
                            break;
                        case 'F':
                            $exc_gpzone  = $cell->getFormattedValue();
                            break;
                        case 'G':
                            $exc_state   = $cell->getFormattedValue();
                            break;
                        case 'H':
                            $exc_lga = $cell->getFormattedValue();
                            break;
                        case 'I':
                            $exc_dept  = $cell->getFormattedValue();
                            // $exc_prev_dept  = $cell->getFormattedValue();
                            break;
                        case 'J':
                            $exc_qualifications  = $cell->getFormattedValue();
                            break;
                        case 'K':
                            $exc_rank    = $cell->getFormattedValue();
                            break;
                        case 'L':
                            $exc_compcas = $cell->getFormattedValue(); // CON__ -> This could be compcas or contediss
                            break;
                        case 'M':
                            $exc_step    = $cell->getFormattedValue(); // STEP
                            // $exc_compcas = $cell->getFormattedValue(); // CON__ -> This could be compcas or contediss
                            break;
                        case 'N':
                            $exc_birthdate    = $cell->getFormattedValue();
                            // $exc_step    = $cell->getFormattedValue(); // STEP
                            break;
                        case 'O':
                            $exc_firstappt    = $cell->getFormattedValue();
                            // $exc_birthdate    = $cell->getFormattedValue();
                            break;
                        case 'P':
                            $exc_pres_apt     = $cell->getFormattedValue();
                            // $exc_firstappt    = $cell->getFormattedValue();
                            break;
                        case 'Q':
                            $exc_type_appt    = $cell->getFormattedValue();
                            // $exc_pres_apt     = $cell->getFormattedValue();
                            break;
                        case 'R':
                            $exc_class    = $cell->getFormattedValue();
                            // $exc_type_appt    = $cell->getFormattedValue();
                            break;
                        case 'S':
                            // $exc_status   = $cell->getFormattedValue();
                            $exc_category   = $cell->getFormattedValue();
                            // $exc_class    = $cell->getFormattedValue();
                            break;
                        case 'T':
                            $exc_mstatus  = $cell->getFormattedValue();
                            // $exc_category   = $cell->getFormattedValue();
                            break;
                    

                    }

                    // echo '<td>' .
                    //    $key .
                    //    // $cell->getValue() .
                    //     $cell->getFormattedValue() . "   |==|  KEY: $key".
                    //     '</td>' . PHP_EOL;
                }

                echo '</tr>' . PHP_EOL;

                // Adding the records
                echo "ADDING RECORDS -PFN- $exc_pfn - $count<br/>";
               // $this->addRecords($exc_sn, $exc_pfn, $exc_surname, $exc_othername, $exc_sex,  $exc_gpzone, $exc_state, $exc_lga, $exc_prev_dept,  $exc_dept, $exc_qualifications, $exc_rank, $exc_compcas, $exc_step, $exc_birthdate,  $exc_firstappt,  $exc_pres_apt,  $exc_type_appt,  $exc_class, $exc_category,  $exc_status, $exc_mstatus, $exc_position, $exc_added_responsibility, $exc_phone_no );


               echo "$exc_pfn $exc_firstname";
               $this->addRecordsDiff($exc_sn, $exc_pfn, $exc_surname, $exc_firstname, $exc_othername, $exc_sex,  $exc_gpzone, $exc_state, $exc_lga, $exc_dept, $exc_qualifications, $exc_rank, $exc_compcas, $exc_step, $exc_birthdate,  $exc_firstappt,  $exc_pres_apt,  $exc_type_appt,  $exc_class, $exc_category, $exc_mstatus );

               // private function addRecordsDiff($exc_sn, $exc_pfn, $exc_surname, $exc_othername, $exc_sex,  $exc_gpzone, $exc_state, $exc_lga, $exc_prev_dept,  $exc_dept, $exc_qualifications, $exc_rank, $exc_compcas, $exc_step, $exc_birthdate,  $exc_firstappt,  $exc_pres_apt,  $exc_type_appt,  $exc_class, $exc_category,  $exc_status, $exc_mstatus, $exc_position, $exc_added_responsibility, $exc_phone_no, $email = null ) : bool {

                //Adding Records


                $count++;
            }

//            if($count > 100) break;
        }
        echo '</table>' . PHP_EOL;

        $this->info("TOTAL-RECORDS: $count");

        if($count == $highestRow){
            ECHO "Deleted file $filesname\n";
          //  Storage::disk('local')->delete($filesname);
            echo "\n";
        }

    }

    private function processDateFormat(string $this_date_param){
        $formatedDate = '';
        try{
            $formatedDate = Carbon::createFromFormat('d/m/Y', $this_date_param);
        }catch(\Exception $e){

            try{
                $formatedDate = $formatedDate ?? Carbon::createFromFormat('d/M/Y', $this_date_param);
            }catch (\Exception $e){
                var_dump($e->getMessage());
                dd($e->getTrace());
            }
        }
        return $formatedDate;
    }

    private function addRecords($exc_sn, $exc_pfn, $exc_surname, $exc_othername, $exc_sex,  $exc_gpzone, $exc_state, $exc_lga, $exc_prev_dept,  $exc_dept, $exc_qualifications, $exc_rank, $exc_compcas, $exc_step, $exc_birthdate,  $exc_firstappt,  $exc_pres_apt,  $exc_type_appt,  $exc_class, $exc_category,  $exc_status, $exc_mstatus, $exc_position, $exc_added_responsibility, $exc_phone_no, $email = null ) : bool {

        if(Staff::exists($exc_pfn)){
            $thisStaff = Staff::Where('staffno', $exc_pfn)->first();

            //Stage 1: Handle Names
            $this->info("STAGE 1: UPDATING NAME OF THE STAFF");
            $othername_array = explode(' ', $exc_othername);
            $lastname = $othername_array[0] ?? "";
            $othername = implode(' ', array_slice($othername_array, 1));

                $thisStaff->fname = $exc_surname;
                $thisStaff->lname = $lastname;
                $thisStaff->oname = $othername;

            $thisStaff->email = $email?? $thisStaff->email;

            $birthdate = $this->processDateFormat($exc_birthdate);
            $first_appt_date = $this->processDateFormat($exc_firstappt);

            $thisStaff->dateobirth = $birthdate;
            $thisStaff->firstappointdate = $first_appt_date;
            // $thisStaff->state_id =

            $this->info("STAGE 2: UPDATING STATE & LGA INFORMATION");
            $state = DB::table("state")->where('state', 'like', "%$exc_state%" )->get()->first();

            if(empty($state)){
                $state = DB::table("state")->where('state', 'like', '%BAUCHI%')->get()->first(); // as default
            }
            $thisStaff->state_id = $state->id;

            $lga = DB::table("lga")->where("lga", "like", "%$exc_lga%")->where("stateid", $state->id )->first();

            if(empty($lga)){
                $lga = DB::table("lga")->where("stateid", $state->id)->first();
            }




            $thisStaff->save();

            //Get the Records

            return true;
        }

        $othername_array = explode(' ', $exc_othername);
        $lastname = $othername_array[0] ?? "";
        $othername = implode(' ', array_slice($othername_array, 1));


        $state = DB::table("state")->where('state', 'like', "%$exc_state%" )->get()->first();

        if(empty($state)){
            $state = DB::table("state")->where('state', 'like', '%BAUCHI%')->get()->first(); // as default
        }

        $lga = DB::table("lga")->where("lga", "like", "%$exc_lga%")->where("stateid", $state->id )->first();

        if(empty($lga)){
            $lga = DB::table("lga")->where("stateid", $state->id )->first();
        }

        $appointment_type = DB::table("appointment_types")->where('appointmenttype', 'like', "%$exc_type_appt%")->get()->first();

        if(empty($appointment_type)){
            $appointment_type =$appointment_type = DB::table("appointment_types")->first();
        }

        $gpzone = DB::table("zones")->where('gpzone', 'like', "%$exc_gpzone%")->get()->first();

        if(empty($gpzone)){
            $gpzone = DB::table("zones")->first();
        }

        $staff_category = $exc_status;


        $birthdate = $this->processDateFormat($exc_birthdate);
        $first_appt_date = $this->processDateFormat($exc_firstappt);

        try{
            $pres_apt_date = $pres_apt_date ?? Carbon::createFromFormat('d/m/Y', $exc_pres_apt);
        }catch(\Exception $e){
            try{
                $pres_apt_date =  $pres_apt_date ?? Carbon::createFromFormat('d/M/Y', $exc_pres_apt);
            }catch (\Exception $e){
                var_dump($e->getMessage());
                dd($e->getTrace());
            }
        }
        $email = UtilityController::getUniqueTempEmailAddress();

        try {

            \DB::beginTransaction();

            $newStaff = Staff::create([
                'fname' => $exc_surname,
                'lname' => $lastname,
                'oname' => $othername,
                'email' => $email,
                'gender' => $exc_sex,
                'staffno' => $exc_pfn,
                'address1' => "",
                'address2' => "",
                'dateobirth' => $birthdate,
                'status' => 1,
                'photo' => "",
                'state_id' => $state->id,
                'lga_id' => $lga->id,
                'firstappointdate' => $first_appt_date,
                'appointmenttype' => $appointment_type->id,
                'staffclass' => $exc_class,
                'maritalstatus' => $exc_mstatus,
                'phoneno' => "",
                'gpzone' => $gpzone->id,
                'nok_fname' => "",
                'nok_lname' => "",
                'nok_oname' => "",
                'nok_address' => "",
                'nok_phoneno' => "",
                'nok_relationship' => "",
                'child1_name' => "",
                'child1_age' => 0,
                'child2_name' => "",
                'child2_age' => 0,
                'child3_name' => "",
                'child3_age' => 0,
                'child4_name' => "",
                'child4_age' => 0
            ]);

            $rank = DB::table("ranks")->where('rank', 'like', "%$exc_rank%")->where('staffclass', 'like', "$exc_class")->get()->first();

            if (empty($rank)) {
                $rank = DB::table("ranks")->where('staffclass', 'like', "$exc_class")->get()->first();
            }

            $rank = empty($rank)?  DB::table("ranks")->first() : $rank;

            $exc_compcas = (int)$exc_compcas;

            $exc_compcas = ($exc_compcas > 0)? $exc_compcas : 1;

            $salary_scale_ = $exc_class == "AS"? 1 : 2;


            $promotions = Promotions::create([
                'staff_id' => $newStaff->id,
                'promotion_date' => $pres_apt_date,
                'description' => "First Promotion  Indicator",
                'position' => Position::where('position', 'NONE')->get()->first()->id,
                'status' => Promotions::$APPROVED_PROMOTION,
                'staff_status' => 1,
                'con___' => $exc_compcas,
                'salary_scale' => $salary_scale_,
                'salary_scale_value' => $exc_compcas,
                'staffclass' => $exc_class,
                'rank' => $rank->id,
                'category' => $staff_category,
                'step' => rand(1, 10),
                'promotion_indicator' => Promotions::$CURRENT_PROMOTION,
                'presentappointdate' => $pres_apt_date,
                'appointmenttype' => $appointment_type->id,
            ]);

            $dept = DB::table("department")->where('department', 'like', "%$exc_dept%")->get()->first();

            if (empty($dept)) {
                $dept = DB::table("department")->first();
            }

            $staffDept = StaffDepartment::create([
                'staff_id' => $newStaff->id,
                'dept_id' => $dept->id,
                'school' => $dept->school,
                'status' => StaffDepartment::$STATUS_CURRENT // 1
            ]);


            $qualificationtitle = $exc_qualifications;
            $qualificationtype = "OTHERS";
            $qualificationdesc = "Qualification/Certification";
            $registeredprobody = "NONE";


            //TO BE UPDATED
            StaffExtras::create([
                'staff_id' => $newStaff->id,
                'title' => $qualificationtitle,
                'description' => $qualificationdesc,
                'registeredprobody' => $registeredprobody,
                'qualificationtype' => $qualificationtype,

                // 1 - means approved automatically, 2 - accepted but yet to formalize it, 3 - proposed by staff
                // 4 - rejected
                'status' => StaffExtras::$ACCEPTED_QUALIFICATION_STATUS
            ]);

            $addStaffToUser = User::create([
                'name' => ($exc_surname . " " . $lastname . " " . $othername),
                'email' => $email, 'password' => bcrypt('password'), 'username' => $exc_pfn,
                'access_level' => Staff::$USER_STAFF,
                'status' => User::$USER_ACCOUNT_STATUS_ENABLED
            ]);

            echo "<br/>SUCEESSFULLY ADDED ". $newStaff->staffno . "<br/>";
            \DB::commit();
        }catch(\Exception $e){
            var_dump($e->getMessage());
            echo($e->getTraceAsString());

            \DB::rollback();
        }

        return true;

    }



    // $this->addRecordsDiff($exc_sn, $exc_pfn, $exc_surname, $exc_firstname, $exc_othername, $exc_sex,  $exc_gpzone, $exc_state, $exc_lga, $exc_dept, $exc_qualifications, $exc_rank, $exc_compcas, $exc_step, $exc_birthdate,  $exc_firstappt,  $exc_pres_apt,  $exc_type_appt,  $exc_class, $exc_status, $exc_mstatus );
    // private function addRecordsDiff($exc_sn, $exc_pfn, $exc_surname, $exc_othername, $exc_sex,  $exc_gpzone, $exc_state, $exc_lga, $exc_prev_dept,  $exc_dept, $exc_qualifications, $exc_rank, $exc_compcas, $exc_step, $exc_birthdate,  $exc_firstappt,  $exc_pres_apt,  $exc_type_appt,  $exc_class, $exc_category,  $exc_status, $exc_mstatus, $exc_position, $exc_added_responsibility, $exc_phone_no, $email = null ) : bool {

    private function addRecordsDiff( $exc_sn, $exc_pfn, $exc_surname, $exc_firstname, $exc_othername, $exc_sex,  $exc_gpzone, $exc_state, $exc_lga, $exc_dept, $exc_qualifications, $exc_rank, $exc_compcas, $exc_step, $exc_birthdate,  $exc_firstappt,  $exc_pres_apt,  $exc_type_appt,  $exc_class, $exc_status, $exc_mstatus ) : bool {

        $this->info("STAFF-NO:  $exc_pfn");

        if(Staff::exists($exc_pfn)){
            $thisStaff = Staff::Where('staffno', $exc_pfn)->first();

            //Stage 1: Handle Names
            $this->info("STAGE 1: UPDATING NAME OF THE STAFF");
            // $othername_array = explode(' ', $exc_othername);
            // $lastname = $othername_array[0] ?? "";
            // $othername = implode(' ', array_slice($othername_array, 1));

                $thisStaff->fname = $exc_firstname?? $thisStaff->fname;
                $thisStaff->lname = $exc_surname?? $thisStaff->lname;
                $thisStaff->oname = $exc_othername ?? $thisStaff->oname;

            $thisStaff->email = $email?? $thisStaff->email;

            $birthdate = $this->processDateFormat($exc_birthdate);
            $first_appt_date = $this->processDateFormat($exc_firstappt);

            $thisStaff->dateobirth = $birthdate;
            $thisStaff->firstappointdate = $first_appt_date;

            $this->info("STAGE 2: UPDATING STATE & LGA INFORMATION");
            $state = DB::table("state")->where('state', 'like', "%$exc_state%" )->get()->first();

            if(!empty($state)){
                $thisStaff->state_id = $state->id;
            }

            if(!empty($state)){
                $lga = DB::table("lga")->where("lga", "like", "%$exc_lga%")->where("stateid", $state->id )->first();
            }else{
                $lga = DB::table("lga")->where("lga", "like", "%$exc_lga%")->first();
            }

            if(!empty($lga)){
                $thisStaff->lga_id = $lga->id;
            }

            $rank = DB::table("ranks")->where('rank', 'like', "%$exc_rank%")->where('staffclass', 'like', "$exc_class")->get()->first();


            //---------------------
            $birthdate = $this->processDateFormat($exc_birthdate);
            $first_appt_date = $this->processDateFormat($exc_firstappt);
            $pres_apt_date = $this->processDateFormat($exc_pres_apt);

            $staffPromotionObj = $thisStaff->getPromotion();

            $staffPromotionObj->promotion_date = $pres_apt_date;
            $staffPromotionObj->description = "Imported Data Promotion Updated Info";
            if (!empty($rank)) {
                $staffPromotionObj->rank = $rank->id;
            }

            $exc_compcas = (int)$exc_compcas;

            $exc_compcas = ($exc_compcas > 0)? $exc_compcas : 1;

            $salary_scale_ = $exc_class == "AS"? 1 : 2;

            $staff_category = $exc_status;

            $appointment_type = DB::table("appointment_types")->where('appointmenttype', 'like', "%$exc_type_appt%")->get()->first();

            if(!empty($appointment_type)){
                $staffPromotionObj->appointmenttype = $appointment_type->id;
                $thisStaff->appointmenttype = $appointment_type->id;
            }

            $gpzone = DB::table("zones")->where('gpzone', 'like', "%$exc_gpzone%")->get()->first();

            if(!empty($gpzone)){
                $thisStaff->gpzone = $gpzone->id;
            }

            $staffPromotionObj->staff_status = 1;
            $staffPromotionObj->salary_scale = $salary_scale_;
            $staffPromotionObj->salary_scale_value = $exc_compcas;
            $staffPromotionObj->con___ = $exc_compcas;
            $staffPromotionObj->staffclass = $exc_class;
            $staffPromotionObj->category = $staff_category;
            $staffPromotionObj->step = $exc_step;
            // $staffPromotionObj->promotion_indicator = Promotions::$CURRENT_PROMOTION;
            $staffPromotionObj->presentappointdate = $pres_apt_date;
            $staffPromotionObj->status = Promotions::$APPROVED_PROMOTION;
            $staffPromotionObj->staff_status = 1;
            $staffPromotionObj->save();

            //--------------------

            $thisStaff->save();

            //Get the Records
            
            return true;
        }

        $lastname = $exc_firstname?? "";
        $othername = $exc_othername?? "";

// $exc_sn, $exc_pfn, $exc_surname, $exc_firstname, $exc_othername, $exc_sex,  $exc_gpzone, $exc_state, $exc_lga, $exc_dept, $exc_qualifications, $exc_rank, $exc_compcas, $exc_step, $exc_birthdate,  $exc_firstappt,  $exc_pres_apt,  $exc_type_appt,  $exc_class, $exc_status, $exc_mstatus
// 

        $state = DB::table("state")->where('state', 'like', "%$exc_state%" )->get()->first();

        if(empty($state)){
            $state = DB::table("state")->where('state', 'like', '%BAUCHI%')->get()->first(); // as default
        }

        $lga = DB::table("lga")->where("lga", "like", "%$exc_lga%")->where("stateid", $state->id )->first();

        if(empty($lga)){
            $lga = DB::table("lga")->where("stateid", $state->id )->first();
        }

        $appointment_type = DB::table("appointment_types")->where('appointmenttype', 'like', "%$exc_type_appt%")->get()->first();

        if(empty($appointment_type)){
            $appointment_type =$appointment_type = DB::table("appointment_types")->first();
        }

        $gpzone = DB::table("zones")->where('gpzone', 'like', "%$exc_gpzone%")->get()->first();

        if(empty($gpzone)){
            $gpzone = DB::table("zones")->first();
        }

        $staff_category = $exc_status;


        $birthdate = $this->processDateFormat($exc_birthdate);
        $first_appt_date = $this->processDateFormat($exc_firstappt);

        try{
            $pres_apt_date = $pres_apt_date ?? Carbon::createFromFormat('d/m/Y', $exc_pres_apt);
        }catch(\Exception $e){
            try{
                $pres_apt_date =  $pres_apt_date ?? Carbon::createFromFormat('d/M/Y', $exc_pres_apt);
            }catch (\Exception $e){
                var_dump($e->getMessage());
                dd($e->getTrace());
            }
        }
        $email = UtilityController::getUniqueTempEmailAddress();

        try {

            \DB::beginTransaction();

            $newStaff = Staff::create([
                'fname' => $exc_surname,
                'lname' => $lastname,
                'oname' => $othername,
                'email' => $email,
                'gender' => $exc_sex,
                'staffno' => $exc_pfn,
                'address1' => "",
                'address2' => "",
                'dateobirth' => $birthdate,
                'status' => 1,
                'photo' => "",
                'state_id' => $state->id,
                'lga_id' => $lga->id,
                'firstappointdate' => $first_appt_date,
                'appointmenttype' => $appointment_type->id,
                'staffclass' => $exc_class,
                'maritalstatus' => $exc_mstatus,
                'phoneno' => "",
                'gpzone' => $gpzone->id,
                'nok_fname' => "",
                'nok_lname' => "",
                'nok_oname' => "",
                'nok_address' => "",
                'nok_phoneno' => "",
                'nok_relationship' => "",
                'child1_name' => "",
                'child1_age' => 0,
                'child2_name' => "",
                'child2_age' => 0,
                'child3_name' => "",
                'child3_age' => 0,
                'child4_name' => "",
                'child4_age' => 0
            ]);

            $rank = DB::table("ranks")->where('rank', 'like', "%$exc_rank%")->where('staffclass', 'like', "$exc_class")->get()->first();

            if (empty($rank)) {
                $rank = DB::table("ranks")->where('staffclass', 'like', "$exc_class")->get()->first();
            }

            $rank = empty($rank)?  DB::table("ranks")->first() : $rank;

            $exc_compcas = (int)$exc_compcas;

            $exc_compcas = ($exc_compcas > 0)? $exc_compcas : 1;

            $salary_scale_ = $exc_class == "AS"? 1 : 2;


            $promotions = Promotions::create([
                'staff_id' => $newStaff->id,
                'promotion_date' => $pres_apt_date,
                'description' => "First Promotion  Indicator",
                'position' => Position::where('position', 'NONE')->get()->first()->id,
                'status' => Promotions::$APPROVED_PROMOTION,
                'staff_status' => 1,
                'con___' => $exc_compcas,
                'salary_scale' => $salary_scale_,
                'salary_scale_value' => $exc_compcas,
                'staffclass' => $exc_class,
                'rank' => $rank->id,
                'category' => $staff_category,
                'step' => rand(1, 10),
                'promotion_indicator' => Promotions::$CURRENT_PROMOTION,
                'presentappointdate' => $pres_apt_date,
                'appointmenttype' => $appointment_type->id,
            ]);

            $dept = DB::table("department")->where('department', 'like', "%$exc_dept%")->get()->first();

            if (empty($dept)) {
                $dept = DB::table("department")->first();
            }

            $staffDept = StaffDepartment::create([
                'staff_id' => $newStaff->id,
                'dept_id' => $dept->id,
                'school' => $dept->school,
                'status' => StaffDepartment::$STATUS_CURRENT // 1
            ]);


            $qualificationtitle = $exc_qualifications;
            $qualificationtype = "OTHERS";
            $qualificationdesc = "Qualification/Certification";
            $registeredprobody = "NONE";


            //TO BE UPDATED
            StaffExtras::create([
                'staff_id' => $newStaff->id,
                'title' => $qualificationtitle,
                'description' => $qualificationdesc,
                'registeredprobody' => $registeredprobody,
                'qualificationtype' => $qualificationtype,

                // 1 - means approved automatically, 2 - accepted but yet to formalize it, 3 - proposed by staff
                // 4 - rejected
                'status' => StaffExtras::$ACCEPTED_QUALIFICATION_STATUS
            ]);

            $addStaffToUser = User::create([
                'name' => ($exc_surname . " " . $lastname . " " . $othername),
                'email' => $email, 'password' => bcrypt('password'), 'username' => $exc_pfn,
                'access_level' => Staff::$USER_STAFF,
                'status' => User::$USER_ACCOUNT_STATUS_DISABLED
            ]);

            echo "<br/>SUCEESSFULLY ADDED ". $newStaff->staffno . "<br/>";
            \DB::commit();
        }catch(\Exception $e){
            var_dump($e->getMessage());
            echo($e->getTraceAsString());

            \DB::rollback();
        }

        return true;

    }
}
