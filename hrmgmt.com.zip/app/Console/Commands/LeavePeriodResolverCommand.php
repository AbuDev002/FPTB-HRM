<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Leave;
use App\Staff;
use App\Promotions;
use App\StaffDepartment;
use App\StaffExtras;
use App\Position;
use Carbon\Carbon;

class LeavePeriodResolverCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'resolve:leave';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This Helps Resolves Leave Period For Staff. Making Automation Easy';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info("Leave Resolver Begins Operations");
        $this->resolveAllPendingLeave();
        $this->info("Leave Resolver Operations Completed Successfully");
    }

    private function resolveAllPendingLeave(){

        try{
            echo "YEAH\n";
            \DB::beginTransaction();
            $count = 0;
            $resolver = Leave::where('to', '<=', now())->where('status', Leave::ACTIVE)->where('range_type', Leave::RANGE_TWO)->get()->all();
            foreach ($resolver as $each_resolver) {
                $count++;
                $this->info("Marking Leave $count As Completed");
                $each_resolver->status = \App\Leave::INACTIVE;
                $each_resolver->save();

                $thisStaff = Staff::find($each_resolver->staff_id);
                $thisStaff->status = 1; // This means now active
                $thisStaff->save();

                // ===========================
                $thisStaff_CurrentPromotion = Promotions::where('status', Promotions::$APPROVED_PROMOTION)
                ->where('promotion_indicator', Promotions::$CURRENT_PROMOTION)
                ->where('staff_id', $thisStaff->id)->get()->first();


                // copy the model of the current promotion
                $newStaffPromotion = $thisStaff_CurrentPromotion->replicate();

                //update and save
                $newStaffPromotion->staff_status = 1; // Now ACTIVE
                $newStaffPromotion->save();

                //change the promotion to past
                $thisStaff_CurrentPromotion->promotion_indicator = Promotions::$PAST_PROMOTION;
                $thisStaff_CurrentPromotion->save();

                $thisStaff->status = 1;
                $thisStaff->save();
                // ========================== DB::select("SELECT `to`-'now()' FROM `leave` WHERE `to`>='now()'")
                // DB::select("select now()")
            }

            $this->info("TOTAL OF $count LEAVE COMPLETED SUCCESSFULLY\n");
            \DB::commit();

        }catch(\Exception $e){
            var_dump($e->getMessage());
            echo ($e->getTraceAsString());

            \DB::rollback();
        }

    }
}
