<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

use App\User;
use \PDF;
use App\Staff;
use App\Promotions;
use App\StaffDepartment;
use App\StaffExtras;
use App\Position;
use Carbon\Carbon;
use PhpOffice\PhpSpreadsheet\Exception;
use App\SalaryScale;
use App\MyClasses\PromotionHandler;

class StaffPromoteCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'promote:staff';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Promote Staff Command From Excel Sheets';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info('Promotion Starting Now');

        echo "==================================================================================================";
        echo "==================================================================================================";
        echo "==================================================================================================";

        // For promoting staff
        $this->processStaffPromotion();

        //For Updating Staff Rank Levels
        // $this->updateStaffRankLevel();

        $this->info('Promotion Completed Successfully');
    }

    public function processStaffPromotion()
    {
        $this->info('++++++++');
        $files = Storage::files("promotefile");

        $this->info("Files To Be Processed: " . implode(", ", $files));

        if(count($files) > 0){
            $filesname = $files[0];
        }

        if(empty($filesname)){
          $this->info("No File Found");            
          return;  
        } 

        $this->info("File Being Processed: $filesname");

        $staffregnos_array = [];
        $council_meeting_count = '';
        $registrar = 'Haj. Rakiya U. Maleka';


        $filename_local = Storage::disk('local')->exists($filesname);

        var_dump($filename_local);
        $filestoragepath = storage_path("app/$filesname");
        $spreadSheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($filestoragepath);

        $worksheet = $spreadSheet->getActiveSheet();

        echo "COLINDEX\n";
        $highestRow = $worksheet->getHighestRow(); // e.g. 10
        $highestColumn = $worksheet->getHighestColumn(); // e.g 'F'
        $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn); // e.g. 5
        printf("<br/>HIGHEST ROW   %s<br/>HIGHEST COLUMN  %s<br/>HIGHEST COLUMN INDEX %s<br/>", $highestRow, $highestColumn, $highestColumnIndex);
        echo "\nCOLINDEX\n";


        $count = 0;
        $staff_category = 1; //academic 2 - non-academic

        echo '<table>' . PHP_EOL;
        foreach ($worksheet->getRowIterator() as $row) {
            if($count == 0) {
                echo "FIRST";
                echo '<tr>' . PHP_EOL;
                $cellIterator = $row->getCellIterator();
                try {
                    $cellIterator->setIterateOnlyExistingCells(FALSE);
                } catch (Exception $e) {
                }
                // This loops through all cells,

                foreach ($cellIterator as $key => $cell) {

                    switch ($key){
                        case 'P':
                           $council_meeting_count = $cell->getFormattedValue(); //88th
                            echo
                            $cell->getFormattedValue() . "   |==|  KEY: $key".
                            PHP_EOL;
                            break;
                        case 'Q':
                            $registrar = $cell->getFormattedValue(); // registra
                            echo 
                            $cell->getFormattedValue() . "   |==|  KEY: $key".
                            PHP_EOL;
                            break;
                    }

                    echo '<td>' .
                        $cell->getValue() . "   KEY: $key".
                        '</td>' . PHP_EOL;
                }
                echo '</tr>' . PHP_EOL;
                $count++;
            }else{
                
                $cellIterator = $row->getCellIterator();

                try {
                    $cellIterator->setIterateOnlyExistingCells(FALSE);
                } catch (Exception $e) {
                } // This loops through all cells


                foreach ($cellIterator as $key => $cell) {
                    switch ($key){
                        case 'A':
                           $exc_sn = $cell->getFormattedValue();
                            echo
                            $cell->getFormattedValue() . "   |==|  KEY: $key".
                            PHP_EOL;
                            if(!empty($exc_sn))
                                $staffregnos_array[] = $exc_sn;
                            break;
                        case 'B':
                            $exc_pfn = $cell->getFormattedValue();
                            echo 
                            $cell->getFormattedValue() . "   |==|  KEY: $key".
                            PHP_EOL;
                            break;
                    }

                }

                

                    // Adding the records
                    echo "PROMOTING STAFF WITH -PFN- $exc_sn - $count";
                    // $this->promoteStaff($exc_sn);
                   // $this->addRecords($exc_sn, $exc_pfn, $exc_surname, $exc_othername, $exc_sex,  $exc_gpzone, $exc_state, $exc_lga, $exc_prev_dept,  $exc_dept, $exc_qualifications, $exc_rank, $exc_compcas, $exc_step, $exc_birthdate,  $exc_firstappt,  $exc_pres_apt,  $exc_type_appt,  $exc_class, $exc_category,  $exc_status, $exc_mstatus, $exc_position, $exc_added_responsibility, $exc_phone_no );

                    //Adding Records


                    $count++;
                }

            //            if($count > 100) break;
            }
            echo '</table>' . PHP_EOL;

            $this->info("TOTAL-RECORDS: $count");

            //Generate PDF
            $promotedstaff = Staff::whereIn('staffno', $staffregnos_array )->get()->all();

            $cd = \Carbon\Carbon::now()->format('dS M, Y');

            // dd($staffregnos_array);
            // dd($promotedstaff);

            $ccd = $cd;

            $data = ['title' => 'Welcome To Staff Promotion Report', 'staffs' => $promotedstaff , 'council_count' => $council_meeting_count, 'registrar' => $registrar, 'todays_date' => $ccd ];

            $pdf =  PDF::loadView('myPDF', $data);

            $rand = rand(450, 898989);
            $pdf->save(storage_path("app/public/promotions/promotionletters.pdf"));



            if($count == $highestRow){
                ECHO "Deleted file $filesname\n";
               // Storage::disk('local')->delete($filesname);
                echo "\n";
            }

        }

        public function updateStaffRankLevel()
        {
            $this->info('++++++++');
            $files = Storage::files("staffgradelevelupdate");

            $this->info("Files To Be Processed: " . implode(", ", $files));

            if(count($files) > 0){
                $filesname = $files[0];
            }

            if(empty($filesname)){
              $this->info("No File Found");            
              return;  
            } 

            $this->info("File Being Processed: $filesname");

            $filename_local = Storage::disk('local')->exists($filesname);

            var_dump($filename_local);
            $filestoragepath = storage_path("app/$filesname");
            $spreadSheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($filestoragepath);

            $worksheet = $spreadSheet->getActiveSheet();

            echo "COLINDEX\n";
            $highestRow = $worksheet->getHighestRow(); // e.g. 10
            $highestColumn = $worksheet->getHighestColumn(); // e.g 'F'
            $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn); // e.g. 5
            printf("<br/>HIGHEST ROW   %s<br/>HIGHEST COLUMN  %s<br/>HIGHEST COLUMN INDEX %s<br/>", $highestRow, $highestColumn, $highestColumnIndex);
            echo "\nCOLINDEX\n";


            $count = 0;
            $staff_category = 1; //academic 2 - non-academic

            echo '<table>' . PHP_EOL;
            foreach ($worksheet->getRowIterator() as $row) {
                if($count == 0) {
                    echo "FIRST";
                    echo '<tr>' . PHP_EOL;
                    $cellIterator = $row->getCellIterator();
                    try {
                        $cellIterator->setIterateOnlyExistingCells(FALSE);
                    } catch (Exception $e) {
                    }
                    // This loops through all cells,

                    foreach ($cellIterator as $key => $cell) {
                        echo '<td>' .
                            $cell->getValue() . "   KEY: $key".
                            '</td>' . PHP_EOL;
                    }
                    echo '</tr>' . PHP_EOL;
                    $count++;
                }else{
                    
                    $cellIterator = $row->getCellIterator();

                    try {
                        $cellIterator->setIterateOnlyExistingCells(FALSE);
                    } catch (Exception $e) {
                    } // This loops through all cells


                    foreach ($cellIterator as $key => $cell) {
                        switch ($key){
                            case 'D':
                               $salaryScale = $cell->getFormattedValue();
                                echo
                                $cell->getFormattedValue() . "   |==|  KEY: $key".
                                PHP_EOL;
                                break;
                            case 'E':
                                $salaryScaleValue = $cell->getFormattedValue();
                                echo 
                                $cell->getFormattedValue() . "   |==|  KEY: $key".
                                PHP_EOL;
                                break;
                            case 'F':
                                $step = $cell->getFormattedValue();
                                echo 
                                $cell->getFormattedValue() . "   |==|  KEY: $key".
                                PHP_EOL;
                                break;
                            case 'I':
                               $exc_sn = $cell->getFormattedValue();
                                echo
                                $cell->getFormattedValue() . "   |==|  KEY: $key".
                                PHP_EOL;
                                break;
                        }

                    }
                        // Updating the records
                        echo "UPDATING STAFF WITH -PFN- $exc_sn - $count";

                        $this->updateStaffSalaryScaleRelatedDetails($exc_sn, $salaryScale, $salaryScaleValue, $step);
                       

                        //Adding Records


                        $count++;
                    }

                //            if($count > 100) break;
                }
                echo '</table>' . PHP_EOL;

                $this->info("TOTAL-RECORDS: $count");

                if($count == $highestRow){
                    ECHO "Deleted file $filesname\n";
                   // Storage::disk('local')->delete($filesname);
                    echo "\n";
                }

        }

        public function promoteStaff($staff_pfn)
        {
            $thisStaff = Staff::Where('staffno', $staff_pfn)->first();

            if(is_null($thisStaff)){
                return;
            }

            $promotionHandler = new PromotionHandler($staff_pfn);
            $promotionHandler->promoteStaff();

        }

        public function updateStaffSalaryScaleRelatedDetails($exc_sn, $salaryScale, $salaryScaleValue, $step)
        {
            $thisStaff = Staff::Where('staffno', $exc_sn)->first();

            if(is_null($thisStaff)){
                return;
            }

            $promotionHandler = new PromotionHandler($exc_sn);
            $promotionHandler->updateStaffPromotion($salaryScale, $salaryScaleValue, $step);

        }

    
}