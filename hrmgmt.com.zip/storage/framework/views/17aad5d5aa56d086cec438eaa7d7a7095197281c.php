<?php
    $current_page = 'rank';
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                        
                        <?php if(isset($displaystate)): ?>
                            <?php if($displaystate == 'edit'): ?>
                                <div class="header">
                                <h4 class="title">Update Rank Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('rank/'.$rank->first()->id )); ?>" method="POST">

                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Rank')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Rank')); ?>" class="form-control <?php echo e($errors->has('rank') ? ' is-invalid' : ''); ?>" name="rank" value="<?php echo e(old('rank', $rank->first()->rank)); ?>" required autofocus>
                                                <?php if($errors->has('rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('StaffClass')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('staffclass') ? ' is-invalid' : ''); ?>" name="staffclass" required >
                                                    <option <?php echo e(old('staffclass'=="AS"? 'selected="selected"': " ", ($rank->first()->staffclass == "AS"? 'selected': "" ))); ?> value="AS">AS - ACADEMIC STAFF</option>
                                                    <option <?php echo e(old('staffclass'=="NA"? 'selected="selected"': " ", ($rank->first()->staffclass == "NA"? 'selected': " "))); ?>  value="NA">NA - NON-ACADEMIC STAFF</option>
                                                </select>
                                                <?php if($errors->has('staffclass')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffclass')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Description')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $rank->first()->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("rank/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Rank Information</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php elseif($displaystate == 'delete'): ?>
                                <div class="header">
                                <h4 class="title text-danger">Delete Rank Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('rank/'.$rank->first()->id )); ?>" method="POST">

                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Rank?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Rank')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('Rank')); ?>" class="form-control <?php echo e($errors->has('rank') ? ' is-invalid' : ''); ?>" name="rank" value="<?php echo e(old('rank', $rank->first()->rank)); ?>" required autofocus>
                                                <?php if($errors->has('rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Rank StaffClass')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('Rank')); ?>" class="form-control <?php echo e($errors->has('rank') ? ' is-invalid' : ''); ?>" name="rank" value="<?php echo e(old('rank', $rank->first()->staffclass)); ?>" required autofocus>
                                                <?php if($errors->has('rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Rank Description')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $rank->first()->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("status/create")); ?>" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE Rank</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php else: ?>
                                
                                <div class="header">
                                <h4 class="title">View Rank Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" >


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Rank')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('Rank')); ?>" class="form-control <?php echo e($errors->has('rank') ? ' is-invalid' : ''); ?>" name="rank" value="<?php echo e(old('rank', $rank->first()->rank)); ?>" required autofocus>
                                                <?php if($errors->has('rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Rank StaffClass')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('Rank StaffClass')); ?>" class="form-control <?php echo e($errors->has('staffclass') ? ' is-invalid' : ''); ?>" name="staffclass" value="<?php echo e(old('staffclass', $rank->first()->staffclass)); ?>" required autofocus>
                                                <?php if($errors->has('staffclass')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffclass')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Description')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $rank->first()->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <a href="<?php echo e(url("rank/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="<?php echo e(url("rank/{$rank->first()->id}").'/edit'); ?>" class="btn btn-info btn-fill pull-right">Edit Rank Information</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        <?php else: ?>
                            
                            <div class="header">
                                <h4 class="title">Add New Rank</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('rank.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Rank')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Rank')); ?>" class="form-control <?php echo e($errors->has('rank') ? ' is-invalid' : ''); ?>" name="rank" value="<?php echo e(old('rank')); ?>" required autofocus>
                                                <?php if($errors->has('rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('StaffClass')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('staffclass') ? ' is-invalid' : ''); ?>" name="staffclass" required >
                                                    <option <?php echo e(old('staffclass'=="AS"? 'selected="selected"': " ", ($rank->first()->staffclass == "AS"? 'selected': "" ))); ?> value="AS">AS - ACADEMIC STAFF</option>
                                                    <option <?php echo e(old('staffclass'=="NA"? 'selected="selected"': " ", ($rank->first()->staffclass == "NA"? 'selected': " "))); ?>  value="NA">NA - NON-ACADEMIC STAFF</option>
                                                </select>
                                                <?php if($errors->has('staffclass')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffclass')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Description')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description')); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add New Rank</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Ranks Available</h4>
                                <p class="category">This is the list of All Rank Available</p>
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>Rank</th>
                                        <th>Staff-Class</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($eachRank->rank); ?></td>
                                            <td><?php echo e($eachRank->staffclass); ?></td>
                                            <td><?php echo e($eachRank->description); ?></td>
                                            <td style="min-width: 15em">
                                                <a class="btn btn-sm btn-info" href="<?php echo e(url("rank/$eachRank->id").'/edit'); ?>" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="<?php echo e(url("rank/$eachRank->id")); ?>" >View</a>
                                                <a class="btn btn-sm btn-danger" href="<?php echo e(url("rank/$eachRank->id?action=del")); ?>" >Delete</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>