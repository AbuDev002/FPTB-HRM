<?php
    $current_page = 'reports';
    $page_title = "Staff Reports";
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-12">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">Get Staff Summary Reports</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('leave.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-3 col-sm-3" style="border-right: 1px solid #333" >
                                            <div class="form-group" >
                                                <label><?php echo e(__('Summary Report')); ?></label><br/>
                                                <a href="<?php echo e(url('summary_report?act=active')); ?>" class="btn btn-success <?php echo e($typeact == 'active'? 'btn-fill' : ''); ?> <?php echo e($typeact == ''? 'btn-fill' : ''); ?> ">Active Summary Report</a>

                                            </div>
                                            <div class="form-group" >
                                                <label><?php echo e(__('Inactive Summary Report')); ?></label><br/>
                                                <a href="<?php echo e(url('summary_report?act=inactive')); ?>" class="btn btn-warning  <?php echo e($typeact == 'inactive'? 'btn-fill' : ''); ?> ">InActive Summary Report</a>

                                            </div>
                                        </div>
                                    </div>
                                    <hr>

                                    <h5 id="staff_report_title" class="text-center">STAFF REPORTS SUMMARY</h5>
                                    <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group" id="summarysearchResults">
                                           <table id="reportable_staff" class="table table-bordered table-condensed">
                                            <?php
                                                $count = 1;
                                                $summation_total = 0;
                                            ?>
                                                   <thead>
                                                       <tr>
                                                           <td>S/N</td>
                                                           
                                                           <td>RANK</td>
                                                           <td>TOTAL</td>
                                                           <td>STATUS</td>
                                                       </tr>
                                                   </thead>
                                                   <tbody id="summarysearchResultsBody">
                                                    <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <?php
                                                                $sub_total = 0;
                                                                $deptReport = \App\SummaryReport::getRecords($eachDepartment->id, $reverse_records);
                                                            ?>
                                                        <tr>
                                                            <td colspan="" style="text-align:center;"></td>
                                                            <td colspan="" style="text-align:center;"><b>DEPARTMENT OF <?php echo e($eachDepartment->id . ' '. $eachDepartment->description); ?></b></td>
                                                            <td colspan="" style="text-align:center;"></td>
                                                            <td colspan="" style="text-align:center;"></td>
                                                        </tr>
                                                        <?php $__currentLoopData = $deptReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subreport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $sub_total += $subreport->SUMMATION;
                                                        ?>
                                                        <tr>
                                                            <td><?php echo e($count++); ?></td>
                                                            
                                                            <td><?php echo e($subreport->rank); ?></td>
                                                            <td><?php echo e($subreport->SUMMATION); ?></td>
                                                            <td><?php echo e($subreport->status); ?></td>
                                                        </tr>
                                                        
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $summation_total += $sub_total;
                                                    ?>
                                                    <tr>
                                                        <td colspan=""  > </td>
                                                        <td colspan="" style="text-align: right;"><b>SUB-TOTAL IS:</b></td>
                                                        <td colspan=""><b><?php echo e("$sub_total"); ?></b></td>
                                                        <td colspan=""></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td colspan=""></td>
                                                        <td colspan="" style="text-align: right;"><b>GRAND TOTAL IS:</b></td>
                                                        <td colspan=""><b><?php echo e("$summation_total"); ?></b></td>
                                                        <td colspan=""></td>
                                                    </tr>
                                                   </tbody>
                                               </table>

                                            </div>
                                        </div>
                                    </div>


                                    <h5 id="staff_report_title" class="text-center">HOD REPORTS SUMMARY</h5>
                                    <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group" id="searchResults">

                                            <?php
                                                $count = 1;
                                                $summation_total = 0;
                                                $hodRecords = \App\SummaryReport::getHods($reverse_records);
                                            ?>

                                           <table id="summaryStaffReport" class="table table-bordered table-condensed">
                                                   <thead>
                                                       <tr>
                                                           <td>S/N</td>
                                                           <td>FULLNAME</td>
                                                           <td>RANK</td>
                                                           <td>DEPARTMENT</td>
                                                           <td>POSITION</td>
                                                           <td>STAFFNO</td>
                                                           <td>STATUS</td>
                                                       </tr>
                                                   </thead>
                                                   <tbody id="summaryStaffReportBody">
                                                    <?php $__currentLoopData = $hodRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachHodRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($count++); ?></td>
                                                            <td><?php echo e($eachHodRecord->fullname); ?></td>
                                                            <td><?php echo e($eachHodRecord->rank); ?></td>
                                                            <td><?php echo e($eachHodRecord->description); ?></td>
                                                            <td><?php echo e($eachHodRecord->position); ?></td>
                                                            <td><?php echo e($eachHodRecord->staffno); ?></td>
                                                            <td><?php echo e($eachHodRecord->status); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   </tbody>
                                               </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                                <hr>
                            </div>
                        </div>
                    </div>

                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
