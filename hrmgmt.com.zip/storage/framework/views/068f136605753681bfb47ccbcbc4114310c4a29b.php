<?php
    $current_page = 'appointmenttype';
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                        
                        <?php if(isset($displaystate)): ?>
                            <?php if($displaystate == 'edit'): ?>
                            
                                <div class="header">
                                <h4 class="title">Update Appointment Type Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('appointmenttype/'.$singleappointmenttype->id )); ?>" method="POST">

                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Appointment-Type')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Appointment-Type')); ?>" class="form-control <?php echo e($errors->has('appointmenttype') ? ' is-invalid' : ''); ?>" name="appointmenttype" value="<?php echo e(old('appointmenttype', $singleappointmenttype->appointmenttype)); ?>" required autofocus>
                                                <?php if($errors->has('appointmenttype')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('appointmenttype')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Description')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $singleappointmenttype->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("appointmenttype/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Appointment-Type Information</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php elseif($displaystate == 'delete'): ?>
                                <div class="header">
                                <h4 class="title text-danger">Delete Appointment-Type Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('appointmenttype/'.$singleappointmenttype->id )); ?>" method="POST">

                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Appointment-Type?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Appointment-Type')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('Appointment-Type')); ?>" class="form-control <?php echo e($errors->has('appointmenttype') ? ' is-invalid' : ''); ?>" name="appointmenttype" value="<?php echo e(old('appointmenttype', $singleappointmenttype->appointmenttype)); ?>" required autofocus>
                                                <?php if($errors->has('appointmenttype')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('appointmenttype')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Appointment-Type Description')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $singleappointmenttype->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("appointmenttype/create")); ?>" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE Appointment-Type</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php else: ?>
                                
                                <div class="header">
                                <h4 class="title">View Appointment-Type Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" >


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Appointment-Type')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('Appointment-Type')); ?>" class="form-control <?php echo e($errors->has('appointmenttype') ? ' is-invalid' : ''); ?>" name="appointmenttype" value="<?php echo e(old('appointmenttype', $singleappointmenttype->appointmenttype)); ?>" required autofocus>
                                                <?php if($errors->has('appointmenttype')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('appointmenttype')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Description')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $singleappointmenttype->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <a href="<?php echo e(url("appointmenttype/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="<?php echo e(url("appointmenttype/{$singleappointmenttype->id}").'/edit'); ?>" class="btn btn-info btn-fill pull-right">Edit Appointment-Type Information</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        <?php else: ?>
                            
                            <div class="header">
                                <h4 class="title">Add New Appointment-Type</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('appointmenttype.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Appointment-Type')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Appointment-Type')); ?>" class="form-control <?php echo e($errors->has('appointmenttype') ? ' is-invalid' : ''); ?>" name="appointmenttype" value="<?php echo e(old('appointmenttype')); ?>" required autofocus>
                                                <?php if($errors->has('appointmenttype')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('appointmenttype')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Description')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description')); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add New Appointment-Type</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Appointment Type Available</h4>
                                <p class="category">This is the list of All Appointment Type Available</p>
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>Appointment-Type</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $appointmenttype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachAppointmenttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($eachAppointmenttype->appointmenttype); ?></td>
                                            <td><?php echo e($eachAppointmenttype->description); ?></td>
                                            <td>
                                                <a class="btn btn-sm btn-info" href="<?php echo e(url("appointmenttype/$eachAppointmenttype->id").'/edit'); ?>" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="<?php echo e(url("appointmenttype/$eachAppointmenttype->id")); ?>" >View</a>
                                                <a class="btn btn-sm btn-danger" href="<?php echo e(url("appointmenttype/$eachAppointmenttype->id?action=del")); ?>" >Delete</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>