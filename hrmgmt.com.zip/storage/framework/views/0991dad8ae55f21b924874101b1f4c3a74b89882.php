<?php
    $current_page = 'reports';
    $page_title = "Staff To Be Promoted";
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-12">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">Staff Due For Promotion Listing</h4>
                                <p class="category">List of Staff That Are Due For Promotion</p>
                                <p>
                                    <?php if(in_array('photo',$hide_columns) || in_array('action', $hide_columns) ): ?>
                                        <button src-link-attr="<?php echo e(url('promotionlist')); ?>" id="btn_select_staff_promote" class="btn-small btn-fill btn btn-danger">Hide/Show Action & Photo Columns</button>
                                    <?php else: ?>
                                        <button src-link-attr="<?php echo e(url('promotionlist')); ?>?hide1=action&hide2=photo" id="btn_select_staff_promote" class="btn-small btn btn-danger">Hide/Show Action & Photo Columns</button>
                                    <?php endif; ?>

                                    &nbsp; 
                                    <?php if($quater == 'jan'): ?>
                                      <label><input id="jan_quater" checked="checked" class="input input-sm" value="jan" type="radio" name="quater"> JANUARY LISTING</label>  
                                    <?php else: ?>
                                    <label><input id="jan_quater" class="input input-sm" value="jan" type="radio" name="quater"> JANUARY LISTING</label>
                                    <?php endif; ?>


                                    <?php if($quater == 'july'): ?>
                                    <label>
                                      <input checked="checked" id="july_quater" class="input input-sm" type="radio" value="july" name="quater"> JULY LISTING
                                    </label>
                                    <?php else: ?>
                                    <label>
                                      <input id="july_quater" class="input input-sm" type="radio" value="july" name="quater"> JULY LISTING
                                    </label>
                                    <?php endif; ?>

                                    <?php if($quater == 'all'): ?>
                                    <label>
                                      <input checked="checked" id="all_quater" class="input input-sm" type="radio" value="all" name="quater"> ALL LISTING
                                    </label>
                                    <?php else: ?>
                                    <label>
                                      <input id="all_quater" class="input input-sm" type="radio" value="all" name="quater"> ALL LISTING
                                    </label>
                                    <?php endif; ?>

                                      &nbsp;  YEAR: 
                                    <?php if(!empty($quater_year)): ?>
                                    <label>
                                     <input name="" id="promotion_year" class="btn btn-primary" type="date" value="<?php echo e($quater_year); ?>" >
                                    </label>
                                    <?php else: ?>
                                    <label>
                                      <input name="" id="promotion_year" class="btn btn-primary" type="date" value="<?php echo e(date('Y-m-d')); ?>" >
                                    </label>
                                    <?php endif; ?>
                                </p>
                             
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('leave.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <?php

                                      if($quater_year != 'all')
                                        $carbon_quater_year = \Carbon\Carbon::parse("$quater_year");
                                      else
                                        $carbon_quater_year = \Carbon\Carbon::now();


                                      if($quater_year != 'all' && $quater != 'all'){
                                          $quater_year_only = $carbon_quater_year->year;

                                                          if($quater == 'jan'){
                                                              $title = "JANUARY LIST OF STAFF DUE FOR PROMOTION IN THE YEAR $quater_year_only";
                                                            }elseif($quater == 'july'){
                                                              $title = "JULY LIST OF STAFF DUE FOR PROMOTION IN THE YEAR $quater_year_only";
                                                            }

                                      }elseif($quater_year == 'all' && $quater != 'all'){
                                                            if($quater == 'jan'){
                                                              $title = "JANUARY LIST OF STAFF DUE FOR PROMOTION FOR ALL YEARS";
                                                            }elseif($quater == 'july'){
                                                              $title = "JULY LIST OF STAFF DUE FOR PROMOTION FOR ALL YEARS";
                                                            }
                                                          }elseif($quater_year != 'all' && $quater == 'all'){
                                                            $quater_year_only = $carbon_quater_year->year;
                                                            $title = "ALL STAFF DUE FOR PROMOTION IN YEAR $quater_year_only";
                                                          }else{
                                                            $title = "ALL STAFF DUE FOR PROMOTION FOR ALL YEARS";
                                                          }
                                    ?>

                                    <script type="text/javascript">
                                      document.title = "REGISTRY REPORT::<?php echo e($title); ?>";
                                    </script>

                                    <h5 id="staff_report_title" name="staff_report_title_name" class="text-center"><?php echo e($title); ?></h5>
                                    <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group" id="searchResults">
                                           <table id="stafftobepromoted" class="table table-bordered table-condensed">
                                                   <thead>
                                                       <tr>
                                                           <td>S/N</td>
                                                           <td>STAFFNO</td>
                                                           <td>FULLNAMES</td>
                                                           <?php if(!in_array('photo',$hide_columns)): ?>
                                                               <th>Staff photo</th>
                                                           <?php endif; ?>
                                                           <td>DEPARTMENT</td>
                                                           <td>GENDER</td>
                                                           <td>SALARY SCALE</td>
                                                           <td>LEVEL</td>
                                                           <td>STEP</td>
                                                           <td>RANK</td>
                                                           <td>CATEGORY</td>
                                                           <td>CLASS</td>
                                                           <td>DATEOB</td>
                                                           <td>POSITION</td>
                                                           <td>PHONENO</td>
                                                           <td>STATE</td>
                                                           <td>LGA</td>
                                                           <td>STATUS</td>
                                                           <td>LAST PROMOTED</td>
                                                           <td>DUE FOR PROMOTION AS AT</td>
                                                           <?php if(!in_array('action',$hide_columns)): ?>
                                                               <th>Action</th>
                                                           <?php endif; ?>
                                                       </tr>
                                                   </thead>
                                                   <tbody id="searchResultsBody">
                                                   <?php
                                                       $count_c = 1;

                                                       $chief_ranks = \App\Rank::where('rank', 'like', '%Chief%')->get()->pluck('id')->all();
                                                       
                                                       
                                                       $special_ranks = \App\Rank::where('rank', 'RECTOR')
                                                       ->where('rank', 'BURSAR')
                                                       ->where('rank', 'DEPUTY REGISTRAR')
                                                       ->where('rank', 'POLYTECHNIC LIBRARIAN')
                                                       ->where('rank', 'DEPUTY RECTOR')
                                                       ->get()->pluck('id')->all();

                                                       $permanent_staffs = \App\AppointmentType::where('appointmenttype', 'like', '%PERM%')->pluck('id')->all();

                                                   ?>

                                                   <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStaff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                       <?php
                                                           $department = \App\Department::find(\App\StaffDepartment::where(['staff_id'=>$eachStaff->id])->first()['dept_id'])['description'];
                                                           $department = $eachStaff->getDepartment();
                                                           $currentPromotion = \App\Promotions::where('status', \App\Promotions::$APPROVED_PROMOTION)
                                                               ->where('promotion_indicator', \App\Promotions::$CURRENT_PROMOTION)->where('staff_id', $eachStaff->id)->get()->first();

                                                           $rank = \App\Rank::find($currentPromotion->rank);
                                                           $status = \App\Status::find($currentPromotion->staff_status)->status;
                                                       $thisDate = $currentPromotion->promotion_date;

                                                       // dump($thisDate); //dd("STOP");
                                                       $datework = \Carbon\Carbon::parse($thisDate);
                                                       
                                                       $considered_year_date = $carbon_quater_year;

                                                       $yearDifferenceNow = ($considered_year_date->year - $datework->year);


                                                      if($quater == 'jan'){
                                                        if( $yearDifferenceNow >= 3 && ($datework->month <= 6) ){

                                                        // If this staff is currently a Chief in Rank
                                                        if(!in_array($currentPromotion->rank, $chief_ranks) && in_array($currentPromotion->appointmenttype, $permanent_staffs) && !in_array($currentPromotion->rank, $special_ranks) && ($currentPromotion->last_promotion_status != \App\Promotions::$IS_LAST_PROMOTED)){

                                                              $isOkToDisplayRecord = true;

                                                          if($isOkToDisplayRecord){

                                                       ?>

                                                       <tr>
                                                           <td><?php echo e($count_c++); ?></td>
                                                           <td><?php echo e($eachStaff->staffno); ?></td>
                                                           <td><?php echo e("{$eachStaff->fname} {$eachStaff->lname} {$eachStaff->oname}"); ?></td>
                                                           <?php if(!in_array('photo',$hide_columns)): ?>
                                                               <td><img class="img" width="100px" height="100px" src="<?php echo e(\Storage::url("{$eachStaff->photo}")); ?>"  /> </td>
                                                           <?php endif; ?>
                                                           <td><?php echo e($department); ?></td>
                                                           <td><?php echo e($eachStaff->gender); ?></td>
                                                           <td><?php echo e($currentPromotion->getSalaryScale()); ?></td>
                                                           <td><?php echo e($currentPromotion->salary_scale_value); ?></td>
                                                           <td><?php echo e($currentPromotion->step); ?></td>
                                                           <td><?php echo e($rank->rank); ?></td>
                                                           <td><?php echo e($currentPromotion->category); ?></td>
                                                           <td><?php echo e($currentPromotion->staffclass); ?></td>
                                                           <td><?php echo e($eachStaff->dateobirth); ?></td>
                                                           <td><?php echo e($currentPromotion->getPosition()); ?></td>
                                                           <td><?php echo e($eachStaff->phoneno); ?></td>
                                                           <td><?php echo e($eachStaff->getDetails()['state']); ?></td>
                                                           <td><?php echo e($eachStaff->getDetails()['lga']); ?></td>
                                                           <td><?php echo e($currentPromotion->getStaffStatus()); ?></td>
                                                           <td><?php echo e($currentPromotion->presentappointdate); ?></td>
                                                           <td>
                                                               <?php

                                                               \App\Http\Controllers\StaffController::getDueDate($datework);

                                                                ?>
                                                           </td>

                                                           <?php if(!in_array('action',$hide_columns)): ?>
                                                               <td>

                                                                   <form onsubmit="return (confirm('Are you Sure That You Want To Delete This Record? Please Confirm.?'))" action="<?php echo e(url("staff/". $eachStaff->id)); ?>" method="POST" >
                                                                       <input type="hidden" name="_method" value="delete">
                                                                       <?php echo csrf_field(); ?>
                                                                       <a class="btn btn-sm btn-primary " href="<?php echo e(url('promote/'.$eachStaff->id)); ?>">Promote</a>

                                                                   </form>
                                                               </td>
                                                           <?php endif; ?>

                                                       </tr>
                                                       <?php
                                                          }
                                                          }
                                                        }
                                                      }elseif($quater == 'july'){
                                                          if( $yearDifferenceNow >= 3 && ($datework->month > 6) ){

                                                        // If this staff is currently a Chief in Rank
                                                        if(!in_array($currentPromotion->rank, $chief_ranks)  && !in_array($currentPromotion->rank, $special_ranks)  && in_array($currentPromotion->appointmenttype, $permanent_staffs) && ($currentPromotion->last_promotion_status != \App\Promotions::$IS_LAST_PROMOTED)){

                                                              $isOkToDisplayRecord = true;

                                                          if($isOkToDisplayRecord){

                                                       ?>

                                                       <tr>
                                                           <td><?php echo e($count_c++); ?></td>
                                                           <td><?php echo e($eachStaff->staffno); ?></td>
                                                           <td><?php echo e("{$eachStaff->fname} {$eachStaff->lname} {$eachStaff->oname}"); ?></td>
                                                           <?php if(!in_array('photo',$hide_columns)): ?>
                                                               <td><img class="img" width="100px" height="100px" src="<?php echo e(\Storage::url("{$eachStaff->photo}")); ?>"  /> </td>
                                                           <?php endif; ?>
                                                           <td><?php echo e($department); ?></td>
                                                           <td><?php echo e($eachStaff->gender); ?></td>
                                                           <td><?php echo e($currentPromotion->getSalaryScale()); ?></td>
                                                           <td><?php echo e($currentPromotion->salary_scale_value); ?></td>
                                                           <td><?php echo e($currentPromotion->step); ?></td>
                                                           <td><?php echo e($rank->rank); ?></td>
                                                           <td><?php echo e($currentPromotion->category); ?></td>
                                                           <td><?php echo e($currentPromotion->staffclass); ?></td>
                                                           <td><?php echo e($eachStaff->dateobirth); ?></td>
                                                           <td><?php echo e($currentPromotion->getPosition()); ?></td>
                                                           <td><?php echo e($eachStaff->phoneno); ?></td>
                                                           <td><?php echo e($eachStaff->getDetails()['state']); ?></td>
                                                           <td><?php echo e($eachStaff->getDetails()['lga']); ?></td>
                                                           <td><?php echo e($currentPromotion->getStaffStatus()); ?></td>
                                                           <td><?php echo e($currentPromotion->presentappointdate); ?></td>
                                                           <td>
                                                               <?php

                                                                \App\Http\Controllers\StaffController::getDueDate($datework);

                                                                ?>
                                                           </td>

                                                           <?php if(!in_array('action',$hide_columns)): ?>
                                                               <td>

                                                                   <form onsubmit="return (confirm('Are you Sure That You Want To Delete This Record? Please Confirm.?'))" action="<?php echo e(url("staff/". $eachStaff->id)); ?>" method="POST" >
                                                                       <input type="hidden" name="_method" value="delete">
                                                                       <?php echo csrf_field(); ?>
                                                                       <a class="btn btn-sm btn-primary " href="<?php echo e(url('promote/'.$eachStaff->id)); ?>">Promote</a>

                                                                   </form>
                                                               </td>
                                                           <?php endif; ?>

                                                       </tr>
                                                       <?php
                                                          }
                                                          }
                                                        }
                                                      }else{
                                                        if( $yearDifferenceNow >= 3 ){

                                                        // If this staff is currently a Chief in Rank
                                                        if(!in_array($currentPromotion->rank, $chief_ranks)  && !in_array($currentPromotion->rank, $special_ranks) && in_array($currentPromotion->appointmenttype, $permanent_staffs) && ($currentPromotion->last_promotion_status != \App\Promotions::$IS_LAST_PROMOTED)){

                                                              $isOkToDisplayRecord = true;

                                                          if($isOkToDisplayRecord){

                                                       ?>

                                                       <tr>
                                                           <td><?php echo e($count_c++); ?></td>
                                                           <td><?php echo e($eachStaff->staffno); ?></td>
                                                           <td><?php echo e("{$eachStaff->fname} {$eachStaff->lname} {$eachStaff->oname}"); ?></td>
                                                           <?php if(!in_array('photo',$hide_columns)): ?>
                                                               <td><img class="img" width="100px" height="100px" src="<?php echo e(\Storage::url("{$eachStaff->photo}")); ?>"  /> </td>
                                                           <?php endif; ?>
                                                           <td><?php echo e($department); ?></td>
                                                           <td><?php echo e($eachStaff->gender); ?></td>
                                                           <td><?php echo e($currentPromotion->getSalaryScale()); ?></td>
                                                           <td><?php echo e($currentPromotion->salary_scale_value); ?></td>
                                                           <td><?php echo e($currentPromotion->step); ?></td>
                                                           <td><?php echo e($rank->rank); ?></td>
                                                           <td><?php echo e($currentPromotion->category); ?></td>
                                                           <td><?php echo e($currentPromotion->staffclass); ?></td>
                                                           <td><?php echo e($eachStaff->dateobirth); ?></td>
                                                           <td><?php echo e($currentPromotion->getPosition()); ?></td>
                                                           <td><?php echo e($eachStaff->phoneno); ?></td>
                                                           <td><?php echo e($eachStaff->getDetails()['state']); ?></td>
                                                           <td><?php echo e($eachStaff->getDetails()['lga']); ?></td>
                                                           <td><?php echo e($currentPromotion->getStaffStatus()); ?></td>
                                                           <td><?php echo e($currentPromotion->presentappointdate); ?></td>
                                                           <td>
                                                              <?php
                                                                  \App\Http\Controllers\StaffController::getDueDate($datework);
                                                              ?>
                                                           </td>

                                                           <?php if(!in_array('action',$hide_columns)): ?>
                                                               <td>

                                                                   <form onsubmit="return (confirm('Are you Sure That You Want To Delete This Record? Please Confirm.?'))" action="<?php echo e(url("staff/". $eachStaff->id)); ?>" method="POST" >
                                                                       <input type="hidden" name="_method" value="delete">
                                                                       <?php echo csrf_field(); ?>
                                                                       <a class="btn btn-sm btn-primary " href="<?php echo e(url('promote/'.$eachStaff->id)); ?>">Promote</a>

                                                                   </form>
                                                               </td>
                                                           <?php endif; ?>

                                                       </tr>
                                                       <?php
                                                          }
                                                          }
                                                        }
                                                      }
                                                      

                                                       ?>

                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   </tbody>
                                               </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                                <hr>

                            </div>
                        </div>
                    </div>

                </div>

                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>