<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.ico')); ?> ">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>H-R Federal Polytechnic Bauchi :: <?php echo e(isset($page_title)? $page_title : ''); ?></title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="<?php echo e(asset('assets/css/animate.min.css')); ?>" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="<?php echo e(asset('assets/css/light-bootstrap-dashboard.css?v=1.4.0')); ?>" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo e(asset('assets/css/demo.css')); ?>" rel="stylesheet" />



    <!--     Fonts and icons     -->
    <link href="<?php echo e(asset('http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href='<?php echo e(asset("http://fonts.googleapis.com/css?family=Roboto:400,700,300")); ?> ' rel='stylesheet' type='text/css'>
    <link href="<?php echo e(asset('assets/css/pe-icon-7-stroke.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/datatables.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo e(asset('assets/css/mystyle.css')); ?>" rel="stylesheet" />

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="purple" data-image="<?php echo e(asset('assets/img/sidebar-5.jpg')); ?>">

    <!--
        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag
    -->

        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                    HR-App
                </a>
            </div>

            <ul class="nav">

    <?php if(\Auth::user()->access_level == \App\Staff::$USER_ADMIN): ?>
        <?php if($current_page == 'dashboard'): ?>
                <li class="active">
                    <a href="<?php echo e(url('/home')); ?>">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(url('/home')); ?>">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'appointmenttype'): ?>
                <li class="active">
                    <a href="<?php echo e(route('appointmenttype.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Appoint-Type</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('appointmenttype.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Appoint-Type</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'school'): ?>
                <li class="active">
                    <a href="<?php echo e(route('school.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View School</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('school.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View School</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'department'): ?>
                <li class="active">
                    <a href="<?php echo e(route('department.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Department</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('department.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Department</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'departmentunits'): ?>
                <li class="active">
                    <a href="<?php echo e(route('units.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Dept Units</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('units.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Dept Units</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'rank'): ?>
                <li class="active">
                    <a href="<?php echo e(route('rank.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Rank</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('rank.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Rank</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'zone'): ?>
                <li class="active">
                    <a href="<?php echo e(route('zone.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Zone</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('zone.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Zone</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'status'): ?>
                <li class="active">
                    <a href="<?php echo e(route('status.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Status</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('status.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Status</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'addstaff'): ?>
                <li class="active">
                    <a href="<?php echo e(route('staff.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add New Staff</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('staff.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add New Staff</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'viewstaff'): ?>
                <li class="active">
                    <a href="<?php echo e(route('staff.index')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View/Update Staff</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('staff.index')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View/Update Staff</p>
                    </a>
                </li>
                <?php endif; ?>

                

                <?php if($current_page == 'promotion_process'): ?>
                <li class="active">
                    <a href="<?php echo e(route('promotion_upload_process.index')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Promotion Process Mgmt</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('promotion_upload_process.index')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Promotion Process Mgmt</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'salary_structure_setting'): ?>
                <li class="active">
                    <a href="<?php echo e(route('salary_structure_setting.index')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Salary Structure Settings</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('salary_structure_setting.index')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Salary Structure Settings</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'rankpromotionform'): ?>
                <li class="active">
                    <a href="<?php echo e(route('rank_promotion_setting.index')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Rank Promotion Settings</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('rank_promotion_setting.index')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Rank Promotion Settings</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'position'): ?>
                <li class="active">
                    <a href="<?php echo e(route('position.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Position</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('position.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Add/View Position</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'salary-scale'): ?>
                    <li class="active">
                        <a href="<?php echo e(route('salaryscale.create')); ?>">
                            <i class="pe-7s-user"></i>
                            <p>Manage Salary Scale</p>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="">
                        <a href="<?php echo e(route('salaryscale.create')); ?>">
                            <i class="pe-7s-user"></i>
                            <p>Manage Salary Scale</p>
                        </a>
                    </li>
                <?php endif; ?>



                <?php if($current_page == 'profile'): ?>
                <li class="active">
                    <a href="<?php echo e(route('account.profile')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Update Account Info</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('account.profile')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Update Acount Info</p>
                    </a>
                </li>
                <?php endif; ?>
<hr>

                <?php if($current_page == 'reports'): ?>
                <li class="active">
                    <a href="<?php echo e(route('staff.reports')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Get Staff Reports</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('staff.reports')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Get Staff Reports</p>
                    </a>
                </li>
                <?php endif; ?>

            <?php if($current_page == 'due_for_promotions'): ?>
                <li class="active">
                    <a href="<?php echo e(route('staff.promotionlist')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Due For Promotion</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('staff.promotionlist')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Due For Promotion</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'online'): ?>
                <li class="active">
                    <a href="<?php echo e(route('user.online')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Users</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('user.online')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Users</p>
                    </a>
                </li>
                <?php endif; ?>

    <?php elseif(\Auth::user()->access_level == \App\Staff::$USER_SUBADMIN): ?>

                <?php if($current_page == 'dashboard'): ?>
                <li class="active">
                    <a href="<?php echo e(url('/home')); ?>">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(url('/home')); ?>">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'appointmenttype'): ?>
                <li class="active">
                    <a href="<?php echo e(route('appointmenttype.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Appoint-Type</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('appointmenttype.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Appoint-Type</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'school'): ?>
                <li class="active">
                    <a href="<?php echo e(route('school.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View School</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('school.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View School</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'department'): ?>
                <li class="active">
                    <a href="<?php echo e(route('department.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Department</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('department.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Department</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'rank'): ?>
                <li class="active">
                    <a href="<?php echo e(route('rank.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Rank</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('rank.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Rank</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'zone'): ?>
                <li class="active">
                    <a href="<?php echo e(route('zone.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Zone</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('zone.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Zone</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'status'): ?>
                <li class="active">
                    <a href="<?php echo e(route('status.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Status</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('status.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Status</p>
                    </a>
                </li>
                <?php endif; ?>

              

                <?php if($current_page == 'viewstaff'): ?>
                <li class="active">
                    <a href="<?php echo e(route('staff.index')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View/Update Staff</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('staff.index')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View/Update Staff</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'leave'): ?>
                <li class="active">
                    <a href="<?php echo e(route('leave.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Manage Staff Leave</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('leave.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Manage Staff Leave</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if($current_page == 'position'): ?>
                <li class="active">
                    <a href="<?php echo e(route('position.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Position</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('position.create')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>View Position</p>
                    </a>
                </li>
                <?php endif; ?>


                <?php if($current_page == 'profile'): ?>
                <li class="active">
                    <a href="<?php echo e(route('account.profile')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Update Account Info</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('account.profile')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Update Acount Info</p>
                    </a>
                </li>
                <?php endif; ?>
<hr>

                <?php if($current_page == 'reports'): ?>
                <li class="active">
                    <a href="<?php echo e(route('staff.reports')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Get Staff Reports</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('staff.reports')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Get Staff Reports</p>
                    </a>
                </li>
                <?php endif; ?>

        <?php elseif(\Auth::user()->access_level == \App\Staff::$USER_STAFF): ?>

                <?php if($current_page == 'dashboard'): ?>
                <li class="active">
                    <a href="<?php echo e(url('/home')); ?>">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(url('/home')); ?>">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <?php endif; ?>


                <?php if($current_page == 'staffinfo'): ?>
                <li class="active">
                    <a href="<?php echo e(route('account.staffinfo')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Your Info</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('account.staffinfo')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Your Info</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if(App\GenSettings::showEnable()): ?>
                    <?php if($current_page == 'basic-info-update'): ?>
                    <li class="active">
                        <a href="<?php echo e(route('staff.basic-info-update')); ?>">
                            <i class="pe-7s-info"></i>
                            <p>Update Info<i style="color:red">*</i></p>
                        </a>
                    </li>
                    <?php else: ?>
                    <li class="">
                        <a href="<?php echo e(route('staff.basic-info-update')); ?>">
                            <i class="pe-7s-info"></i>
                            <p>Update Info<i style="color:red">*</i></p>
                        </a>
                    </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if($current_page == 'addqualification'): ?>
                <li class="active">
                    <a href="<?php echo e(route('account.addqualification')); ?>">
                        <i class="pe-7s-pen"></i>
                        <p>Add New Qualification</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('account.addqualification')); ?>">
                        <i class="pe-7s-pen"></i>
                        <p>Add New Qualification</p>
                    </a>
                </li>
                <?php endif; ?>

                  <?php if($current_page == 'profile'): ?>
                <li class="active">
                    <a href="<?php echo e(route('account.profile')); ?>">
                        <i class="pe-7s-info"></i>
                        <p>Manage Account Info</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="">
                    <a href="<?php echo e(route('account.profile')); ?>">
                        <i class="pe-7s-info"></i>
                        <p>Manage Account Info</p>
                    </a>
                </li>
                <?php endif; ?>


         <?php endif; ?>

            </ul>
        </div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(url('home')); ?>">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
                                <p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>
                        <!-- <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-globe"></i>
                                    <b class="caret hidden-lg hidden-md"></b>
                                    <p class="hidden-lg hidden-md">
                                        5 Notifications
                                        <b class="caret"></b>
                                    </p>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
                        <li>
                           <a href="#">
                                <i class="fa fa-search"></i>
                                <p class="hidden-lg hidden-md">Search</p>
                           </a>
                        </li>-->

                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="#">
                                <?php
                                    $Accesslevel = Auth::user()->access_level;

                                    if($Accesslevel == \App\Staff::$USER_ADMIN)
                                    {
                                        $salutation = "Admin ".Auth::user()->name;
                                    }else if($Accesslevel == \App\Staff::$USER_SUBADMIN){
                                        $salutation = "Sub-Admin ".Auth::user()->name;
                                    }else if($Accesslevel == \App\Staff::$USER_STAFF){
                                        $salutation = "Staff ".Auth::user()->name;

                                    }
                                ?>
                               <p>Welcome, <?php echo e($salutation); ?></p>
                            </a>
                        </li>
                        <li>
                           <a href="<?php echo e(url('accountprofile')); ?>">
                               <p>Account</p>
                            </a>
                        </li>
                        <!-- <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <p>
                                        Dropdown
                                        <b class="caret"></b>
                                    </p>

                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                              </ul>
                        </li> -->
                        <li>
                            <form method="post" action="<?php echo e(url('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="btn btb-sm btn-success btn-block" href="#">
                                    <p>Log out</p>
                                </button>
                            </form>
                        </li>
                        <li class="separator hidden-lg"></li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
