<?php
    $current_page = 'profile';
    $page_title = "Your Profile Page";
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">


                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <p class="text-info">
                                    <?php if($errors->any()): ?>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="info text-danger"><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </p>
                                <h4 class="title">Manage Your Account</h4>
                                <p class="category"></p>
                                 <?php if(session('status')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('pasword-update-alert')): ?>
                                    <div class="alert alert-info">
                                        <?php echo e(session('pasword-update-alert')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('updateaccountaccess')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Full Name')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('Full Name')); ?>" class="form-control <?php echo e($errors->has('firstname') ? ' is-invalid' : ''); ?>" name="firstname" value="<?php echo e(Auth::user()->name); ?>" required autofocus>
                                                <?php if($errors->has('firstname')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('firstname')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('OldPassword')); ?></label>
                                                <input type="password" placeholder="<?php echo e(__('Old Password')); ?>" class="form-control <?php echo e($errors->has('oldpassword') ? ' is-invalid' : ''); ?>" name="oldpassword" value="<?php echo e(old('oldpassword')); ?>" required autofocus>
                                                <?php if($errors->has('oldpassword')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('oldpassword')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('New Password')); ?></label>
                                                <input type="password" placeholder="<?php echo e(__('New Password')); ?>" class="form-control <?php echo e($errors->has('newpassword') ? ' is-invalid' : ''); ?>" name="newpassword" value="<?php echo e(old('newpassword')); ?>" required autofocus>
                                                <?php if($errors->has('newpassword')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('newpassword')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('Confirm New Password')); ?></label>
                                                <input type="password" placeholder="<?php echo e(__('Confirm New Password')); ?>" class="form-control <?php echo e($errors->has('confirmnewpassword') ? ' is-invalid' : ''); ?>" name="confirmnewpassword" value="<?php echo e(old('confirmnewpassword')); ?>" required autofocus>
                                                <?php if($errors->has('confirmnewpassword')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('confirmnewpassword')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>


                                    </div>
                                    <hr>

                                    <button id="updateStaffbtnsubmit" type="submit" class="btn btn-success btn-fill pull-right">Updated Account Password</button>
                                    <div class="clearfix"></div>
                                </form>
                                <?php if(\Auth::user()->isAdmin()): ?>
                                <form enctype="multipart/form-data" action="<?php echo e(route('updateaccountaccess')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="photo_update" value="TRUE" >
                                    <hr/>
                                     <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label><?php echo e(__('Photo')); ?></label>
                                                <input required="required" type="file" class="form-control" placeholder="<?php echo e(__('photo')); ?>" class="form-control <?php echo e($errors->has('photo') ? ' is-invalid' : ''); ?>" name="photo" value="<?php echo e(old('photo')); ?>"  autofocus>

                                                <?php if($errors->has('photo')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('photo')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <button id="updateStaffbtnsubmit" type="submit" class="btn btn-success btn-fill pull-left">Updated Profile Picture</button>
                                    <div class="clearfix"></div>
                                </form>
                                <?php endif; ?>
                                

                            </div>
                        </div>
                                <h4>Your Account Login History For the Last 30 Days</h4>
                                <table id="account_login_history_personal" class="table table-bordered table-condensed">
                                    <thead>
                                        <tr>
                                            <td>ID</td>
                                            <td>Username</td>
                                            
                                            <td>TYPE</td>
                                            <td>DATETIME</td>
                                            <td>IP-Address</td>
                                            <td>Browser</td>
                                            <td>Platform</td>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <td>ID</td>
                                            <td>Username</td>
                                            
                                            <td>TYPE</td>
                                            <td>DATETIME</td>
                                            <td>IP-Address</td>
                                            <td>Browser</td>
                                            <td>Platform</td>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                            $count_id = 1;
                                        ?>

                                        <?php $__currentLoopData = $loginHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachLoginHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <tr>
                                            <td><?php echo e($count_id++); ?></td>
                                            <td><?php echo e($eachLoginHistory->username); ?></td>
                                            <td><?php echo e(($eachLoginHistory->type == \App\LoginHistory::$LOGIN_TYPE) ? "LOGIN" : ( ($eachLoginHistory->type == \App\LoginHistory::$LOGOUT_TYPE) ? "LOGOUT" : ($eachLoginHistory->type == \App\LoginHistory::$LOGIN_ATTEMPT ? "LOGIN_ATTEMPT" : "UNKNOWN"))); ?></td>
                                            <td><?php echo e($c = new \Carbon\Carbon($eachLoginHistory->created_at)); ?> - <span>&nbsp;&nbsp;</span> <?php echo e($c->diffForHumans()); ?></td>
                                            <td><?php echo e($eachLoginHistory->ip); ?></td>
                                            <td><?php echo e($eachLoginHistory->browser); ?></td>
                                            <td><?php echo e($eachLoginHistory->platform); ?></td>
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                    </div>

                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">
                                <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt="..."/>
                            </div>
                            <div class="content">
                                <div class="author">
                                     <a href="#">
                                    

                                    <?php if(Auth::user()->isStaff()): ?>
                                        <?php
                                            $thisStaff = \App\Staff::where('staffno', Auth::user()->username)->get()->first();
                                        ?>
                                        <img class="avatar border-gray" src="<?php echo e(\Storage::exists($thisStaff->photo)? url('/').\Storage::url($thisStaff->photo) : url('/').\Storage::url('defaultlogo.jpg')); ?>" alt="..."/>
                                    <?php elseif(Auth::user()->isSubAdmin()): ?>
                                        <img class="avatar border-gray" src="<?php echo e(\Storage::exists(Auth::user()->photo)? url('/').\Storage::url(Auth::user()->photo) : asset('assets/img/default-avatar.png')); ?>" alt="..."/>
                                    <?php elseif(Auth::user()->isAdmin()): ?>
                                        
                                        <img class="avatar border-gray" src="<?php echo e(\Storage::exists(Auth::user()->photo)? url('/').\Storage::url(Auth::user()->photo) : asset('assets/img/default-avatar.png')); ?>" alt="..."/>
                                    <?php endif; ?>

                                      <!-- <h4 class="title">Mike Andrew<br />
                                         <small>michael24</small> -->
                                      </h4>
                                    </a>
                                </div>
                                <p class="description text-center"> <?php echo e(Auth::user()->name); ?>

                                </p>
                            </div>
                            <hr>
                            <div class="text-center">
                            
                            </div>
                        </div>
                    </div>

                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>