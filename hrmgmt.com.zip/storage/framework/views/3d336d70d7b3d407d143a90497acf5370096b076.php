<?php
    $current_page = 'promotion_process';
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">

                            <?php if(isset($displaystate)): ?>
                            <?php if($displaystate == 'edit'): ?>
                                <div class="header">
                                <h4 class="title">Update Salary Scale/Step Rules Settings</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('salary_structure_setting/'.$this_salaryscaleSPId->id )); ?>" method="POST">

                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale')); ?></label>
                                                <select type="text" placeholder="<?php echo e(__('Select Salary Scale')); ?>" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?>" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    <?php $__currentLoopData = $salaryscale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSalaryScale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($eachSalaryScale->id == old('salaryscale', $this_salaryscaleSPId->salaryscale)): ?>
                                                            <option selected="selected" value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('salaryscale')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('From Old Level/Step: ')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Old Grade Level/Step')); ?>" class="form-control <?php echo e($errors->has('oldgrade') ? ' is-invalid' : ''); ?>" name="oldgrade" value="<?php echo e(old('oldgrade', $this_salaryscaleSPId->oldgrade)); ?>" required autofocus>
                                                <?php if($errors->has('oldgrade')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('oldgrade')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('To New Level/Step: ')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('New Grade Level/Step')); ?>" class="form-control <?php echo e($errors->has('newgrade') ? ' is-invalid' : ''); ?>" name="newgrade" value="<?php echo e(old('newgrade', $this_salaryscaleSPId->newgrade )); ?>" required autofocus>
                                                <?php if($errors->has('newgrade')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('newgrade')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("salary_structure_setting/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Promotion Salary Scale/Steps</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php elseif($displaystate == 'delete'): ?>
                                <div class="header">
                                <h4 class="title text-danger">Delete Promotion Salary Structure Scale Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('salary_structure_setting/'.$this_salaryscaleSPId->id )); ?>" method="POST">

                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Promotion Salary Structure/Scale?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale')); ?></label>
                                                <select disabled="disabled" type="text" placeholder="<?php echo e(__('Select Salary Scale')); ?>" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?>" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    <?php $__currentLoopData = $salaryscale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSalaryScale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachSalaryScale->id == old('salaryscale', $this_salaryscaleSPId->salaryscale)): ?>
                                                            <option selected="selected" value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('salaryscale')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('From Old Level/Step: ')); ?></label>
                                                <input type="text" readonly="readonly" placeholder="<?php echo e(__('Old Grade Level/Step')); ?>" class="form-control <?php echo e($errors->has('oldgrade') ? ' is-invalid' : ''); ?>" name="oldgrade" value="<?php echo e(old('oldgrade', $this_salaryscaleSPId->oldgrade)); ?>" required autofocus>
                                                <?php if($errors->has('oldgrade')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('oldgrade')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('To New Level/Step: ')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('New Grade Level/Step')); ?>" class="form-control <?php echo e($errors->has('newgrade') ? ' is-invalid' : ''); ?>" name="newgrade" value="<?php echo e(old('newgrade', $this_salaryscaleSPId->newgrade)); ?>" readonly="readonly" required autofocus>
                                                <?php if($errors->has('newgrade')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('newgrade')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("salary_structure_setting/create")); ?>" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE Promotion Salary Structure/Scale</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php else: ?>
                                <div class="header">
                                    <h4 class="title">View Salary Scale/Step Rules Settings</h4>
                                    <p class="category"></p>
                                </div>
                                <div class="content">
                                    <form enctype="multipart/form-data" >

                                        <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale')); ?></label>
                                                <select disabled="disabled" type="text" placeholder="<?php echo e(__('Select Salary Scale')); ?>" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?>" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    <?php $__currentLoopData = $salaryscale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSalaryScale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachSalaryScale->id == old('salaryscale', $this_salaryscaleSPId->salaryscale)): ?>
                                                            <option selected="selected" value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('salaryscale')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('From Old Level/Step: ')); ?></label>
                                                <input type="text" readonly="readonly" placeholder="<?php echo e(__('Old Grade Level/Step')); ?>" class="form-control <?php echo e($errors->has('oldgrade') ? ' is-invalid' : ''); ?>" name="oldgrade" value="<?php echo e(old('oldgrade', $this_salaryscaleSPId->oldgrade)); ?>" required autofocus>
                                                <?php if($errors->has('oldgrade')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('oldgrade')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('To New Level/Step: ')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('New Grade Level/Step')); ?>" class="form-control <?php echo e($errors->has('newgrade') ? ' is-invalid' : ''); ?>" name="newgrade" value="<?php echo e(old('newgrade', $this_salaryscaleSPId->newgrade)); ?>" readonly="readonly" required autofocus>
                                                <?php if($errors->has('newgrade')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('newgrade')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>


                                    <a href="<?php echo e(url("salary_structure_setting/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="<?php echo e(url("salary_structure_setting/{$this_salaryscaleSPId->id}").'/edit'); ?>" class="btn btn-info btn-fill pull-right">Edit Salary Scale Promotion Rules Setting</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        <?php else: ?>

                            <div class="header">
                                <h4 class="title">Upload Staff To Be Promoted List</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <?php if(\Session::has('status')): ?>
                                  <div class="alert alert-success"><?php echo e(\Session::get('status')); ?></div>
                               <?php endif; ?>
                                <form enctype="multipart/form-data" action="<?php echo e(route('promotion_upload_process.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <input type="file" name="uploadfile" required class="form-control" >
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <input class="btn btn-fill btn-sm btn-primary" type="submit" value="Upload Promotion Staff Record(s)">
                                            </div>
                                        </div>

                                    </div>
                                        <hr/>

                                        <a class="btn btn-lg btn-success btn-fill" href="<?php echo e(url('getPdfFile')); ?>">Get Promotion PDF</a>

                                </form>
                            </div>
                            
                            <?php endif; ?>
                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">All Staff Promotion File Lists</h4>
                                <p class="category">Promotion File List Settings</p>
                                <?php if(session('salaryscale')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('salaryscale')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table id="entirestafflist" class="table table-hover table-striped">
                                    <thead>
                                        <th>S/N</th>
                                        <th>File Name</th>
                                        <th>Processing Status</th>
                                        <th>Complete Status</th>
                                        <th>Date Uploaded</th>
                                    </thead>
                                    <tbody>
                                       
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>