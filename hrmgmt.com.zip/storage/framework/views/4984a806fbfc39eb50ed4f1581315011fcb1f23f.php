
                                    <div class="row">
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <img class="img-thumbnail" src="<?php echo e(Storage::url($thisStaff->photo)); ?>" width="100px" height="100px">
                                            </div>
                                        </div>
                                    </div>


                                <form id="qualification_form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('staff_qualification')); ?>">
                                            
                                            <hr style="border: 1px solid grey;" />
                                            <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="POST" id="qualification_form_method">
                                    <input type="hidden" name="this_staff" value="<?php echo e($thisStaff->id); ?>" id="this_staff">

                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend  title="#qualification" class="title">Qualification [APPROVED]</legend>
                                            <table class="table table-responsive tab-content">
                                                <thead>
                                                    <tr>
                                                        <td>ID</td>
                                                        <td>Q-TYPE</td>
                                                        <td>QUALIFICATION-TITLE</td>
                                                        <td>QUALIFICATION-DESCRIPTION</td>
                                                        <td>REGISTERED PROFESSIONAL BODY</td>
                                                        <td>STATUS</td>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                       <td>ID</td>
                                                       <td>Q-TYPE</td>
                                                       <td>QUALIFICATION-TITLE</td>
                                                       <td>QUALIFICATION-DESCRIPTION</td>
                                                       <td>REGISTERED PROFESSIONAL BODY</td>
                                                       <td>STATUS</td>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php ($countSN = 1); ?>
                                                    <?php $__currentLoopData = $staffExtras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStaffExtra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS ): ?>
                                                        <tr>
                                                            <td><?php echo e($countSN++); ?></td>
                                                            <td><?php echo e($eachStaffExtra->qualificationtype); ?></td>
                                                            <td><?php echo e($eachStaffExtra->title); ?></td>
                                                            <td><?php echo e($eachStaffExtra->description); ?></td>
                                                            <td><?php echo e($eachStaffExtra->registeredprobody); ?></td>
                                                            <td id="staffextras_td<?php echo e($eachStaffExtra->id); ?>" >
                                                            <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-success">approved</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-info">accepted</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$PROPOSED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-warning">proposed</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$REJECTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-danger">rejected</span>
                                                            <?php endif; ?>
                                                            </td>
        
                                                        </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            <hr style="border: 1px solid grey;" />
                                        </fieldset>
                                    </div>
                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend  title="#qualification" class="title">Qualification [YET TO BE APPROVED]</legend>
                                            <table class="table table-responsive tab-content">
                                                <thead>
                                                    <tr>
                                                        <td>ID</td>
                                                        <td>Q-TYPE</td>
                                                        <td>QUALIFICATION-TITLE</td>
                                                        <td>QUALIFICATION-DESCRIPTION</td>
                                                        <td>REGISTERED PROFESSIONAL BODY</td>
                                                        <td>STATUS</td>
                                                        <td>ACTION</td>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                       <td>ID</td>
                                                       <td>Q-TYPE</td>
                                                       <td>QUALIFICATION-TITLE</td>
                                                       <td>QUALIFICATION-DESCRIPTION</td>
                                                       <td>REGISTERED PROFESSIONAL BODY</td>
                                                       <td>STATUS</td>
                                                       <td>ACTION</td>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php ($countSN = 1); ?>
                                                    <?php $__currentLoopData = $staffExtras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStaffExtra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachStaffExtra->status != \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS ): ?>
                                                        <tr>
                                                            <td><?php echo e($countSN++); ?></td>
                                                            <td><?php echo e($eachStaffExtra->qualificationtype); ?></td>
                                                            <td><?php echo e($eachStaffExtra->title); ?></td>
                                                            <td><?php echo e($eachStaffExtra->description); ?></td>
                                                            <td><?php echo e($eachStaffExtra->registeredprobody); ?></td>
                                                            <td id="staffextras_td<?php echo e($eachStaffExtra->id); ?>" >
                                                            <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-success">approved</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-info">accepted</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$PROPOSED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-warning">proposed</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$REJECTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-danger">rejected</span>
                                                            <?php endif; ?>
                                                            </td>
        
                                                            <td>
                                                                <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-success">Already Approved</span>
                                                                <?php elseif($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-info">Accepted Awaiting Approval</span>
                                                                <?php else: ?>
                                                                    <button extras_id="<?php echo e($eachStaffExtra->id); ?>" extras_act="modify" class="btn btn-xs btn-warning btn-outline-warning" type="button">MODIFY</button>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            <hr style="border: 1px solid grey;" />
                                            <div id="qualification_new_div" class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select id="qualificationtype" name="qualificationtype" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option  value="OND">OND</option>
                                                            <option  value="HND">HND</option>
                                                            <option  value="DEG">Degree</option>
                                                            <option  value="PGD">PGD</option>
                                                            <option  value="MSC">MSC</option>
                                                            <option  value="PHD">PHD</option>
                                                            <option  value="OTHERS">Others</option>
                                                        </select>
                                                        <?php if($errors->has('qualificationtype')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtype')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input id="qualificationtitle" name="qualificationtitle" type="text" class="form-control" placeholder="Qualification Title" value="<?php echo e(old('qualificationtitle')); ?>"  required="required" >
                                                        <?php if($errors->has('qualificationtitle')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtitle')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input id="qualificationdesc" name="qualificationdesc" type="text" class="form-control" placeholder="Qualification Description" value="<?php echo e(old('qualificationdesc')); ?>"  required="required" >
                                                        <?php if($errors->has('qualificationdesc')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationdesc')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea id="registeredprobody" required="required" name="registeredprobody" class="form-control" placeholder="Registered Professional Body" ><?php echo e(old('registeredprobody')); ?></textarea>
                                                        <?php if($errors->has('registeredprobody')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('registeredprobody')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>

                                                        <input type="hidden" name="qualificationcount" value="1" >
                                                    </div>
                                                </div>

                                            </div>
                                        </fieldset>
                                    </div>

                                    <button id="qualification_submit_btn" type="submit" class="btn btn-success btn-fill pull-right">Submit New Qualification</button>
                                    <div class="clearfix"></div>
                                </form>

                                <div id="conpcass" class="form-group hidden">
                                                <label id="con_label"><?php echo e(__('CONPCASS')); ?></label>
                                                <select id="con___AS_select" class="form-control <?php echo e($errors->has('con___') ? ' is-invalid' : ''); ?> " name="con___" required>

                                                    <?php for($i = 1; $i < 10; $i++): ?>
                                                        <option <?php echo e(old('con___')=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                                <?php if($errors->has('con___')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('con___')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                </div>
                                <div id="contediss" class="form-group hidden">
                                                <label id="con_label"><?php echo e(__('CONTEDISS')); ?></label>
                                                <select id="con___NA_select" class="form-control <?php echo e($errors->has('con___') ? ' is-invalid' : ''); ?> " name="con___" required>

                                                    <?php for($i = 1; $i < 16; $i++): ?>
                                                        <option <?php echo e(old('con___')=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                                <?php if($errors->has('con___')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('con___')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                 </div>

                                 <div id="qualificationformcontrols" class="qualificationformcontrols hidden">
                                    <div class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select name="qualificationtype[]" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option value="OND">OND</option>
                                                            <option value="HND">HND</option>
                                                            <option value="DEG">Degree</option>
                                                            <option value="PGD">PGD</option>
                                                            <option value="MSC">MSC</option>
                                                            <option value="PHD">PHD</option>
                                                            <option value="OTHERS">Others</option>
                                                        </select>
                                                        <?php if($errors->has('qualificationtype[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtype[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input required="required" name="qualificationtitle[]" type="text" class="form-control" placeholder="Qualification Title" value="<?php echo e(old('qualificationtitle[]')); ?>">
                                                        <?php if($errors->has('qualificationtitle[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtitle[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input required="required" name="qualificationdesc[]" type="text" class="form-control" placeholder="Qualification Description" value="<?php echo e(old('qualificationdesc[]')); ?>"  required="required" >
                                                        <?php if($errors->has('qualificationdesc[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationdesc[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea required="required" name="registeredprobody[]" class="form-control" placeholder="Registered Professional Body" ><?php echo e(old('registeredprobody[]', "NONE")); ?></textarea>
                                                        <?php if($errors->has('registeredprobody[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('registeredprobody[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>

                                                        <input type="hidden" name="qualificationcount[]" value="1" >
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <button onclick="this.parentNode.parentNode.remove()" type="button" class="btn-sm btn-danger pull-right btn removebtn">Remove</button>
                                                </div>
                                                <div class="col-md-12" style="padding-top: 1px; padding-left: 1px;">
                                                <hr style="border: 1px solid grey;">
                                                </div>
                                            </div>
                                 </div>