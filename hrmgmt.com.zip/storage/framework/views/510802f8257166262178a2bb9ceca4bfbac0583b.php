<?php
    $current_page = 'due_for_promotions';

    if(empty($displayType))
        $displayType = "all";

?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
            <?php if($displayType == "show"): ?>
                <div class="col-md-10">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">View Staff Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <?php echo $__env->make('staff.viewstaff_show', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </div>
            <?php elseif( $displayType == "edit" ): ?>
                <div class="col-md-10">
                        <div class="card">
                            <?php if($show_dc_print): ?>
                            <div class="header">
                                <h4 class="title">DECEASED STAFF</h4>
                                <p class="category"></p>
                            </div>
                            <?php else: ?>
                            <div class="header">
                                <h4 class="title">Promote Staff</h4>
                                <p class="category"></p>
                            </div>
                            <?php endif; ?>
                            <div class="content">
                                <?php echo $__env->make('staff.viewstaff_promote_edit', ['some' => 'data'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </div>
            <?php elseif( $displayType == "all" ): ?>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">List Of Staffs</h4>
                                <p class="category">This is the list of Staff</p>
                                <p>
                                    <?php if(in_array('photo',$hide_columns) || in_array('action', $hide_columns) ): ?>
                                        <button src-link-attr="<?php echo e(url('staff')); ?>/?hide1=action&hide2=photo" id="btn_select_staff" class="btn-small btn-fill btn btn-danger">Hide/Show Action & Photo Columns</button>
                                    <?php else: ?>
                                        <button src-link-attr="<?php echo e(url('staff')); ?>" id="btn_select_staff" class="btn-small btn btn-danger">Hide/Show Action & Photo Columns</button>
                                    <?php endif; ?>

                                    <?php
                                        /*  var_dump($hide_columns);
                                            var_dump(in_array('action',$hide_columns));
                                        */
                                    ?>
                                </p>
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table id="entirestafflist" class="table table-bordered table-condensed table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Staff No</th>
                                            <th>Staff Name</th>
                                            <?php if(!in_array('photo',$hide_columns)): ?>
                                                <th>Staff photo</th>
                                            <?php endif; ?>
                                            <th>Gender</th>
                                            <th>Department</th>
                                            <th>Rank</th>
                                            <th>Category</th>
                                            <th>StaffClass</th>
                                            <th>DateOfBirth</th>
                                            <th>Address</th>
                                            <th>Status</th>
                                            <?php if(!in_array('action',$hide_columns)): ?>
                                                <th>Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Staff No</th>
                                            <th>Staff Name</th>
                                            <?php if(!in_array('photo',$hide_columns)): ?>
                                                <th>Staff photo</th>
                                            <?php endif; ?>
                                            <th>Gender</th>
                                            <th>Department</th>
                                            <th>Rank</th>
                                            <th>Category</th>
                                            <th>StaffClass</th>
                                            <th>DateOfBirth</th>
                                            <th>Address</th>
                                            <th>Status</th>
                                            <?php if(!in_array('action',$hide_columns)): ?>
                                                <th>Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </tfoot>
                                    <tbody>

                                        <?php
                                            $count_c = 1;
                                        ?>

                                        <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStaff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php
                                            $department = \App\Department::find(\App\StaffDepartment::where(['staff_id'=>$eachStaff->id])->first()['dept_id'])['description'];
                                            $department = $eachStaff->getDepartment();
                                            $currentPromotion = \App\Promotions::where('status', \App\Promotions::$APPROVED_PROMOTION)
                                                ->where('promotion_indicator', \App\Promotions::$CURRENT_PROMOTION)->where('staff_id', $eachStaff->id)->get()->first();

                                            $rank = \App\Rank::find($currentPromotion->rank);
                                            $status = \App\Status::find($currentPromotion->staff_status)->status;

                                        ?>

                                        <tr>
                                            <td><?php echo e($count_c++); ?></td>
                                            <td><?php echo e($eachStaff->staffno); ?></td>
                                            <td><?php echo e("{$eachStaff->fname} {$eachStaff->lname} {$eachStaff->oname}"); ?></td>
                                            <?php if(!in_array('photo',$hide_columns)): ?>
                                                <td><img class="img" width="100px" height="100px" src="<?php echo e(\Storage::url("{$eachStaff->photo}")); ?>"  /> </td>
                                            <?php endif; ?>
                                            <td><?php echo e($eachStaff->gender); ?></td>
                                            <td><?php echo e($department); ?></td>
                                            <td><?php echo e($rank->rank); ?></td>
                                            <td><?php echo e($currentPromotion->category); ?></td>
                                            <td><?php echo e($currentPromotion->staffclass); ?></td>
                                            <td><?php echo e("{$eachStaff->dateobirth}"); ?></td>
                                            <td><?php echo e("{$eachStaff->address1}"); ?></td>
                                            <td><?php echo e("{$status}"); ?></td>

                                            <?php if(!in_array('action',$hide_columns)): ?>
                                                <td>

                                                    <form onsubmit="return (confirm('Are you Sure That You Want To Delete This Record? Please Confirm.?'))" action="<?php echo e(url("staff/". $eachStaff->id)); ?>" method="POST" >
                                                        <input type="hidden" name="_method" value="delete">
                                                        <?php echo csrf_field(); ?>
                                                        <a class="btn btn-sm btn-primary " href="<?php echo e(url('staff/'.$eachStaff->id.'')); ?>">View</a>
                                                        <a class="btn btn-sm btn-info " href="<?php echo e(url('staff/'.$eachStaff->id.'/edit')); ?>">Edit</a>
                                                        <button class="btn btn-sm btn-danger" href="<?php echo e(url('staff/'.$eachStaff->id.'/delete')); ?>">Delete</button>

                                                    </form>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
