
<?php if($show_dc_print): ?>
    <div class="col-12">
                                            <input type="hidden" name="this_staff" id="this_staff_id" value="<?php echo e($thisStaff->id); ?>">
                                            <table class="table table-bordered">
                                                <tr>
                                                    <td><div class="form-group">
                                                            <img class="img-thumbnail" src="<?php echo e(Storage::url($thisStaff->photo)); ?>" width="100px" height="100px">
                                                        </div></td>
                                                    <td><?php echo e($thisStaff->getFullName()); ?></td>
                                                    <td>Department: <?php echo e($thisStaff->getDepartment()); ?></td>
                                                    <td>State: <?php echo e($thisStaff->getDetails()['state']); ?></td>
                                                    <td>Local Govt:  <?php echo e($thisStaff->getDetails()['lga']); ?></td>
                                                    <td>Date Of Birth: <?php echo e($thisStaff->dateobirth); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Condolence Message:</td>
                                                    <td colspan="5"><textarea name="cond_comment" id="cond_comment" class="form-control"
                                                                              rows="5"><?php echo e(\App\CondolenceMessage::where('staff_id', $thisStaff->id)->first()->condolence); ?></textarea></td>

                                                </tr>
                                            </table>
                                        </div>
<?php else: ?>
                                      <?php
                                          $thisDate = $currentPromotion->presentappointdate;
                                                       $datework = \Carbon\Carbon::parse($thisDate);
                                                       $now = \Carbon\Carbon::now();

                                                       $yearDifference = $datework->diffInYears($now);
                                                       if($yearDifference > 3){
                                                           $dueDate = $datework->addYear(3);
                                                                   $dueDateString = $dueDate->toDateString();
                                                                   $dateDiff = $datework->diffForHumans(\Carbon\Carbon::now());
                                                                   $toDateArray = explode(" ", $dateDiff);
                                                                   array_pop($toDateArray);
                                                                   $dateSinceWhen = implode($toDateArray, "");
                                                               $dueDateString .= " Exactly " . $dateSinceWhen . ' Ago.' ;

                                                               echo "<div class='alert alert-info'> <h4><b>PROMOTION DUE AS AT: ".$dueDateString . "</b></h4></div>";
                                                       }

                                      ?>  
<form id="btn_basic_update_form" enctype="multipart/form-data" action="<?php echo e(url('staff/'.$thisStaff->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("PUT"); ?>

                                    <input type="hidden" name="this_staff" value="<?php echo e($thisStaff->id); ?>">

                                    <div class="row">
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <img class="img-thumbnail" src="<?php echo e(Storage::url($thisStaff->photo)); ?>" width="100px" height="100px">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Staff No (PFN)')); ?></label>
                                                <span id="staffnocheckokmessage"class="hide text-success">Staff No - Available (good!)</span>
                                                <span id="staffnocheckbadmessage" class="hide text-danger">Staff No - Unavailable (try again)</span>
                                                <input readonly="readonly" id="staffnocheck_" type="text" class="form-control control" placeholder="<?php echo e(__('staffno (PFN)')); ?>" class="form-control <?php echo e($errors->has('staffno') ? ' is-invalid' : ''); ?>" name="staffno" value="<?php echo e(old('staffno', $thisStaff->staffno)); ?>"  required="required" autofocus>

                                                <?php if($errors->has('staffno')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffno')); ?></strong>
                                                        </span>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('FirstName')); ?></label>
                                                <input  readonly="readonly" id="firstname_input" type="text" placeholder="<?php echo e(__('FirstName')); ?>" class="form-control <?php echo e($errors->has('firstname') ? ' is-invalid' : ''); ?>" name="firstname" value="<?php echo e(old('firstname', $thisStaff->fname)); ?>" required autofocus>
                                                <?php if($errors->has('firstname')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('firstname')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('LastName')); ?></label>
                                                <input  readonly="readonly" id="lastname_input" type="text" placeholder="<?php echo e(__('LastName')); ?>" class="form-control <?php echo e($errors->has('lastname') ? ' is-invalid' : ''); ?>" name="lastname" value="<?php echo e(old('lastname', $thisStaff->lname)); ?>" required autofocus>
                                                <?php if($errors->has('lastname')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('lastname')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('OtherName')); ?></label>
                                                <input  readonly="readonly" id="othername_input" type="text" placeholder="<?php echo e(__('OtherName')); ?>" class="form-control <?php echo e($errors->has('othername') ? ' is-invalid' : ''); ?>" name="othername" value="<?php echo e(old('othername', $thisStaff->oname)); ?>"  autofocus>
                                                <?php if($errors->has('othername')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('othername')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Gender')); ?></label>
                                                <select id="gender_input" name="gender" class="form-control" required="required">
                                                    <option <?php echo e(old('gender', $thisStaff->gender) == "M" ? 'selected="selected"' : ''); ?> value="M"><?php echo e(__('Male')); ?></option>
                                                    <option <?php echo e(old('gender', $thisStaff->gender) == "F" ? 'selected="selected"' : ''); ?>  value="F"><?php echo e(__('Female')); ?></option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('Marital Status')); ?></label>
                                                <select id="maritalstatus" class="form-control <?php echo e($errors->has('maritalstatus') ? ' is-invalid' : ''); ?> " name="maritalstatus" required>

                                                    <option <?php echo e(old('maritalstatus', $thisStaff->maritalstatus)=="M"? 'selected="selected"' : ''); ?> value="M" >Married</option>
                                                    <option <?php echo e(old('maritalstatus', $thisStaff->maritalstatus) =="S"? 'selected="selected"' : ''); ?> value="S" >Single</option>

                                                </select>
                                                <?php if($errors->has('maritalstatus')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('maritalstatus')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('PhoneNo')); ?></label>
                                                <input id="phoneno_input" type="text" placeholder="<?php echo e(__('PhoneNo')); ?>" class="form-control <?php echo e($errors->has('phoneno') ? ' is-invalid' : ''); ?>" name="phoneno" value="<?php echo e(old('phoneno', $thisStaff->phoneno)); ?>" required  autofocus>
                                                <?php if($errors->has('phoneno')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('phoneno')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2">
                                            <div class="form-group">
                                                <label><?php echo e(__('Current Appointment Date')); ?></label>
                                                <input readonly="readonly" id="old_presentappointdate_input" type="date" class="form-control" placeholder="<?php echo e(__('Present Appointment Date')); ?>" class="form-control <?php echo e($errors->has('presentappointdate') ? ' is-invalid' : ''); ?>" name="presentappointdate" value="<?php echo e(old('presentappointdate', $currentPromotion->presentappointdate)); ?>" required="required"  autofocus>

                                                <?php if($errors->has('presentappointdate')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('presentappointdate')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                </form>

                                <hr/>
                                <form id="staff_level_form" action="<?php echo e(url('promote')); ?>" method="POST">

                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="this_staff" value="<?php echo e($thisStaff->id); ?>">

                                    <div class="row">

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('New Appointment Date')); ?></label>
                                                <input id="presentappointdate_input" type="date" class="form-control" placeholder="<?php echo e(__('Present Appointment Date')); ?>" class="form-control <?php echo e($errors->has('presentappointdate') ? ' is-invalid' : ''); ?>" name="presentappointdate" value="<?php echo e(old('presentappointdate', $currentPromotion->presentappointdate)); ?>" required="required"  autofocus>

                                                <?php if($errors->has('presentappointdate')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('presentappointdate')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Appointment Type')); ?></label>
                                                <select id="appointmenttype_input" class="form-control <?php echo e($errors->has('appointmenttype') ? ' is-invalid' : ''); ?> " name="appointmenttype" required>
                                                    <?php $__currentLoopData = $appointmenttype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anAppointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(old('appointmenttype', $currentPromotion->appointmenttype)==$anAppointment->id? 'selected="selected"' : ''); ?>  value="<?php echo e($anAppointment->id); ?>"><?php echo e($anAppointment->appointmenttype); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php if($errors->has('appointmenttype')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('appointmenttype')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>


                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Position (If Any)')); ?></label>
                                                    <select id="position_input" class="form-control <?php echo e($errors->has('position') ? ' is-invalid' : ''); ?> " name="position" required>

                                                            <option value="0">None</option>
                                                        <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachPosition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option <?php echo e(old('position', $currentPromotion->position)==$eachPosition->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachPosition->id); ?>"><?php echo e($eachPosition->position); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>

                                                <?php if($errors->has('position')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('position')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                         <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Staff Class')); ?></label>
                                                <select id="staffclass" class="form-control <?php echo e($errors->has('staffclass') ? ' is-invalid' : ''); ?> " name="staffclass" required>
                                                    <option selected="selected" >Select Staff Class</option>
                                                    <option <?php echo e(old('staffclass', $currentPromotion->staffclass) == "AS"? 'selected="selected"' : ''); ?> value="AS">Academic Staff</option>
                                                    <option  <?php echo e(old('staffclass', $currentPromotion->staffclass) == "NA"? 'selected="selected"' : ''); ?>  value="NA">Non-Academic Staff</option>
                                                </select>

                                                <?php if($errors->has('staffclass')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffclass')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">

                                        <?php if($currentPromotion->staffclass == "AS"): ?>
                                            <div id="con___parent" class="col-md-1 hide">
                                            <div id="conpcass" class="form-group">
                                                <label id="con_label"><?php echo e(__('CONPCASS')); ?></label>
                                                <select id="con___AS_select" class="form-control <?php echo e($errors->has('con___') ? ' is-invalid' : ''); ?> " name="con___" required>

                                                    <?php for($i = 1; $i < 10; $i++): ?>
                                                        <option <?php echo e(old('con___', $currentPromotion->con___)=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                                <?php if($errors->has('con___')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('con___')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <?php elseif($currentPromotion->staffclass == "NA"): ?>
                                            <div id="con___parent" class="col-md-1 hide">
                                            <div id="contediss" class="form-group">
                                                <label id="con_label"><?php echo e(__('CONTEDISS')); ?></label>
                                                <select id="con___NA_select" class="form-control <?php echo e($errors->has('con___') ? ' is-invalid' : ''); ?> " name="con___" required>

                                                    <?php for($i = 1; $i < 16; $i++): ?>
                                                        <option <?php echo e(old('con___', $currentPromotion->con___)=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                                <?php if($errors->has('con___')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('con___')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                            </div>
                                        <?php endif; ?>

                                        <div id="salaryscale___parent" class="col-sm-1 col-md-2">
                                            <div id="salaryscale" class="form-group">
                                                <label id="con_label"><?php echo e(__('Salary Scale')); ?></label>
                                                <select id="salaryscale_select" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?> " name="salaryscale" required>
                                                    <option value="">Select Salary Scale...</option>
                                                    <?php $__currentLoopData = $salaryscale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSalaryScale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(old('salaryscale')==$eachSalaryScale->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachSalaryScale->id); ?>" ><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                                <?php if($errors->has('salaryscale')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div id="salaryscalevalue___parent" class="col-sm-1 col-md-1">
                                            <div id="salaryscalevalue" class="form-group">
                                                <label id="con_label"><?php echo e(__('S-Scale Value')); ?></label>
                                                <select id="salaryscalevalue_select" class="form-control <?php echo e($errors->has('salaryscalevalue') ? ' is-invalid' : ''); ?> " name="salaryscalevalue" required>
                                                    <option value="">Select Salary Scale Value ...</option>

                                                </select>
                                                <?php if($errors->has('salaryscalevalue')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscalevalue')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Category')); ?></label>
                                                <select id="category_input" class="form-control <?php echo e($errors->has('category') ? ' is-invalid' : ''); ?> " name="category" required>
                                                    <option <?php echo e(old('category', $currentPromotion->category) =="JS"? 'selected="selected"' : ''); ?> value="JS" >Junior Staff</option>
                                                    <option <?php echo e(old('category', $currentPromotion->category)=="SS"? 'selected="selected"' : ''); ?> value="SS" >Senior Staff</option>
                                                </select>

                                                <?php if($errors->has('category')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('category')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label><?php echo e(__('Rank')); ?></label>
                                                <select id="rank" class="form-control <?php echo e($errors->has('rank') ? ' is-invalid' : ''); ?> " name="rank" required>
                                                        <option value="">Select Staff Rank</option>
                                                         <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option <?php echo e(old('rank', $currentPromotion->rank)==$eachRank->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachRank->id); ?>"><?php echo e($eachRank->rank); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                                <?php if($errors->has('rank')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Step')); ?></label>

                                                    <select id="step_select" class="form-control <?php echo e($errors->has('step') ? ' is-invalid' : ''); ?> " name="step" required>

                                                    <?php for($i = 1; $i <= 50; $i++): ?>
                                                        <option <?php echo e(old('step', $currentPromotion->step)=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>

                                                <?php if($errors->has('step')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('step')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label>Promotion Description/Comment</label>
                                                <textarea name="description" class="form-control" placeholder="Promotion Description/Comment" required="required" ><?php echo e(old('description', $currentPromotion->description)); ?></textarea>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <button id="staff_level_update_btn" type="submit" disabled="disabled" class="btn btn-success btn-fill pull-right">Promote Staff</button>
                                    <div class="clearfix"></div>
                                </form>

                                <hr>
                                <form id="staff_status_form" action="<?php echo e(url('staff_status')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="this_staff" value="<?php echo e($thisStaff->id); ?>">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Status')); ?></label>
                                                <select id="staff_status" class="form-control <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?> " name="status" required>
                                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(old('status', $thisStaff->status)==$eachStatus->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachStatus->id); ?>"><?php echo e($eachStatus->status); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div><br/>
                                        <button disabled="disabled" title="Please Click To Effect Staff Status Change" id="btnstaff_status" type="submit" class="btn btn-success btn-fill pull-left">Change Staff Status</button>
                                    <div class="clearfix"></div>


                                    </div>
                                </form>
                                <?php if($thisStaff->status == \App\Status::where('status', 'DECEASED')->first()->id): ?>
                                <form id="staff_status_form" action="<?php echo e(url('staff_status')); ?>" method="GET">
                                        <div class="col-12">
                                            <input type="hidden" name="this_staff" id="this_staff_id" value="<?php echo e($thisStaff->id); ?>">
                                            <table class="table table-bordered">
                                                <tr>
                                                    <td><div class="form-group">
                                                            <img class="img-thumbnail" src="<?php echo e(Storage::url($thisStaff->photo)); ?>" width="100px" height="100px">
                                                        </div></td>
                                                    <td><?php echo e($thisStaff->getFullName()); ?></td>
                                                    <td>Department: <?php echo e($thisStaff->getDepartment()); ?></td>
                                                    <td>State: <?php echo e($thisStaff->getDetails()['state']); ?></td>
                                                    <td>Local Govt:  <?php echo e($thisStaff->getDetails()['lga']); ?></td>
                                                    <td>Date Of Birth: <?php echo e($thisStaff->dateobirth); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Condolence Message:</td>
                                                    <td colspan="4"><textarea name="cond_comment" id="cond_comment" class="form-control"
                                                                              rows="5"><?php echo e(\App\CondolenceMessage::where('staff_id', $thisStaff->id)->first()->condolence); ?></textarea></td>
                                                    <td><a onclick="preventDefault()" class="btn btn-success btn-fill" id="btn_comment_update">Save</a>&nbsp;&nbsp;<a href="<?php echo e(url('/staff/'.$thisStaff->id.'/edit?act=dcprint')); ?>" class="btn btn-primary btn-fill" id="btn_comment_update">SavePrint</a></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </form>
                                    <?php endif; ?>


                                <form id="qualification_form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('staff_qualification')); ?>">

                                            <hr style="border: 1px solid grey;" />
                                            <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="POST" id="qualification_form_method">
                                    <input type="hidden" name="this_staff" value="<?php echo e($thisStaff->id); ?>" id="this_staff">

                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend  title="#qualification" class="title">PROMOTION HISTORY</legend>
                                            <table class="table table-responsive tab-content">
                                                <thead>
                                                    <tr>
                                                        <td>ID</td>
                                                        <td>PROMOTION EFFECTIVE DATE</td>
                                                        <td>RANK</td>
                                                        <td>STEP</td>
                                                        <td>SALARY SCALE</td>
                                                        <td>SALARY SCALE VALUE</td>
                                                        <td>CATEGORY</td>
                                                        <td>STATUS</td>
                                                        <td>PROMOTION-INDICATOR</td>
                                                        <td>Created_At</td>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                       <td>ID</td>
                                                        <td>PROMOTION DATE</td>
                                                        <td>RANK</td>
                                                        <td>STEP</td>
                                                        <td>SALARY SCALE</td>
                                                        <td>SALARY SCALE VALUE</td>
                                                        <td>CATEGORY</td>
                                                        <td>STATUS</td>
                                                        <td>PROMOTION-INDICATOR</td>
                                                        <td>Created_At</td>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php ($countSN = 1); ?>
                                                    <?php $__currentLoopData = $staffPromotionHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStaffPromotionHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        
                                                        <tr>
                                                            <td><?php echo e($countSN++); ?></td>
                                                            <td><?php echo e($eachStaffPromotionHistory->presentappointdate); ?></td>
                                                            <td><?php echo e($eachStaffPromotionHistory->getRank()); ?></td>
                                                            <td><?php echo e($eachStaffPromotionHistory->step); ?></td>
                                                            <td><?php echo e($eachStaffPromotionHistory->con___); ?></td>
                                                            <td><?php echo e($eachStaffPromotionHistory->con___); ?></td>
                                                            <td><?php echo e($eachStaffPromotionHistory->category); ?></td>
                                                            <td><?php echo $eachStaffPromotionHistory->status == App\Promotions::$APPROVED_PROMOTION? '<span class="label label-success">APPROVED</span>' : '<span class="label label-warning">DISAPPROVED</span>'; ?></td>
                                                            <td><?php echo $eachStaffPromotionHistory->promotion_indicator == \App\Promotions::$CURRENT_PROMOTION ? '<span class="label label-success">CURRENT</span>' : '<span class="label label-info">PAST</span>'; ?></td>
                                                            <td><?php echo e(\Carbon\Carbon::parse($eachStaffPromotionHistory->created_at)->toDateTimeString()); ?></td>

                                                        </tr>
                                                        
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            <hr style="border: 1px solid grey;" />
                                        </fieldset>
                                    </div>
                              
                                    
                                    <div class="clearfix"></div>
                                </form>

                             
<?php endif; ?>
