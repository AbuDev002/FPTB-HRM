<!DOCTYPE html>
<html>
<head>
    <title>Hi</title>
</head>
<body>
    
<?php
    $count = count($staffs);
    $count_st = 0;
?>
<?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStaff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php

    $salaryscale = $eachStaff->getDetails()['salary_scale'];
    $salaryscalevalue = $eachStaff->getDetails()['salary_scale_value'];
    $step = $eachStaff->getDetails()['step'];
    $promotiondate = $eachStaff->getPromotion()->promotion_date;

    $count_st++;

?>
    
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

    <table>
        <tbody style="width:100%; border: 0px" >
            <tr>
                
                <td>FPTB/CA/<?php echo e($eachStaff->staffno); ?></td>
                <td></td>
                <td><?php echo e($todays_date); ?></td>
            </tr>
            <tr>
                <td><br>
                    <p>
                        <?php echo e($eachStaff->getFullName()); ?> <br>
                        Ufs: HOD, <?php echo e($eachStaff->getDepartmentUnit()); ?>, <br>
                        Federal Polytechnic,<br>
                        Bauchi. <br><br>
                    </p>
                </td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>
                    <b><u>PROMOTION</u></b>
                </td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="3">
                    <p align="justify">
                        I am happy to inform you that the Governing Council at its <?php echo e($council_count); ?> Regular Meeting has approved the recommendations of the Expanded Management Committee for your promotion in recognition of your hard work and dedication to duties. <br><br>

                        It is my pleasure and priviledge  inform you that you have been promoted to the rank of <b><u><?php echo e($eachStaff->getDetails()['rank']); ?></u></b> on <?php echo e($salaryscale); ?> <b><u><?php echo e($salaryscalevalue); ?></u></b> step <b><u><?php echo e($step); ?></u></b> with effect from <?php echo e($promotiondate); ?>. Your next increment will be with effect from <?php echo e($promotiondate); ?>. <br><br>

                        It is hoped that you will justify our promotion by increased productivity and total devotion to duties. <br>
                        Accept my congratulations. <br> <br><br>


                        <br>
                        
                        <?php
                            $full_path = Storage::disk('public')->path('_______signsample.png');
                        ?>

                        <img src="<?php echo e($full_path); ?>" width="100px" height="100px" /> <br>
                        <b><?php echo e($registrar); ?></b><br>
                        <b><tt>REGISTRAR</tt></b>
                        <br>
                        <br>
                        <b>CC: Bursar</b><br>
                        <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Chief Internal Auditor</b>
                    </p>
                </td>
                
            </tr>
        </tbody>
    </table>

    <?php if($count_st < $count): ?>
        <p style="page-break-before: always;"></p>
    <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</body>
</html>