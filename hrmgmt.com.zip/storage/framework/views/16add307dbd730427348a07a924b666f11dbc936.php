
<form enctype="multipart/form-data" action="<?php echo e(url('staff/'.$thisStaff->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <img class="img-thumbnail" src="<?php echo e(Storage::url($thisStaff->photo)); ?>" width="100px" height="100px">
                                            </div>
                                        </div>
                                    </div>
                                    <table class="table table-condensed table-responsive">
                                        <tr>
                                            <td colspan="5">
                                                <label><?php echo e(__('Staff No')); ?></label>
                                                <p><?php echo e($thisStaff->staffno); ?><p/>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td>
                                                <label><?php echo e(__('First Name')); ?></label>
                                                <p><?php echo e($thisStaff->fname); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('Last Name')); ?></label>
                                                <p><?php echo e($thisStaff->lname); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('Other Name')); ?></label>
                                                <p><?php echo e($thisStaff->oname); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('Gender')); ?></label>
                                                <p><?php echo e($thisStaff->gender == "M"? "Male" : "Female"); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('Date Of Birth')); ?></label>
                                                <p><?php echo e($thisStaff->dateobirth); ?><p/>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label><?php echo e(__('Marital Status')); ?></label>
                                                <p><?php echo e($thisStaff->maritalstatus == "M" ? "Married" : "Single"); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('Phone No')); ?></label>
                                                <p><?php echo e($thisStaff->phoneno); ?><p/>
                                            </td>
                                            <td >
                                                <label><?php echo e(__('Email Address')); ?></label>
                                                <p><?php echo e($thisStaff->email); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('STATE')); ?></label>
                                                <p>
                                                    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachState): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($thisStaff->state_id ==$eachState->id): ?>
                                                            <?php echo e($eachState->state); ?>

                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('LGA')); ?></label>
                                                <p>
                                                    <?php $__currentLoopData = $lga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachLga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($thisStaff->lga_id == $eachLga->id): ?>
                                                            <?php echo e($eachLga->lga); ?>

                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p/>
                                            </td>
                                        </tr>
                                        <tr>

                                            <td colspan="5">
                                                <label><?php echo e(__('Address')); ?></label>
                                                <p><?php echo e($thisStaff->address1); ?><p/>
                                            </td>
                                            
                                            
                                        </tr>
                                        <tr>
                                            <td colspan="5" style="text-align: center;"><strong>Next Of Kin Information</strong></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label><?php echo e(__('NEXT OF KIN FIRST NAME')); ?></label>
                                                <p><?php echo e($thisStaff->nok_fname); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('NEXT OF KIN LAST NAME')); ?></label>
                                                <p><?php echo e($thisStaff->nok_lname); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('NEXT OF KIN OTHER NAME')); ?></label>
                                                <p><?php echo e($thisStaff->nok_oname); ?><p/>
                                            </td>
                                            <td>
                                               <label><?php echo e(__('NEXT OF KIN ADDRESS')); ?></label>
                                                <p><?php echo e($thisStaff->nok_address); ?><p/>
                                            </td>
                                            <td>
                                               <label><?php echo e(__('NEXT OF KIN Relationship')); ?></label>
                                                <p><?php echo e($thisStaff->nok_relationship); ?><p/>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="5">
                                                <label><?php echo e(__('NEXT OF KIN PHONE NO')); ?></label>
                                                <p><?php echo e($thisStaff->nok_phoneno); ?><p/>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <label><?php echo e(__('CHILD\'S NAME (IF ANY)')); ?></label>
                                                <p><?php echo e($thisStaff->child1_name); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('CHILD\' AGE')); ?></label>
                                                <p><?php echo e($thisStaff->child1_age); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('CHILD\'S NAME (IF ANY)')); ?></label>
                                                <p><?php echo e($thisStaff->child2_name); ?><p/>
                                            </td>
                                            <td colspan="2">
                                                <label><?php echo e(__('CHILD\' AGE')); ?></label>
                                                <p><?php echo e($thisStaff->child2_age); ?><p/>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label><?php echo e(__('CHILD\'S NAME (IF ANY)')); ?></label>
                                                <p><?php echo e($thisStaff->child3_name); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('CHILD\' AGE')); ?></label>
                                                <p><?php echo e($thisStaff->child3_age); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('CHILD\'S NAME (IF ANY)')); ?></label>
                                                <p><?php echo e($thisStaff->child4_name); ?><p/>
                                            </td>
                                            <td>
                                                <label><?php echo e(__('CHILD\' AGE')); ?></label>
                                                <p><?php echo e($thisStaff->child4_age); ?><p/>
                                            </td>

                                        </tr>

                                    </table>

                                    <hr id="childsection2_hr" class="">

                                    <table class="table table-condensed">
                                        <tr>

                                            <td colspan="2">
                                                <label><?php echo e(__('SCHOOL')); ?></label>
                                                <p>
                                                    <?php $__currentLoopData = $school; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSchool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($staffdepartment->school == $eachSchool->id): ?>
                                                            <?php echo e($eachSchool->school); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p/>
                                            </td>
                                            <td colspan="2">
                                                <label><?php echo e(__('DEPARTMENT')); ?></label>
                                                <p>
                                                     <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($staffdepartment->dept_id == $eachDepartment->id): ?>
                                                            <?php echo e($eachDepartment->department); ?> <?php echo e($eachDepartment->description); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p/>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td >
                                                <label><?php echo e(__('FIRST APPOINTMENT DATE')); ?></label>
                                                <p>
                                                    <?php echo e($thisStaff->firstappointdate); ?>

                                                <p/>
                                            </td>
                                            <td >
                                                <label><?php echo e(__('APPOINTMENT TYPE')); ?></label>
                                                <p>
                                                     <?php $__currentLoopData = $appointmenttype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anAppointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($currentPromotion->appointmenttype == $anAppointment->id): ?>
                                                            <?php echo e($anAppointment->appointmenttype); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p/>
                                            </td>
                                            <td >

                                                <label><?php echo e(__('POSITION (IF ANY)')); ?></label>
                                                <p>
                                                     <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachPosition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($currentPromotion->position == $eachPosition->id): ?>
                                                            <?php echo e($eachPosition->position); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p/>
                                                <label><?php echo e(__('ADDED RESPONSIBILITIES (IF ANY)')); ?></label>
                                                <p>
                                                     <?php $__currentLoopData = $thisStaff->getDetails()['addedresponsibilities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($eachRes->position . ', '); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p/>
                                            </td>
                                            <td colspan="2" >
                                                <label><?php echo e(__('STEP')); ?></label>
                                                <p>
                                                    <?php echo e($currentPromotion->step); ?>

                                                <p/>
                                            </td>

                                        </tr>

                                        <tr>
                                            <td >
                                                <label><?php echo e(__('PRESENT APPOINTMENT DATE')); ?></label>
                                                <p>
                                                    <?php echo e($currentPromotion->presentappointdate); ?>

                                                <p/>
                                            </td>
                                            <td >
                                                <label><?php echo e(__('STAFF CLASS')); ?></label>
                                                <p>
                                                     <?php echo e($currentPromotion->staffclass == "AS" ? "Academic Staff" : "Non-Academic Staff"); ?>

                                                <p/>
                                            </td>
                                            <td >
                                                <label><?php echo e(__('RANK')); ?></label>
                                                <p>
                                                     <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($currentPromotion->rank == $eachRank->id ? $eachRank->rank : ''); ?>

                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p/>
                                            </td>
                                            <td >
                                                <label>SALARY SCALE</label>
                                                <p>
                                                    <?php echo e($currentPromotion->getSalaryScale()); ?>

                                                <p/>
                                            </td>
                                            <td >
                                                <label>SALARY SCALE VALUE</label>
                                                <p>
                                                    <?php echo e($currentPromotion->salary_scale_value); ?>

                                                <p/>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td >
                                                <label><?php echo e(__('CATEGORY')); ?></label>
                                                <p>
                                                    <?php echo e($currentPromotion->category =="JS"? "Junior Staff" : "Senior Staff"); ?>

                                                <p/>
                                            </td>
                                            <td >
                                                <label><?php echo e(__('GPZONE')); ?></label>
                                                <p>
                                                     <?php $__currentLoopData = $gpzone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachGPZone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($thisStaff->gpzone==$eachGPZone->id): ?>
                                                            <?php echo e($eachGPZone->gpzone); ?> [<?php echo e($eachGPZone->description); ?>]
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p/>
                                            </td>
                                            <td >
                                                <label><?php echo e(__('STATUS')); ?></label>
                                                <p>
                                                     <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($thisStaff->status==$eachStatus->id): ?>
                                                            <?php echo e($eachStatus->status); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p/>
                                            </td>
                                            <td colspan="2" >
                                                <label><?php echo e(__('LAST PROMOTED DATE')); ?></label>
                                                <p>
                                                    <?php echo e($thisStaff->getDetails()['current_promotion_date']); ?>

                                                     
                                                        
                                                            
                                                        
                                                    
                                                <p/>
                                            </td>

                                        </tr>

                                    </table>

                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend  title="#qualification" class="title">Qualification [APPROVED]</legend>
                                            <table class="table table-responsive">
                                                <thead>
                                                    <tr>
                                                        <td>ID</td>
                                                        <td>Q-TYPE</td>
                                                        <td>QUALIFICATION-TITLE</td>
                                                        <td>QUALIFICATION-DESCRIPTION</td>
                                                        <td>REGISTERED PROFESSIONAL BODY</td>
                                                        <td>STATUS</td>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                       <td>ID</td>
                                                       <td>Q-TYPE</td>
                                                       <td>QUALIFICATION-TITLE</td>
                                                       <td>QUALIFICATION-DESCRIPTION</td>
                                                       <td>REGISTERED PROFESSIONAL BODY</td>
                                                       <td>STATUS</td>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                        $countSN = 1;
                                                    ?>

                                                    <?php $__currentLoopData = $staffExtras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStaffExtra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS ): ?>
                                                        <tr>
                                                            <td><?php echo e($countSN++); ?></td>
                                                            <td><?php echo e($eachStaffExtra->qualificationtype); ?></td>
                                                            <td><?php echo e($eachStaffExtra->title); ?></td>
                                                            <td><?php echo e($eachStaffExtra->description); ?></td>
                                                            <td><?php echo e($eachStaffExtra->registeredprobody); ?></td>
                                                            <td id="staffextras_td<?php echo e($eachStaffExtra->id); ?>" >
                                                            <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-success">approved</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-info">accepted</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$PROPOSED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-warning">proposed</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$REJECTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-danger">rejected</span>
                                                            <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            <hr style="border: 1px solid grey;" />
                                        </fieldset>
                                    </div>
                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend  title="#qualification" class="title">Qualification [YET TO BE APPROVED]</legend>
                                            <table class="table table-responsive">
                                                <thead>
                                                    <tr>
                                                        <td>ID</td>
                                                        <td>Q-TYPE</td>
                                                        <td>QUALIFICATION-TITLE</td>
                                                        <td>QUALIFICATION-DESCRIPTION</td>
                                                        <td>REGISTERED PROFESSIONAL BODY</td>
                                                        <td>STATUS</td>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                       <td>ID</td>
                                                       <td>Q-TYPE</td>
                                                       <td>QUALIFICATION-TITLE</td>
                                                       <td>QUALIFICATION-DESCRIPTION</td>
                                                       <td>REGISTERED PROFESSIONAL BODY</td>
                                                       <td>STATUS</td>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php
                                                        $countSN = 1;
                                                    ?>

                                                    <?php $__currentLoopData = $staffExtras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStaffExtra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachStaffExtra->status != \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS ): ?>
                                                        <tr>
                                                            <td><?php echo e($countSN++); ?></td>
                                                            <td><?php echo e($eachStaffExtra->qualificationtype); ?></td>
                                                            <td><?php echo e($eachStaffExtra->title); ?></td>
                                                            <td><?php echo e($eachStaffExtra->description); ?></td>
                                                            <td><?php echo e($eachStaffExtra->registeredprobody); ?></td>
                                                            <td id="staffextras_td<?php echo e($eachStaffExtra->id); ?>" >
                                                            <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-success">approved</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-info">accepted</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$PROPOSED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-warning">proposed</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$REJECTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-danger">rejected</span>
                                                            <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            <hr style="border: 1px solid grey;" />
                                        </fieldset>
                                    </div>


                                    
                                    <button onclick="window.print()" type="button" class="btn btn-info btn-fill pull-left">Print</button>
                                    <a id="btnsubmit" href="<?php echo e(url('staff/'.$thisStaff->id.'/edit')); ?>" class="btn btn-info btn-fill pull-right">Edit Staff</a>
                                    <div class="clearfix"></div>
                                    <div class="clearfix"></div>
                                </form>
                                <br>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="panel-group" id="accordion">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        <a title="Click Or Toggle Collapse" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"> <strong>Promotion History</strong></a>
                                                    </h4>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse in">
                                                    <div class="panel-body">
                                                        <table class="table table-bordered table-hover table-responsive table-striped table-condensed">
                                                            <thead>
                                                                <tr>
                                                                    <td>S/N</td>
                                                                    <td>Position</td>
                                                                    <td>Staff-Class</td>
                                                                    <td>Rank</td>
                                                                    <td>Category</td>
                                                                    <td>SalaryScale</td>
                                                                    <td>SalaryScale Value</td>
                                                                    <td>Step</td>
                                                                    <td>Present Appointment Date</td>
                                                                    <td>Status</td>
                                                                    <td>Appointment-Type</td>
                                                                    <td>Staff-Status</td>
                                                                    <td>Promotion-Indicator</td>
                                                                    <td>Promotion-Date</td>

                                                                </tr>
                                                            </thead>
                                                            <tfoot>
                                                                <tr>
                                                                    <td>S/N</td>
                                                                    <td>Position</td>
                                                                    <td>Staff-Class</td>
                                                                    <td>Rank</td>
                                                                    <td>Category</td>
                                                                    <td>SalaryScale</td>
                                                                    <td>SalaryScale Value</td>
                                                                    <td>Step</td>
                                                                    <td>Present Appointment Date</td>
                                                                    <td>Status</td>
                                                                    <td>Appointment-Type</td>
                                                                    <td>Staff-Status</td>
                                                                    <td>Promotion-Indicator</td>
                                                                    <td>Promotion-Date</td>

                                                                </tr>
                                                            </tfoot>
                                                            <tbody>
                                                                <?php
                                                                    $count_sn_ = 1;
                                                                ?>

                                                                <?php $__currentLoopData = $thisStaff->getAllPromotionHistory(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachPromotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($count_sn_++); ?></td>
                                                                        <td><?php echo e($eachPromotion->getPosition()); ?></td>
                                                                        <td><?php echo e($eachPromotion->getStaffClass()); ?></td>
                                                                        <td><?php echo e($eachPromotion->getRank()); ?></td>
                                                                        <td><?php echo e($eachPromotion->category); ?></td>
                                                                        <td><?php echo e($eachPromotion->getSalaryScale()); ?></td>
                                                                        <td><?php echo e($eachPromotion->salary_scale_value); ?></td>
                                                                        <td><?php echo e($eachPromotion->step); ?></td>
                                                                        <td><?php echo e($eachPromotion->presentappointdate); ?></td>
                                                                        <td><?php echo e($eachPromotion->status == \App\Promotions::$APPROVED_PROMOTION? "APPROVED" : "DISAPPROVED"); ?></td>
                                                                        <td><?php echo e($eachPromotion->getAppointmentType()); ?></td>
                                                                        <td><?php echo e($eachPromotion->getStaffStatus()); ?></td>
                                                                        <td><?php echo e($eachPromotion->promotion_indicator == \App\Promotions::$CURRENT_PROMOTION? "CURRENT" : "PAST"); ?></td>
                                                                        <td><?php echo e($eachPromotion->promotion_date); ?></td>

                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        <a title="Click Or Toggle Collapse" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"> <strong>Staff Department History</strong></a>
                                                    </h4>
                                                </div>
                                                <div id="collapseTwo" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <table class="table table-bordered table-hover table-responsive table-striped table-condensed">
                                                            <thead>
                                                                <tr>
                                                                    <td>S/N</td>
                                                                    <td>Department</td>
                                                                    <td>School</td>
                                                                    <td>Status</td>
                                                                    <td>Date</td>
                                                                </tr>
                                                            </thead>
                                                            <tfoot>
                                                                <tr>
                                                                    <td>S/N</td>
                                                                    <td>Department</td>
                                                                    <td>School</td>
                                                                    <td>Status</td>
                                                                    <td>Date</td>
                                                                </tr>
                                                            </tfoot>
                                                            <tbody>
                                                                <?php
                                                                    $count_sn_ = 1;
                                                                ?>

                                                                <?php $__currentLoopData = $thisStaff->getDepartmentHistory(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDepartmentH): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($count_sn_++); ?></td>
                                                                        <td><?php echo e($eachDepartmentH->getDepartment()); ?></td>
                                                                        <td><?php echo e($eachDepartmentH->getSchool()); ?></td>
                                                                        <td><?php echo e($eachDepartmentH->status == \App\StaffDepartment::$STATUS_CURRENT ? "CURRENT" : "PAST"); ?></td>
                                                                        <td><?php echo e($eachDepartmentH->created_at); ?></td>

                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div id="conpcass" class="form-group hidden">
                                                <label id="con_label"><?php echo e(__('CONPCASS')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('con___') ? ' is-invalid' : ''); ?> " name="con___" required>

                                                    <?php for($i = 1; $i < 10; $i++): ?>
                                                        <option <?php echo e(old('con___')=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                                <?php if($errors->has('con___')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('con___')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                </div>
                                <div id="contediss" class="form-group hidden">
                                                <label id="con_label"><?php echo e(__('CONTEDISS')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('con___') ? ' is-invalid' : ''); ?> " name="con___" required>

                                                    <?php for($i = 1; $i < 16; $i++): ?>
                                                        <option <?php echo e(old('con___')=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                                <?php if($errors->has('con___')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('con___')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                 </div>

                                 <div id="qualificationformcontrols" class="qualificationformcontrols hidden">
                                    <div class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select name="qualificationtype[]" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option value="OND">OND</option>
                                                            <option value="HND">HND</option>
                                                            <option value="DEG">Degree</option>
                                                            <option value="PGD">PGD</option>
                                                            <option value="MSC">MSC</option>
                                                            <option value="PHD">PHD</option>
                                                            <option value="OTHERS">Others</option>
                                                        </select>
                                                        <?php if($errors->has('qualificationtype[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtype[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input required="required" name="qualificationtitle[]" type="text" class="form-control" placeholder="Qualification Title" value="<?php echo e(old('qualificationtitle[]')); ?>">
                                                        <?php if($errors->has('qualificationtitle[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtitle[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input required="required" name="qualificationdesc[]" type="text" class="form-control" placeholder="Qualification Description" value="<?php echo e(old('qualificationdesc[]')); ?>"  required="required" >
                                                        <?php if($errors->has('qualificationdesc[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationdesc[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea required="required" name="registeredprobody[]" class="form-control" placeholder="Registered Professional Body" ><?php echo e(old('registeredprobody[]', "NONE")); ?></textarea>
                                                        <?php if($errors->has('registeredprobody[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('registeredprobody[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>

                                                        <input type="hidden" name="qualificationcount[]" value="1" >
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <button onclick="this.parentNode.parentNode.remove()" type="button" class="btn-sm btn-danger pull-right btn removebtn">Remove</button>
                                                </div>
                                                <div class="col-md-12" style="padding-top: 1px; padding-left: 1px;">
                                                <hr style="border: 1px solid grey;">
                                                </div>
                                            </div>
                                 </div>
