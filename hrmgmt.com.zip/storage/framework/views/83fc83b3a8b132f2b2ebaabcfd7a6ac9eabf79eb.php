<?php
    $current_page = 'rankpromotionform';
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">

                            <?php if(isset($displaystate)): ?>
                            <?php if($displaystate == 'edit'): ?>
                                <div class="header">
                                <h4 class="title">Update Rank Promotion Rules Settings</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('rank_promotion_setting/'.$this_rankpromotionId->id )); ?>" method="POST">

                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale')); ?></label>
                                                <select type="text" placeholder="<?php echo e(__('Select Salary Scale')); ?>" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?>" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    <?php $__currentLoopData = $salaryscale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSalaryScale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($eachSalaryScale->id == old('salaryscale', $this_rankpromotionId->salaryscale)): ?>
                                                            <option selected="selected" value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('salaryscale')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div>
                                    
                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('From Old Rank: ')); ?></label>
                                                <select type="text" placeholder="<?php echo e(__('Select From Old Rank')); ?>" class="form-control <?php echo e($errors->has('old_rank') ? ' is-invalid' : ''); ?>" name="old_rank" required autofocus>
                                                    <option value="">Select From Old Rank</option>

                                                    <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRanks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachRanks->id == old('old_rank', $this_rankpromotionId->old_rank)): ?>
                                                            <option selected="selected" value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('old_rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('old_rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('To New Rank: ')); ?></label>
                                                 <select type="text" placeholder="<?php echo e(__('Select To New Rank')); ?>" class="form-control <?php echo e($errors->has('new_rank') ? ' is-invalid' : ''); ?>" name="new_rank" required autofocus>
                                                    <option value="">Select To New Rank</option>

                                                    <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRanks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachRanks->id == old('new_rank', $this_rankpromotionId->new_rank)): ?>
                                                            <option selected="selected" value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('new_rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('new_rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>
    
                                    <a href="<?php echo e(url("rank_promotion_setting/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Rank Promotion Rules</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php elseif($displaystate == 'delete'): ?>
                                <div class="header">
                                <h4 class="title text-danger">Delete Rank Promotion Rule Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('rank_promotion_setting/'.$this_rankpromotionId->id )); ?>" method="POST">

                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Rank Promotion Rule?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale')); ?></label>
                                                <select disabled="disabled" type="text" placeholder="<?php echo e(__('Select Salary Scale')); ?>" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?>" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    <?php $__currentLoopData = $salaryscale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSalaryScale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachSalaryScale->id == old('salaryscale', $this_rankpromotionId->salaryscale)): ?>
                                                            <option selected="selected" value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('salaryscale')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('From Old Rank: ')); ?></label>
                                                <select disabled type="text" placeholder="<?php echo e(__('Select From Old Rank')); ?>" class="form-control <?php echo e($errors->has('old_rank') ? ' is-invalid' : ''); ?>" name="old_rank" required autofocus>
                                                    <option value="">Select From Old Rank</option>

                                                    <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRanks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachRanks->id == old('old_rank', $this_rankpromotionId->old_rank)): ?>
                                                            <option selected="selected" value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('old_rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('old_rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('To New Rank: ')); ?></label>
                                                 <select disabled type="text" placeholder="<?php echo e(__('Select To New Rank')); ?>" class="form-control <?php echo e($errors->has('new_rank') ? ' is-invalid' : ''); ?>" name="new_rank" required autofocus>
                                                    <option value="">Select To New Rank</option>

                                                    <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRanks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachRanks->id == old('new_rank', $this_rankpromotionId->new_rank)): ?>
                                                            <option selected="selected" value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('new_rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('new_rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
    
                                    <a href="<?php echo e(url("rank_promotion_setting/create")); ?>" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE Rank Promotion Rule</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php else: ?>
                                <div class="header">
                                    <h4 class="title">View Rank Promotion Rules Settings</h4>
                                    <p class="category"></p>
                                </div>
                                <div class="content">
                                    <form enctype="multipart/form-data" >

                                        <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale')); ?></label>
                                                <select disabled="disabled" type="text" placeholder="<?php echo e(__('Select Salary Scale')); ?>" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?>" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    <?php $__currentLoopData = $salaryscale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSalaryScale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachSalaryScale->id == old('salaryscale', $this_rankpromotionId->salaryscale)): ?>
                                                            <option selected="selected" value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('salaryscale')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('From Old Rank: ')); ?></label>
                                                <select disabled type="text" placeholder="<?php echo e(__('Select From Old Rank')); ?>" class="form-control <?php echo e($errors->has('old_rank') ? ' is-invalid' : ''); ?>" name="old_rank" required autofocus>
                                                    <option value="">Select From Old Rank</option>

                                                    <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRanks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachRanks->id == old('old_rank', $this_rankpromotionId->old_rank)): ?>
                                                            <option selected="selected" value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('old_rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('old_rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('To New Rank: ')); ?></label>
                                                 <select disabled type="text" placeholder="<?php echo e(__('Select To New Rank')); ?>" class="form-control <?php echo e($errors->has('new_rank') ? ' is-invalid' : ''); ?>" name="new_rank" required autofocus>
                                                    <option value="">Select To New Rank</option>

                                                    <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRanks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachRanks->id == old('new_rank', $this_rankpromotionId->new_rank)): ?>
                                                            <option selected="selected" value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('new_rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('new_rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>


                                    <a href="<?php echo e(url("rank_promotion_setting/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="<?php echo e(url("rank_promotion_setting/{$this_rankpromotionId->id}").'/edit'); ?>" class="btn btn-info btn-fill pull-right">Edit Rank Promotion Rules Setting</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        <?php else: ?>

                            <div class="header">
                                <h4 class="title">Add Rank Promotion Rules Settings</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <?php if(\Session::has('status')): ?>
                                  <div class="alert alert-success"><?php echo e(\Session::get('status')); ?></div>
                               <?php endif; ?>
                                <form enctype="multipart/form-data" action="<?php echo e(route('rank_promotion_setting.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale')); ?></label>
                                                <select type="text" placeholder="<?php echo e(__('Select Salary Scale')); ?>" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?>" name="salaryscale" required autofocus>
                                                    <option value="">Select SalaryScale</option>

                                                    <?php $__currentLoopData = $salaryscale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSalaryScale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachSalaryScale->id == old('salaryscale')): ?>
                                                            <option selected="selected" value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachSalaryScale->id); ?>"><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('salaryscale')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('From Old Rank: ')); ?></label>
                                                <select type="text" placeholder="<?php echo e(__('Select From Old Rank')); ?>" class="form-control <?php echo e($errors->has('old_rank') ? ' is-invalid' : ''); ?>" name="old_rank" required autofocus>
                                                    <option value="">Select From Old Rank</option>

                                                    <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRanks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachRanks->id == old('old_rank')): ?>
                                                            <option selected="selected" value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('old_rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('old_rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('To New Rank: ')); ?></label>
                                                 <select type="text" placeholder="<?php echo e(__('Select To New Rank')); ?>" class="form-control <?php echo e($errors->has('new_rank') ? ' is-invalid' : ''); ?>" name="new_rank" required autofocus>
                                                    <option value="">Select To New Rank</option>

                                                    <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRanks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachRanks->id == old('new_rank')): ?>
                                                            <option selected="selected" value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachRanks->id); ?>"><?php echo e($eachRanks->rank); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('new_rank')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('new_rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add Rank Promotion Rule Settings</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">All Rank Promotion Rule Settings Listing</h4>
                                <p class="category">Rank Promotion Rules Settings</p>
                                <?php if(session('salaryscale')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('salaryscale')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table id="entirestafflist" class="table table-hover table-striped">
                                    <thead>
                                        <th>Salary Scale</th>
                                        <th>From Old Rank</th>
                                        <th>To New Rank</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $rank_promotion_model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRankPromotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($eachRankPromotion->getSalaryScale()); ?></td>
                                            <td><?php echo e($eachRankPromotion->getOldRank()); ?></td>
                                            <td><?php echo e("{$eachRankPromotion->getNewRank()}"); ?></td>
                                            <td>
                                                <a class="btn btn-sm btn-info" href="<?php echo e(url("rank_promotion_setting/$eachRankPromotion->id").'/edit'); ?>" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="<?php echo e(url("rank_promotion_setting/$eachRankPromotion->id")); ?>" >View</a>
                                                <a class="btn btn-sm btn-danger" href="<?php echo e(url("rank_promotion_setting/$eachRankPromotion->id?action=del")); ?>" >Delete</a>
                                            </td>
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>