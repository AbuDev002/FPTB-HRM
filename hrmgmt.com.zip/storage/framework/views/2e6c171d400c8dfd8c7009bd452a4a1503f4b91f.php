<?php
    $current_page = 'dashboard';
    $page_title = "Dashboard";
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php if(Auth::user()->access_level == \App\Staff::$USER_ADMIN): ?>

            <div class="row">
                <div class="col-md-12">
                    <h5>Last Login: <?php echo e(Auth::user()->lastLogin()); ?></h5>
                </div>
            </div>
            <div class="row">
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Active Staff</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h1>
                                    <?php echo e(\App\SummaryReport::getStaffCount('active')); ?>

                                </h1>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Staff On Leave</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h3>
                                    Sabbatical: <?php echo e(\App\SummaryReport::getStaffCount('sabbatical')); ?>

                                </h3>
                                <h3>
                                    Study: <?php echo e(\App\SummaryReport::getStaffCount('study leave')); ?>

                                </h3>
                                <h3>
                                    Leave Of Absence: <?php echo e(\App\SummaryReport::getStaffCount('leave of absence')); ?>

                                </h3>

                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Department</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    <?php echo e(\App\Department::where('is_currently_active', 1)->count()); ?>

                                </h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">School</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    <?php echo e(\App\School::count()); ?>

                                </h1>
                            </div>
                        </div>
                    </div>

                </div>
            <div class="row">
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Staff On Holiday</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                
                                    
                                
                                <h3>
                                    Suspension Pay: <?php echo e(\App\SummaryReport::getStaffCount('suspension with pay')); ?>

                                </h3>
                                <h3>
                                    Suspension No-Pay: <?php echo e(\App\SummaryReport::getStaffCount('suspension without pay')); ?>

                                </h3>
                                <h3>
                                    Annual Leave: <?php echo e(\App\SummaryReport::getStaffCount('annual leave')); ?>

                                </h3>
                                <h3>
                                    Maternity Leave: <?php echo e(\App\SummaryReport::getStaffCount('maternity leave')); ?>

                                </h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Out Of Service</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h3>
                                    Dismisal: <?php echo e(\App\SummaryReport::getStaffCount('dismissal')); ?>

                                </h3>
                                <h3>
                                    Withdrawal: <?php echo e(\App\SummaryReport::getStaffCount('withdrawal')); ?>

                                </h3>
                                <h3>
                                    Transfer: <?php echo e(\App\SummaryReport::getStaffCount('transfer')); ?>

                                </h3>
                                <h3>
                                    Retire: <?php echo e(\App\SummaryReport::getStaffCount('retire')); ?>

                                </h3>
                                <h3>
                                    Termination: <?php echo e(\App\SummaryReport::getStaffCount('termination')); ?>

                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Deceased</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    <?php echo e(\App\SummaryReport::getStaffCount('deceased')); ?>

                                </h1>
                            </div>
                        </div>
                    </div>

                <div class="col-md-3">
                    <div class="card">

                        <div class="header">
                            <h4 class="title text-center">Promotion Notification</h4>
                            <p class="category"></p>
                        </div>
                        <div class="content text-info  text-center">
                            <h1>
                                <?php echo e(\App\SummaryReport::getPromotionNotification()); ?>

                            </h1>
                            <p>
                                <a class="btn btn-success" href="<?php echo e(url('promotionlist')); ?>">View</a>
                            </p>
                        </div>
                    </div>
                </div>



            </div>

                <div class="row">

                    <div class="col-md-12">
                        <table id="usersonline_table" class="table table-bordered table-condensed">
                                                            <thead>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    <td>Name</td>
                                                                    <td>User-Status</td>
                                                                    <td>Level</td>
                                                                    <td>Status</td>
                                                                    <td>Last Seen</td>
                                                                    <td>Action</td>
                                                                </tr>
                                                            </thead>
                                                            <tfoot>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    <td>Name</td>
                                                                    <td>User-Status</td>
                                                                    <td>Level</td>
                                                                    <td>Status</td>
                                                                    <td>Last Seen</td>
                                                                    <td>Action</td>
                                                                </tr>
                                                            </tfoot>
                                                            <tbody id="usersonline_table_body">
                                                                <?php
                                                                    $count_id = 1;
                                                                ?>

                                                                <?php $__currentLoopData = $sessionlast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thisSession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                    <?php
                                                                        $thisVeryUser = \App\User::find($thisSession->user_id);
                                                                        $cT = \Carbon\Carbon::createFromTimestamp($thisSession->last_activity);
                                                                        $diff_in_minutes = $cT->diffInMinutes(\Carbon\Carbon::now());
                                                                    ?>
                                                                <?php if($diff_in_minutes <= 10): ?>
                                                                <tr>
                                                                    <td><?php echo e($count_id++); ?></td>
                                                                    <td><?php echo e($thisVeryUser->username); ?></td>
                                                                    <td><?php echo e($thisVeryUser->name); ?></td>
                                                                    <?php if($thisVeryUser->status == \App\User::$USER_ACCOUNT_STATUS_ENABLED): ?>
                                                                    <td><span class="label label-success">Enabled Account</span></td>
                                                                    <?php else: ?>
                                                                    <td><span class="label label-danger">Disabled Account</span></td>
                                                                    <?php endif; ?>
                                                                    <td><?php echo e(($thisVeryUser->access_level == \App\Staff::$USER_ADMIN) ? "ADMIN" : ( ($thisVeryUser->access_level == \App\Staff::$USER_SUBADMIN) ? "SUB-ADMIN" : ($thisVeryUser->access_level == \App\Staff::$USER_STAFF ? "STAFF" : "STAFF"))); ?></td>
                                                                    <td><span class="label label-success">Online (Active)</span></td>
                                                                    <td><?php echo e($thisVeryUser->isOnline()['last_activity']); ?></td>
                                                                    <td><form loguserout="yes"  action="<?php echo e(url('loguserout')); ?>" method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <input type="hidden" name="loguserout" value="<?php echo e($thisVeryUser->id); ?>" >
                                                                        <button class="btn btn-danger btn-sm btn-fill" href="">Logout User</button>
                                                                        </form>
                                                                    </td>
                                                                </tr>
                                                                <?php endif; ?>
                                                                <?php if($diff_in_minutes > 10 && $diff_in_minutes <= 30): ?>
                                                                <tr>
                                                                    <td><?php echo e($count_id++); ?></td>
                                                                    <td><?php echo e($thisVeryUser->username); ?></td>
                                                                    <td><?php echo e($thisVeryUser->name); ?></td>
                                                                    <?php if($thisVeryUser->status == \App\User::$USER_ACCOUNT_STATUS_ENABLED): ?>
                                                                    <td><span class="label label-success">Enabled Account</span></td>
                                                                    <?php else: ?>
                                                                    <td><span class="label label-danger">Disabled Account</span></td>
                                                                    <?php endif; ?>
                                                                    <td><?php echo e($thisSession->admin ?? ''); ?></td>
                                                                    <td><?php echo e(($thisVeryUser->access_level == \App\Staff::$USER_ADMIN) ? "ADMIN" : ( ($thisVeryUser->access_level == \App\Staff::$USER_SUBADMIN) ? "SUB-ADMIN" : ($thisVeryUser->access_level == \App\Staff::$USER_STAFF ? "STAFF" : "STAFF"))); ?></td>
                                                                    <td><span class="label label-warning">Online (Inactive)</span></td>
                                                                    <td><?php echo e($thisVeryUser->isOnline()['last_activity']); ?></td>
                                                                     <td><form loguserout="yes" action="<?php echo e(url('loguserout')); ?>" method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <input type="hidden" name="loguserout" value="<?php echo e($thisVeryUser->id); ?>" >
                                                                        <button class="btn btn-danger btn-sm btn-fill" href="">Logout User</button>
                                                                        </form>
                                                                    </td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                    </div>

                </div>


        <?php elseif(Auth::user()->access_level == \App\Staff::$USER_SUBADMIN): ?>
                <div class="row">
                <div class="col-md-12">
                    <h5>Last Login: <?php echo e(Auth::user()->lastLogin()); ?></h5>
                </div>
            </div>
            <div class="row">
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Active Staff</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h1>
                                    <?php echo e(\App\SummaryReport::getStaffCount('active')); ?>

                                </h1>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Staff On Leave</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h3>
                                    Sabbatical: <?php echo e(\App\SummaryReport::getStaffCount('sabbatical')); ?>

                                </h3>
                                <h3>
                                    Study: <?php echo e(\App\SummaryReport::getStaffCount('study leave')); ?>

                                </h3>
                                <h3>
                                    Leave Of Absence: <?php echo e(\App\SummaryReport::getStaffCount('leave of absence')); ?>

                                </h3>

                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Department</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    <?php echo e(\App\Department::where('is_currently_active', 1)->count()); ?>

                                </h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">School</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    <?php echo e(\App\School::count()); ?>

                                </h1>
                            </div>
                        </div>
                    </div>

                </div>
            <div class="row">
                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Staff On Holiday</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                
                                    
                                
                                <h3>
                                    Suspension Pay: <?php echo e(\App\SummaryReport::getStaffCount('suspension with pay')); ?>

                                </h3>
                                <h3>
                                    Suspension No-Pay: <?php echo e(\App\SummaryReport::getStaffCount('suspension without pay')); ?>

                                </h3>
                                <h3>
                                    Annual Leave: <?php echo e(\App\SummaryReport::getStaffCount('annual leave')); ?>

                                </h3>
                                <h3>
                                    Maternity Leave: <?php echo e(\App\SummaryReport::getStaffCount('maternity leave')); ?>

                                </h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Out Of Service</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h3>
                                    Dismisal: <?php echo e(\App\SummaryReport::getStaffCount('dismissal')); ?>

                                </h3>
                                <h3>
                                    Withdrawal: <?php echo e(\App\SummaryReport::getStaffCount('withdrawal')); ?>

                                </h3>
                                <h3>
                                    Transfer: <?php echo e(\App\SummaryReport::getStaffCount('transfer')); ?>

                                </h3>
                                <h3>
                                    Retire: <?php echo e(\App\SummaryReport::getStaffCount('retire')); ?>

                                </h3>
                                <h3>
                                    Termination: <?php echo e(\App\SummaryReport::getStaffCount('termination')); ?>

                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Deceased</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    <?php echo e(\App\SummaryReport::getStaffCount('deceased')); ?>

                                </h1>
                            </div>
                        </div>
                    </div>

                <div class="col-md-3">
                    <div class="card">

                        <div class="header">
                            <h4 class="title text-center">Promotion Notification</h4>
                            <p class="category"></p>
                        </div>
                        <div class="content text-info  text-center">
                            <h1>
                                <?php echo e(\App\SummaryReport::getPromotionNotification()); ?>

                            </h1>
                            <p>
                                <a class="btn btn-success" href="<?php echo e(url('promotionlist')); ?>">View</a>
                            </p>
                        </div>
                    </div>
                </div>



            </div>

                <div class="row">

                    <div class="col-md-12">

                    </div>

                </div>

        <?php elseif(Auth::user()->access_level == \App\Staff::$USER_SUBADMIN): ?>
                <div class="row">
                    <div class="col-md-12">
                        <h5>Last Login: <?php echo e(Auth::user()->lastLogin()); ?></h5>
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">Active Staff</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h1>
                                    <?php echo e(\App\Staff::where('status', \App\Status::where('status', 'active')->get()->first()->id)->get()->count()); ?>

                                </h1>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card">

                            <div class="header">
                                <h4 class="title text-center">In-Active Staff</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-info  text-center">
                                <h1>
                                    <?php echo e(\App\Staff::where('status', '<>', \App\Status::where('status', 'active')->get()->first()->id)->get()->count()); ?>

                                </h1>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">Department</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    <?php echo e(\App\Department::where('is_currently_active', 1)->count()); ?>

                                </h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card card-outline-primary card-success bg-success ">
                            <div class="header">
                                <h4 class="title text-center">School</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content text-success text-center">
                                <h1>
                                    <?php echo e(\App\School::count()); ?>

                                </h1>
                            </div>
                        </div>
                    </div>
                </div>
        <?php elseif(Auth::user()->access_level == \App\Staff::$USER_STAFF): ?>

            <div class="row">
                <h4 class="panel-heading text-primary">
                    Welcome To Your Dashboard Staff: <?php echo e(Auth::user()->name); ?>

                </h4>
            </div>

            <div class="row">
                 <div class="col-md-12">
                        <div class="card">
                        </div>
                    </div>
            </div>

            <div class="row">


                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <p class="text-info">
                                    <?php if($errors->any()): ?>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="info text-danger"><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </p>
                                <h4 class="title">Manage Your Account</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('staff.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('FirstName')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('FirstName')); ?>" class="form-control <?php echo e($errors->has('firstname') ? ' is-invalid' : ''); ?>" name="firstname" value="<?php echo e(old('firstname')); ?>" required autofocus>
                                                <?php if($errors->has('firstname')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('firstname')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('LastName')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('LastName')); ?>" class="form-control <?php echo e($errors->has('lastname') ? ' is-invalid' : ''); ?>" name="lastname" value="<?php echo e(old('lastname')); ?>" required autofocus>
                                                <?php if($errors->has('lastname')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('lastname')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('OtherName')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('OtherName')); ?>" class="form-control <?php echo e($errors->has('othername') ? ' is-invalid' : ''); ?>" name="othername" value="<?php echo e(old('othername')); ?>"  autofocus>
                                                <?php if($errors->has('othername')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('othername')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label><?php echo e(__('Gender')); ?></label>
                                                <select name="gender" class="form-control" required="required">
                                                    <option value="M"><?php echo e(__('Male')); ?></option>
                                                    <option value="F"><?php echo e(__('Female')); ?></option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Staff No (PFN)')); ?></label>
                                                <span id="staffnocheckokmessage"class="hide text-success">Staff No - Available (good!)</span>
                                                <span id="staffnocheckbadmessage" class="hide text-danger">Staff No - Unavailable (try again)</span>
                                                <input id="staffnocheck" type="text" class="form-control control" placeholder="<?php echo e(__('staffno (PFN)')); ?>" class="form-control <?php echo e($errors->has('staffno') ? ' is-invalid' : ''); ?>" name="staffno" value="<?php echo e(old('staffno')); ?>"  required="required" autofocus>

                                                <?php if($errors->has('staffno')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffno')); ?></strong>
                                                        </span>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('Marital Status')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('maritalstatus') ? ' is-invalid' : ''); ?> " name="maritalstatus" required>

                                                    <option <?php echo e(old('maritalstatus')=="M"? 'selected="selected"' : ''); ?> value="M" >Married</option>
                                                    <option <?php echo e(old('maritalstatus') =="S"? 'selected="selected"' : ''); ?> value="S" >Single</option>


                                                </select>
                                                <?php if($errors->has('maritalstatus')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('maritalstatus')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('PhoneNo')); ?></label>
                                                <input type="phoneno" placeholder="<?php echo e(__('PhoneNo')); ?>" class="form-control <?php echo e($errors->has('phoneno') ? ' is-invalid' : ''); ?>" name="phoneno" value="<?php echo e(old('phoneno')); ?>" required  autofocus>
                                                <?php if($errors->has('phoneno')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('phoneno')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('Email')); ?></label>
                                                <input type="email" placeholder="<?php echo e(__('Email')); ?>" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>"  autofocus>
                                                <?php if($errors->has('email')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('DateOfBirth')); ?></label>
                                                <input type="date" class="form-control" placeholder="<?php echo e(__('dateobirth')); ?>" class="form-control <?php echo e($errors->has('dateobirth') ? ' is-invalid' : ''); ?>" name="dateobirth" value="<?php echo e(old('dateobirth')); ?>" required="required"  autofocus>

                                                <?php if($errors->has('dateobirth')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('dateobirth')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('Photo')); ?></label>
                                                <input type="file" class="form-control" placeholder="<?php echo e(__('photo')); ?>" class="form-control <?php echo e($errors->has('photo') ? ' is-invalid' : ''); ?>" name="photo" value="<?php echo e(old('photo')); ?>"  autofocus>

                                                <?php if($errors->has('photo')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('photo')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>
                                    <hr>

                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('State')); ?></label>
                                                <select id="state" name="state" class="form-control" required="required">
                                                    <option value="">Select State Of Origin</option>
                                                    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachState): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option <?php echo e(old('level')==$eachState? $eachState : ''); ?> value="<?php echo e($eachState->id); ?>" ><?php echo e($eachState->state); ?></option>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Lga')); ?></label>
                                                <select id="lga" name="lga" class="form-control" required="required">
                                                    <option value="">Select Local Government</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Staff Class')); ?></label>
                                                <select id="staffclass" class="form-control <?php echo e($errors->has('staffclass') ? ' is-invalid' : ''); ?> " name="staffclass" required>
                                                    <option selected="selected" >Select Staff Class</option>
                                                    <option value="AS">Academic Staff</option>
                                                    <option value="NA">Non-Academic Staff</option>
                                                </select>

                                                <?php if($errors->has('staffclass')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffclass')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Department')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('department') ? ' is-invalid' : ''); ?> " name="department" required>
                                                    <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option <?php echo e(old('department')==$eachDepartment? $eachDepartment : ''); ?> value="<?php echo e($eachDepartment->id); ?>" ><?php echo e($eachDepartment->department); ?> <?php echo e($eachDepartment->description); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php if($errors->has('department')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('department')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('First Appointment Date')); ?></label>
                                                <input type="date" class="form-control" placeholder="<?php echo e(__('First Appointment Date')); ?>" class="form-control <?php echo e($errors->has('firstappointdate') ? ' is-invalid' : ''); ?>" name="firstappointdate" value="<?php echo e(old('firstappointdate')); ?>"  required="required"  autofocus>

                                                <?php if($errors->has('firstappointdate')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('firstappointdate')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Appointment Type')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('appointmenttype') ? ' is-invalid' : ''); ?> " name="appointmenttype" required>
                                                    <?php $__currentLoopData = $appointmenttype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anAppointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($anAppointment->id); ?>"><?php echo e($anAppointment->appointmenttype); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php if($errors->has('appointmenttype')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('appointmenttype')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Position (If Any)')); ?></label>
                                                    <select class="form-control <?php echo e($errors->has('position') ? ' is-invalid' : ''); ?> " name="position" required>

                                                            <option value="0">None</option>
                                                        <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachPosition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($eachPosition->id); ?>"><?php echo e($eachPosition->position); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>

                                                <?php if($errors->has('position')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('position')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Step')); ?></label>

                                                    <select class="form-control <?php echo e($errors->has('step') ? ' is-invalid' : ''); ?> " name="step" required>

                                                    <?php for($i = 1; $i <= 50; $i++): ?>
                                                        <option <?php echo e(old('step')=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>

                                                <?php if($errors->has('step')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('step')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Present Appointment Date')); ?></label>
                                                <input type="date" class="form-control" placeholder="<?php echo e(__('Present Appointment Date')); ?>" class="form-control <?php echo e($errors->has('presentappointdate') ? ' is-invalid' : ''); ?>" name="presentappointdate" value="<?php echo e(old('presentappointdate')); ?>" required="required"  autofocus>

                                                <?php if($errors->has('presentappointdate')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('presentappointdate')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Rank')); ?></label>
                                                <select id="rank" class="form-control <?php echo e($errors->has('rank') ? ' is-invalid' : ''); ?> " name="rank" required>
                                                        <option value="">Select Staff Rank</option>

                                                </select>
                                                <?php if($errors->has('rank')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div id="con___parent" class="col-md-3">
                                            <div id="conpcass" class="form-group">
                                                <label id="con_label"><?php echo e(__('CONPCASS')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('con___') ? ' is-invalid' : ''); ?> " name="con___" required>

                                                    <?php for($i = 1; $i < 10; $i++): ?>
                                                        <option <?php echo e(old('con___')=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                                <?php if($errors->has('con___')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('con___')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Category')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('category') ? ' is-invalid' : ''); ?> " name="category" required>
                                                    <option <?php echo e(old('category') =="JS"? 'selected="selected"' : ''); ?> value="JS" >Junior Staff</option>
                                                    <option <?php echo e(old('category')=="SS"? 'selected="selected"' : ''); ?> value="SS" >Senior Staff</option>
                                                </select>

                                                <?php if($errors->has('category')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('category')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('GPZone')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('gpzone') ? ' is-invalid' : ''); ?> " name="gpzone" required>

                                                    <?php $__currentLoopData = $gpzone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachGPZone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($eachGPZone->id); ?>"><?php echo e($eachGPZone->gpzone); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                </select>
                                                <?php if($errors->has('gpzone')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('gpzone')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Status')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?> " name="status" required>
                                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($eachStatus->id); ?>"><?php echo e($eachStatus->status); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Address 1</label>
                                                <input name="address1" type="text" class="form-control" placeholder="Address 2" value="<?php echo e(old('address1')); ?>"  required="required" >
                                                <?php if($errors->has('address1')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('address1')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Address 2</label>
                                                <input name="address2" type="text" class="form-control" placeholder="Address 2" value="<?php echo e(old('address2')); ?>"  required="required" >
                                                <?php if($errors->has('address2')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('address2')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend class="title">Qualification</legend>
                                            <div class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select name="qualificationtype[]" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option value="OND">OND</option>
                                                            <option value="HND">HND</option>
                                                            <option value="DEG">Degree</option>
                                                            <option value="PGD">PGD</option>
                                                            <option value="MSC">MSC</option>
                                                            <option value="PHD">PHD</option>
                                                            <option value="OTHERS">Others</option>
                                                        </select>
                                                        <?php if($errors->has('qualificationtitle[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtitle[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input name="qualificationtitle[]" type="text" class="form-control" placeholder="Qualification Title" value="<?php echo e(old('qualificationtitle[]')); ?>"  required="required" >
                                                        <?php if($errors->has('qualificationtitle[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtitle[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input name="qualificationdesc[]" type="text" class="form-control" placeholder="Qualification Description" value="<?php echo e(old('qualificationdesc[]')); ?>"  required="required" >
                                                        <?php if($errors->has('qualificationdesc[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationdesc[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea required="required" name="registeredprobody[]" class="form-control" placeholder="Registered Professional Body" ><?php echo e(old('registeredprobody[]', "NONE")); ?></textarea>
                                                        <?php if($errors->has('registeredprobody[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('registeredprobody[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>

                                                        <input type="hidden" name="qualificationcount[]" value="1" >
                                                    </div>
                                                </div>

                                            </div>
                                            <hr style="border: 1px solid grey;" />

                                        </fieldset>
                                    </div>

                                    <button id="add_qualification" type="button" class="btn btn-info btn-fill pull-left">Add Another Qualification</button>
                                    <button id="btnsubmit" type="submit" class="btn btn-success btn-fill pull-right">Add New Staff</button>
                                    <div class="clearfix"></div>
                                </form>

                                <div id="conpcass" class="form-group hidden">
                                                <label id="con_label"><?php echo e(__('CONPCASS')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('con___') ? ' is-invalid' : ''); ?> " name="con___" required>

                                                    <?php for($i = 1; $i < 10; $i++): ?>
                                                        <option <?php echo e(old('con___')=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                                <?php if($errors->has('con___')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('con___')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                </div>
                                <div id="contediss" class="form-group hidden">
                                                <label id="con_label"><?php echo e(__('CONTEDISS')); ?></label>
                                                <select class="form-control <?php echo e($errors->has('con___') ? ' is-invalid' : ''); ?> " name="con___" required>

                                                    <?php for($i = 1; $i < 16; $i++): ?>
                                                        <option <?php echo e(old('con___')=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                                <?php if($errors->has('con___')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('con___')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                 </div>

                                 <div id="qualificationformcontrols" class="qualificationformcontrols hidden">
                                    <div class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select name="qualificationtype[]" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option value="OND">OND</option>
                                                            <option value="HND">HND</option>
                                                            <option value="DEG">Degree</option>
                                                            <option value="PGD">PGD</option>
                                                            <option value="MSC">MSC</option>
                                                            <option value="PHD">PHD</option>
                                                            <option value="OTHERS">Others</option>
                                                        </select>
                                                        <?php if($errors->has('qualificationtype[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtype[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input required="required" name="qualificationtitle[]" type="text" class="form-control" placeholder="Qualification Title" value="<?php echo e(old('qualificationtitle[]')); ?>">
                                                        <?php if($errors->has('qualificationtitle[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtitle[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input required="required" name="qualificationdesc[]" type="text" class="form-control" placeholder="Qualification Description" value="<?php echo e(old('qualificationdesc[]')); ?>"  required="required" >
                                                        <?php if($errors->has('qualificationdesc[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationdesc[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea required="required" name="registeredprobody[]" class="form-control" placeholder="Registered Professional Body" ><?php echo e(old('registeredprobody[]', "NONE")); ?></textarea>
                                                        <?php if($errors->has('registeredprobody[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('registeredprobody[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>

                                                        <input type="hidden" name="qualificationcount[]" value="1" >
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <button onclick="this.parentNode.parentNode.remove()" type="button" class="btn-sm btn-danger pull-right btn removebtn">Remove</button>
                                                </div>
                                                <div class="col-md-12" style="padding-top: 1px; padding-left: 1px;">
                                                <hr style="border: 1px solid grey;">
                                                </div>
                                            </div>
                                 </div>


                            </div>
                        </div>
                    </div>


            </div>

            <div class="row">

                    <div class="col-md-6">
                        <div class="card">

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">

                        </div>
                    </div>
            </div>

        <?php endif; ?>

<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
