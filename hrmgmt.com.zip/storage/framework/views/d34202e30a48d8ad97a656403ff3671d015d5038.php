<?php
    $current_page = 'reports';
    $page_title = "Staff To Be Promoted";
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-12">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">Staff Due For Promotion Listing</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('leave.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <h5 id="staff_report_title" name="staff_report_title_name" class="text-center">STAFF TO BE PROMOTED</h5>
                                    <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group" id="searchResults">
                                           <table id="staffreporttable" class="table table-bordered table-condensed">
                                                   <thead>
                                                       <tr>
                                                           <td>S/N</td>
                                                           <td>STAFFNO</td>
                                                           <td>FULLNAMES</td>
                                                           <td>DEPARTMENT</td>
                                                           <td>RANK</td>
                                                           <td>CATEGORY</td>
                                                           <td>DATEOB</td>
                                                           <td>GENDER</td>
                                                           <td>POSITION</td>
                                                           <td>PHONENO</td>
                                                           <td>STATE</td>
                                                           <td>LGA</td>
                                                           <td>STATUS</td>
                                                           <td>LAST PROMOTED</td>
                                                       </tr>
                                                   </thead>
                                                   <tbody id="searchResultsBody">

                                                   </tbody>
                                               </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                                <hr>

                            </div>
                        </div>
                    </div>

                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
