<?php
    $current_page = 'reports';
    $page_title = "Staff Reports";
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-12">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">Get Staff Reports</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content"> 
                                <form enctype="multipart/form-data" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-2 col-sm-2" style="border-right: 1px solid #333" >
                                            <div class="form-group" >
                                                <label><?php echo e(__('Filter By Status')); ?></label>
                                                <select class="form-control" id="searchByStatus">
                                                    <option selected="selected"   value="all">All Status</option>
                                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($eachStatus->id); ?>"><?php echo e($eachStatus->status); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                <?php endif; ?>

                                            </div>
                                        </div>

                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label><?php echo e(__('FirstName')); ?></label>
                                                <input id="fname" type="text" placeholder="<?php echo e(__('FirstName')); ?>" class="form-control <?php echo e($errors->has('firstname') ? ' is-invalid' : ''); ?>" name="firstname" value="<?php echo e(old('firstname')); ?>" required autofocus>
                                                <?php if($errors->has('firstname')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('firstname')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label><?php echo e(__('LastName')); ?></label>
                                                <input id="lname" type="text" placeholder="<?php echo e(__('LastName')); ?>" class="form-control <?php echo e($errors->has('lastname') ? ' is-invalid' : ''); ?>" name="lastname" value="<?php echo e(old('lastname')); ?>" required autofocus>
                                                <?php if($errors->has('lastname')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('lastname')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label><?php echo e(__('OtherName')); ?></label>
                                                <input id="oname" type="text" placeholder="<?php echo e(__('OtherName')); ?>" class="form-control <?php echo e($errors->has('othername') ? ' is-invalid' : ''); ?>" name="othername" value="<?php echo e(old('othername')); ?>"  autofocus>
                                                <?php if($errors->has('othername')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('othername')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <label><?php echo e(__('Search Action')); ?></label>
                                            <button id="btn_names" type="button" class="btn btn-success">Search By Names</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label><?php echo e(__('Staff Number Search')); ?></label>
                                                <input id="staffno" type="text" class="form-control" placeholder="<?php echo e(__('Staff No Search')); ?>" class="form-control <?php echo e($errors->has('staffno') ? ' is-invalid' : ''); ?>" name="staffno" value="<?php echo e(old('staffno')); ?>"  autofocus>
                                                <?php if($errors->has('staffno')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffno')); ?></strong>
                                                        </span>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                        <div class="col-md-2 col-sm-2">
                                            <label><?php echo e(__('Action')); ?></label> <br>
                                            <button id="btn_staffno" type="button" class="btn btn-success">Search By StaffNo</button>
                                        </div>
                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label><?php echo e(__('Staff Class')); ?></label>
                                                <select class="form-control" id="searchByStaffClass">
                                                    <option   value="">Search By Staff Class</option>
                                                    <option value="AS">Academic Staff</option>
                                                    <option value="NA">NonAcademic Staff</option>
                                                    <option value="ALL">All</option>
                                                </select>
                                                <?php if($errors->has('staffno')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffno')); ?></strong>
                                                        </span>
                                                <?php endif; ?>

                                            </div>
                                        </div>

                                        <div class="col-md-2 col-sm-2">
                                            <div class="form-group">
                                                <label><?php echo e(__('Department')); ?></label>
                                                <select class="form-control" id="searchByDepartment">
                                                    <option   value="">Search By Department</option>
                                                    <option   value="all">All Department</option>
                                                    <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($eachDepartment->id); ?>"><?php echo e($eachDepartment->department); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('department')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('department')); ?></strong>
                                                        </span>
                                                <?php endif; ?>

                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <label><?php echo e(__('Search Action')); ?></label>
                                            <button id="btn_class_department" type="button" class="btn btn-success">Search By Class/Department</button>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-2 col-sm-2" style="border-right: 1px solid #333" >
                                            <div class="form-group" >
                                                <label><?php echo e(__('Summary Report')); ?></label>
                                                <a href="<?php echo e(url('summary_report')); ?>" class="btn btn-success">Summary Report</a>

                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3">
                                             <div style="display: none;" class="imgloaderindicator"></div> 
                                        </div>
                                    </div>


                                    <h5 id="staff_report_title" name="staff_report_title_name" class="text-center">STAFF REPORTS</h5>
                                    <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group" id="searchResults">
                                           <table id="staffreporttable" class="table table-bordered table-condensed">
                                                   <thead>
                                                       <tr>
                                                           <td>S/N</td>
                                                           <td>STAFFNO</td>
                                                           <td>FULLNAMES</td>
                                                           <td>DEPARTMENT</td>
                                                           <td>RANK</td>
                                                           <td>CATEGORY</td>
                                                           <td>DATEOB</td>
                                                           <td>GENDER</td>
                                                           <td>POSITION</td>
                                                           <td>ADDED. RESP.</td>
                                                           <td>PHONENO</td>
                                                           <td>STATE</td>
                                                           <td>LGA</td>
                                                           <td>STATUS</td>
                                                       </tr>
                                                   </thead>
                                                   <tbody id="searchResultsBody">

                                                   </tbody>
                                               </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                                <hr>

                                
                            </div>
                        </div>
                    </div>

                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
