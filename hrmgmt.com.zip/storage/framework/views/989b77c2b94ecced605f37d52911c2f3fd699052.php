<?php
    $current_page = 'leave';
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-10">
                        <div class="card">

                            <div class="header">
                                <?php if(is_null($staff) || is_null($status)): ?>
                                    <h4 class="title">Give Staff A Leave</h4>
                                <?php else: ?>
                                    <h4 class="title">Give Staff <b><?php echo e("$staff->fname $staff->lname $staff->oname"); ?></b> A <?php echo e("$status->status"); ?></h4>
                                <?php endif; ?>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('leave.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <?php if(!is_null($staff) && !is_null($status)): ?>
                                            <input type="hidden" name="staff_id" class="btn btn-primary|secondary|success|danger|warning|info|light|dark|link" type="button" value="<?php echo e($staff->id); ?>">
                                            <input type="hidden" name="status_id" class="btn btn-primary|secondary|success|danger|warning|info|light|dark|link" type="button" value="<?php echo e($status->id); ?>">
                                        <?php endif; ?>

                                        <div class="col-md-1">
                                            <label>
                                            <input required name="daterangetype" id="" class="radio input-radio" type="radio" value="<?php echo e(\App\Leave::RANGE_ONE); ?>">None-Range Date:
                                        </label>
                                        </div>
                                          <div class="col-md-2">
                                            <div class="form-group">
                                                <?php if(!is_null($status)): ?>
                                                <label><?php echo e(__("$status->status" . ' On')); ?></label>
                                                <?php else: ?>
                                                <label><?php echo e(__('On')); ?></label>
                                                <?php endif; ?>
                                                <input id="leavefrom_date"  type="date" class="form-control" placeholder="<?php echo e(__('leaveon')); ?>" class="form-control <?php echo e($errors->has('leaveon') ? ' is-invalid' : ''); ?>" name="leaveon" value="<?php echo e(old('leaveon')); ?>"  autofocus>

                                                <?php if($errors->has('leaveon')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('leaveon')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <?php ($staff_no = $staff? $staff->staffno : ''); ?>

                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label><?php echo e(__('Staff No')); ?></label>
                                                <input disabled type="text" class="form-control" placeholder="<?php echo e(__('staffno')); ?>" class="form-control <?php echo e($errors->has('staffno') ? ' is-invalid' : ''); ?>" name="staffno" value="<?php echo e(old('staffno', $staff_no)); ?>"  autofocus>
                                                <?php if($errors->has('staffno')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffno')); ?></strong>
                                                        </span>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <?php if(!is_null($staff) && !is_null($status)): ?>
                                            <input type="hidden" name="staff_id" class="btn btn-primary|secondary|success|danger|warning|info|light|dark|link" type="button" value="<?php echo e($staff->id); ?>">
                                        <?php endif; ?>
                                        <div class="col-md-1">
                                            <label>
                                            <input required name="daterangetype" id="" class="radio input-radio" type="radio" value="<?php echo e(\App\Leave::RANGE_TWO); ?>">Range Date:
                                        </label>
                                        </div>
                                          <div class="col-md-2">
                                            <div class="form-group">
                                                <?php if(!is_null($status)): ?>
                                                <label><?php echo e(__("$status->status" . ' From')); ?></label>
                                                <?php else: ?>
                                                <label><?php echo e(__('From')); ?></label>
                                                <?php endif; ?>
                                                <input id="leavefrom_date"  type="date" class="form-control" placeholder="<?php echo e(__('leavefrom')); ?>" class="form-control <?php echo e($errors->has('leavefrom') ? ' is-invalid' : ''); ?>" name="leavefrom" value="<?php echo e(old('leavefrom')); ?>"  autofocus>

                                                <?php if($errors->has('leavefrom')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('leavefrom')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <?php if(!is_null($status)): ?>
                                                <label><?php echo e(__("$status->status" . ' To')); ?></label>
                                                <?php else: ?>
                                                <label><?php echo e(__(' On')); ?></label>
                                                <?php endif; ?>
                                                <input id="leaveto_date" type="date" class="form-control" placeholder="<?php echo e(__('leaveto')); ?>" class="form-control <?php echo e($errors->has('leaveto') ? ' is-invalid' : ''); ?>" name="leaveto" value="<?php echo e(old('leaveto')); ?>"  autofocus>

                                                <?php if($errors->has('leaveto')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('leaveto')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <?php ($staff_no = $staff? $staff->staffno : ''); ?>

                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label><?php echo e(__('Staff No')); ?></label>
                                                <input disabled type="text" class="form-control" placeholder="<?php echo e(__('staffno')); ?>" class="form-control <?php echo e($errors->has('staffno') ? ' is-invalid' : ''); ?>" name="staffno" value="<?php echo e(old('staffno', $staff_no)); ?>"  autofocus>
                                                <?php if($errors->has('staffno')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffno')); ?></strong>
                                                        </span>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <?php if(!is_null($status)): ?>
                                                <label><?php echo e("$status->status"); ?> Comment/Description</label>
                                                <?php else: ?>
                                                <label><?php echo e('Comment/Description'); ?></label>
                                                <?php endif; ?>
                                                <textarea required name="statusdescription" type="text" class="form-control" placeholder="<?php echo e(!is_null($status)? $status->status : ''); ?> Description"><?php echo e(old('statusdescription')); ?></textarea>
                                                <?php if($errors->has('statusdescription')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('statusdescription')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <hr>
                                    <?php if(is_null($staff) || is_null($status)): ?>
                                    <button id="btnsubmit" disabled="" type="submit" class="btn btn-info btn-fill pull-right">Give This Staff Leave</button>
                                    <?php else: ?>
                                    <button id="btnsubmit"  type="submit" class="btn btn-info btn-fill pull-right">Change This Staff <?php echo e("$status->status"); ?></button>
                                    <?php endif; ?>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-10 container-fluid">
                        <h5>Two Date Range Leave List</h5>
                        <table id="staff_leave_table" class="table table-condensed table-responsive">
                            <thead>
                                <tr>
                                    <th>S/N</th>
                                    <th>STAFF NAME</th>
                                    <th>STAFF REGNO</th>
                                    <th>FROM DATE</th>
                                    <th>TO DATE</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php ($count = 1); ?>
                                <?php $__currentLoopData = $allLeave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachLeave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td scope="row"><?php echo e($count++); ?></td>
                                        <td> <?php echo e(\App\Staff::find($eachLeave->staff_id)->getFullName()); ?> </td>
                                        <td><?php echo e(\App\Staff::find($eachLeave->staff_id)->staffno); ?></td>
                                        <td><?php echo e((new DateTime($eachLeave->from))->format('d M Y')); ?></td>
                                        <td><?php echo e((new DateTime($eachLeave->to))->format('d M Y')); ?></td>
                                        <td><?php echo e($eachLeave->description); ?></td>
                                        <td><?php echo $eachLeave->status == \App\Leave::ACTIVE ? "<span class='label label-success'>ACTIVELY ON LEAVE</span>" : "<span class='label label-danger'>BACK FROM LEAVE</span>"; ?></td>
                                        <td></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
