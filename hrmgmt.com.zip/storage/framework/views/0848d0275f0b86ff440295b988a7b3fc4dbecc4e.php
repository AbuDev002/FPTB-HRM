<?php
    $current_page = 'online';
    $page_title = "Users";
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">

                    <div class="col-md-4">
                        <div class="card">
                            <div class="header">
                                <p class="text-info">
                                    <?php if($errors->any()): ?>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="info text-danger"><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                            
                                </p>
                                <h4 class="title">Create SubAmin User Account</h4>
                                <p class="category"></p>
                                 <?php if(session('status')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('create.account')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Full Name')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Full Name')); ?>" class="form-control <?php echo e($errors->has('fullname') ? ' is-invalid' : ''); ?>" name="fullname" value="<?php echo e(old('fullname')); ?>" required autofocus>
                                                <?php if($errors->has('fullname')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('fullname')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('User Name')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('User Name')); ?>" class="form-control <?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required autofocus>
                                                <?php if($errors->has('username')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('username')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Email')); ?></label>
                                                <input type="email" placeholder="<?php echo e(__('Email')); ?>" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                                <?php if($errors->has('email')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('User Type')); ?></label>
                                                <!-- <select name="usertype">
                                                    <option></option>
                                                    <option></option>
                                                    <option></option>
                                                </select> -->
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('User Type')); ?>" class="form-control <?php echo e($errors->has('usertype') ? ' is-invalid' : ''); ?>" name="usertype" value="SubAmin" required autofocus>
                                                <?php if($errors->has('usertype')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('usertype')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Photo')); ?></label>
                                                <input type="file" required="required" class="form-control" placeholder="<?php echo e(__('photo')); ?>" class="form-control <?php echo e($errors->has('photo') ? ' is-invalid' : ''); ?>" name="photo" value="<?php echo e(old('photo')); ?>"  autofocus>

                                                <?php if($errors->has('photo')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('photo')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('New Password')); ?></label>
                                                <input type="password" placeholder="<?php echo e(__('New Password')); ?>" class="form-control <?php echo e($errors->has('newpassword') ? ' is-invalid' : ''); ?>" name="newpassword" value="<?php echo e(old('newpassword')); ?>" required autofocus>
                                                <?php if($errors->has('newpassword')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('newpassword')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(__('Confirm New Password')); ?></label>
                                                <input type="password" placeholder="<?php echo e(__('Confirm New Password')); ?>" class="form-control <?php echo e($errors->has('confirmnewpassword') ? ' is-invalid' : ''); ?>" name="confirmnewpassword" value="<?php echo e(old('confirmnewpassword')); ?>" required autofocus>
                                                <?php if($errors->has('confirmnewpassword')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('confirmnewpassword')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>

                                    <button id="updateStaffbtnsubmit" type="submit" class="btn btn-success btn-fill pull-right">Add New Account</button>
                                    <div class="clearfix"></div>
                                </form>
                                <hr>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-md-6">
                                            <div class="btn-group">
                                                <?php if(\App\GenSettings::showEnable()): ?>
                                                    <button id="btn_enable_staff_update" class="btn btn-success btn-fill hidden"><i class="glyphicon glyphicon-info"></i> Enable Staff Update</button>

                                                    <button id="btn_disable_staff_update" class="btn btn-warning btn-fill "><i class="glyphicon glyphicon-info"></i> Disable Staff Update</button>
                                                <?php else: ?>
                                                    <button id="btn_enable_staff_update" class="btn btn-success btn-fill"><i class="glyphicon glyphicon-info"></i> Enable Staff Update</button>

                                                    <button id="btn_disable_staff_update" class="btn btn-warning btn-fill hidden"><i class="glyphicon glyphicon-info hidden"></i> Disable Staff Update</button>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                

                            </div>
                        </div>

                                
                    </div>

                    <div class="col-md-8">
                        <div class="row">
                            <h3 class="text-center">List Of Users Online </h3>
                        </div>
                        <div class="row">
                            <div class="content">
                                <div class="panel-group" id="accordion">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a title="Click Or Toggle To View List Of Users Online" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"> <strong>List Of Users Online</strong></a>
                                        </h4>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse in">
                                        <div class="panel-body">
                                            <p><h4>List Of Active Users Currently Online</h4>
                                                        <table id="usersonline_table" class="table table-bordered table-condensed">
                                                            <thead>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    <td>Name</td>
                                                                    <td>User-Status</td>
                                                                    <td>Level</td>
                                                                    <td>Status</td>
                                                                    <td>Last Seen</td>
                                                                    <td>Action</td>
                                                                </tr>
                                                            </thead>
                                                            <tfoot>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    <td>Name</td>
                                                                    <td>User-Status</td>
                                                                    <td>Level</td>
                                                                    <td>Status</td>
                                                                    <td>Last Seen</td>
                                                                    <td>Action</td>
                                                                </tr>
                                                            </tfoot>
                                                            <tbody id="usersonline_table_body">
                                                                <?php
                                                                    $count_id = 1;
                                                                ?>

                                                                <?php $__currentLoopData = $sessionlast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thisSession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                    <?php
                                                                        $thisVeryUser = \App\User::find($thisSession->user_id);
                                                                        $cT = \Carbon\Carbon::createFromTimestamp($thisSession->last_activity);
                                                                        $diff_in_minutes = $cT->diffInMinutes(\Carbon\Carbon::now());
                                                                    ?>
                                                                <?php if($diff_in_minutes <= 10): ?>
                                                                <tr>
                                                                    <td><?php echo e($count_id++); ?></td>
                                                                    <td><?php echo e($thisVeryUser->username); ?></td>
                                                                    <td><?php echo e($thisVeryUser->name); ?></td>
                                                                    <?php if($thisVeryUser->status == \App\User::$USER_ACCOUNT_STATUS_ENABLED): ?>
                                                                    <td><span class="label label-success">Enabled Account</span></td>
                                                                    <?php else: ?>
                                                                    <td><span class="label label-danger">Disabled Account</span></td>
                                                                    <?php endif; ?>
                                                                    <td><?php echo e(($thisVeryUser->access_level == \App\Staff::$USER_ADMIN) ? "ADMIN" : ( ($thisVeryUser->access_level == \App\Staff::$USER_SUBADMIN) ? "SUB-ADMIN" : ($thisVeryUser->access_level == \App\Staff::$USER_STAFF ? "STAFF" : "STAFF"))); ?></td>
                                                                    <td><span class="label label-success">Online (Active)</span></td>
                                                                    <td><?php echo e($thisVeryUser->isOnline()['last_activity']); ?></td>
                                                                    <td><form loguserout="yes"  action="<?php echo e(url('loguserout')); ?>" method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <input type="hidden" name="loguserout" value="<?php echo e($thisVeryUser->id); ?>" >
                                                                        <button class="btn btn-danger btn-sm btn-fill" href="">Logout User</button>
                                                                        </form>
                                                                    </td>
                                                                </tr>
                                                                <?php endif; ?>
                                                                <?php if($diff_in_minutes > 10 && $diff_in_minutes <= 30): ?>
                                                                <tr>
                                                                    <td><?php echo e($count_id++); ?></td>
                                                                    <td><?php echo e($thisVeryUser->username); ?></td>
                                                                    <td><?php echo e($thisVeryUser->name); ?></td>
                                                                    <?php if($thisVeryUser->status == \App\User::$USER_ACCOUNT_STATUS_ENABLED): ?>
                                                                    <td><span class="label label-success">Enabled Account</span></td>
                                                                    <?php else: ?>
                                                                    <td><span class="label label-danger">Disabled Account</span></td>
                                                                    <?php endif; ?>
                                                                    
                                                                    <td><?php echo e(($thisVeryUser->access_level == \App\Staff::$USER_ADMIN) ? "ADMIN" : ( ($thisVeryUser->access_level == \App\Staff::$USER_SUBADMIN) ? "SUB-ADMIN" : ($thisVeryUser->access_level == \App\Staff::$USER_STAFF ? "STAFF" : "STAFF"))); ?></td>
                                                                    <td><span class="label label-warning">Online (Inactive)</span></td>
                                                                    <td><?php echo e($thisVeryUser->isOnline()['last_activity']); ?></td>
                                                                     <td><form loguserout="yes" action="<?php echo e(url('loguserout')); ?>" method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <input type="hidden" name="loguserout" value="<?php echo e($thisVeryUser->id); ?>" >
                                                                        <button class="btn btn-danger btn-sm btn-fill" href="">Logout User</button>
                                                                        </form>
                                                                    </td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div class="row">
                            <h3 class="text-center">List Of Users</h3>
                        </div>
                        <div class="row">
                            <div class="content">
                                <div class="panel-group" id="accordion">
                                <?php
                                    $count_id = 1;
                                    $table_count = 1;
                                    $table_count_show = TRUE;
                                ?>

                                <span class="hidden" id="count_users_info"><?php echo e(count($users)); ?></span>

                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachUserH): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">

                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne<?php echo e($eachUserH->id); ?>"><?php echo e($eachUserH->id); ?>. <?php echo e($eachUserH->name); ?></a>
                                            <?php if($eachUserH->isOnline()['online']): ?>
                                                <span class="label label-success">Online</span>
                                            <?php else: ?>
                                                <span class="label label-warning">Offline</span>
                                            <?php endif; ?>
                                            
                                            <span class="label label-warning">Last Login: <?php echo e($eachUserH->lastLogin()); ?></span>

                                            <?php if($eachUserH->status == \App\User::$USER_ACCOUNT_STATUS_ENABLED): ?>
                                                <span class="label label-success btn-fill">Account Enabled</span>
                                            <?php else: ?>
                                                <span class="label label-danger btn-fill">Account Disabled</span>
                                            <?php endif; ?>
                                                <span class="label label-primary btn-fill"><?php echo e(($eachUserH->access_level == \App\Staff::$USER_ADMIN) ? "ADMIN" : ( ($eachUserH->access_level == \App\Staff::$USER_SUBADMIN) ? "SUB-ADMIN" : ($eachUserH->access_level == \App\Staff::$USER_STAFF ? "STAFF" : "STAFF"))); ?></span>

                                            <span class="pull-right">&nbsp;</span>
                                            <button <?php echo e($eachUserH->access_level == \App\Staff::$USER_ADMIN? '' : ''); ?> class="pull-right btn btn-xs btn-warning btn-fill" me_u="ad" user_id="<?php echo e($eachUserH->id); ?>" action="reset" >Reset Password</button>
                                            <span class="pull-right">&nbsp;</span>
                                            <?php if($eachUserH->status == \App\User::$USER_ACCOUNT_STATUS_DISABLED): ?>
                                                <button <?php echo e($eachUserH->access_level == \App\Staff::$USER_ADMIN? 'disabled="disabled"' : ''); ?> class="pull-right btn-xs btn btn-success btn-fill" me_u="ad" user_id="<?php echo e($eachUserH->id); ?>" action="enable" >Enable</button>
                                            <?php else: ?>
                                                <button <?php echo e($eachUserH->access_level == \App\Staff::$USER_ADMIN? 'disabled="disabled"' : ''); ?> class="pull-right btn btn-danger btn-fill btn-xs" me_u="ad" user_id="<?php echo e($eachUserH->id); ?>" action="disable" >Disable</button>
                                            <?php endif; ?>
                                            <span class="clearfix"></span>
                                        </h4>
                                    </div>
                                    
                                    <div id="collapseOne<?php echo e($eachUserH->id); ?>" class="panel-collapse collapse">
                                        <div class="panel-body">
                                            <p><h4>Your Account Login History For the Last 30 Days</h4>
                                                        <table id="<?php echo e("userloginhistory_".($table_count++)); ?>" class="table table-bordered table-condensed">
                                                            <thead>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    
                                                                    <td>Admin Initiated</td>
                                                                    <td>TYPE</td>
                                                                    <td>DATETIME</td>
                                                                    <td>LastTime</td>
                                                                    <td>IP-Address</td>
                                                                    <td>Browser</td>
                                                                    <td>Platform</td>
                                                                </tr>
                                                            </thead>
                                                            <tfoot>
                                                                <tr>
                                                                    <td>ID</td>
                                                                    <td>Username</td>
                                                                    
                                                                    <td>Admin Initiated</td>
                                                                    <td>TYPE</td>
                                                                    <td>DATETIME</td>
                                                                    <td>LastTime</td>
                                                                    <td>IP-Address</td>
                                                                    <td>Browser</td>
                                                                    <td>Platform</td>
                                                                </tr>
                                                            </tfoot>
                                                            <tbody>
                                                                <?php
                                                                    $count_id = 1;
                                                                    $thisVeryUserLoginHistory = $eachUserH->loginHistory();
                                                                ?>

                                                                <?php $__currentLoopData = $thisVeryUserLoginHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachLoginHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                
                                                                <tr>
                                                                    <td><?php echo e($count_id++); ?></td>
                                                                    <td><?php echo e($eachLoginHistory->username); ?></td>
                                                                    <td><?php echo e($eachLoginHistory->admin_id > 0 ? (\App\User::find($eachLoginHistory->admin_id)->name) : "NONE"); ?></td>
                                                                    <td><?php echo e(($eachLoginHistory->type == \App\LoginHistory::$LOGIN_TYPE) ? "LOGIN" : ( ($eachLoginHistory->type == \App\LoginHistory::$LOGOUT_TYPE) ? "LOGOUT" : ($eachLoginHistory->type == \App\LoginHistory::$LOGIN_ATTEMPT ? "LOGIN_ATTEMPT" : "UNKNOWN"))); ?></td>
                                                                    <td><?php echo e($c = new \Carbon\Carbon($eachLoginHistory->created_at)); ?></td>
                                                                    <td><?php echo e(($c = new \Carbon\Carbon($eachLoginHistory->created_at))->diffForHumans()); ?></td>
                                                                    <td><?php echo e($eachLoginHistory->ip); ?></td>
                                                                    <td><?php echo e($eachLoginHistory->browser); ?></td>
                                                                    <td><?php echo e($eachLoginHistory->platform); ?></td>
                                                                </tr>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </p>
                                        </div>
                                    </div>
                                </div>
                                    <?php
                                        $count_id = $count_id + 1;
                                    ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            </div>
                        </div>
                       <!-- <div class="card card-user">
                           <div class="image">
                               <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt="..."/>
                           </div>
                           <div class="content">
                               <div class="author">
                                    <a href="#">
                                   
                                          
                                   <?php if(Auth::user()->access_level == \App\Staff::$USER_STAFF): ?>
                                       <?php
                                           $thisStaff = \App\Staff::where('staffno', Auth::user()->username)->get()->first();
                                       ?>
                                       <img class="avatar border-gray" src="<?php echo e(\Storage::exists($thisStaff->photo)? url('/').\Storage::url($thisStaff->photo) : url('/').\Storage::url('defaultlogo.jpg')); ?>" alt="..."/>
                                   <?php elseif(Auth::user()->access_level == \App\Staff::$USER_SUBADMIN): ?>
                                       
                                       <img class="avatar border-gray" src="<?php echo e(asset('assets/img/default-avatar.png')); ?>" alt="..."/>
                                   <?php elseif(Auth::user()->access_level == \App\Staff::$USER_ADMIN): ?>
                                       <img class="avatar border-gray" src="<?php echo e(asset('assets/img/default-avatar.png')); ?>" alt="..."/>
                                   <?php endif; ?>
                                          
                                     <h4 class="title">Mike Andrew<br />
                                        <small>michael24</small>
                                     </h4>
                                   </a>
                               </div>
                               <p class="description text-center"> <?php echo e(Auth::user()->name); ?>

                               </p>
                           </div>
                           <hr>
                           <div class="text-center">
                           
                           </div>
                       </div> -->
                   </div>

                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>