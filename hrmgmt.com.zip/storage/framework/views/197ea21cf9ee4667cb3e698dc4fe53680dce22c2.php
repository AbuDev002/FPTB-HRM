<!DOCTYPE html>
<html lang="en">
	<head>
		<link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.ico')); ?> ">
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Website Title -->
		<title>Human Resource :: Federal Polytechnic Bauchi</title>

		<!-- Styles -->
		<link href="<?php echo e(asset('assets/hr-fptb/css/bootstrap.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('assets/hr-fptb/css/styles.css')); ?>" rel="stylesheet">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
		rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet"> 
	</head>
	<body data-spy="scroll" data-target=".fixed-top">

		<!-- Particles.js Container -->
		<div id="particles-js">
			<canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="1525" height="794"></canvas>
		</div>


	<!-- Header -->
		<header id="header">
			<!-- Logo And Details -->
			<div class="logo-and-details-wrapper">
				<div class="container">                
					<div class="col-md-9">
						<!-- Logo Text -->
						<a class="logo-txt text-left" href="<?php echo e(url('/')); ?>">
							Human Resource <br>
							<p class="p-under-header text-left ml-0 py-2 w-100">
								Federal Polytechnic Bauchi
							</p>
						</a>
					</div>
				</div>    
			</div> <!-- end of logo and details -->

			<div class="clearfix"></div>

			<!-- Header Content -->
			<div class="header-content">
				<div class="container">
					<div class="row">
						<a href="<?php echo e(url('/login')); ?>" class=" link mx-auto p-5 bg">
							<i class="material-icons">lock</i>
							<h3 class="title">Login</h3>
						</a>	
					</div>
				</div>
			</div> <!-- end of header content -->
		</header> 
		<!-- end of header -->


	<!-- Scripts -->
	<script src="<?php echo e(asset('assets/hr-fptb/js/jquery.js')); ?>"></script> <!-- jQuery - required by Bootstrap -->
	<script src="<?php echo e(asset('assets/hr-fptb/js/bootstrap.js')); ?>"></script> <!-- Bootstrap - front-end web framework -->
	</body>
</html>