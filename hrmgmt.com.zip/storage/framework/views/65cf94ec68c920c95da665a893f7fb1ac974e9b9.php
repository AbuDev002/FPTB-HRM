<?php
    $current_page = 'departmentunits';
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                        <?php if(isset($displaystate)): ?>
                            <?php if($displaystate == 'edit'): ?>
                            <div class="header">
                                <h4 class="title">Update Department Unit Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('units/'.$unit->id )); ?>" method="POST">

                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Department Unit')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Department Unit')); ?>" class="form-control <?php echo e($errors->has('unit') ? ' is-invalid' : ''); ?>" name="unit" value="<?php echo e(old('unit', $unit->unit)); ?>" required autofocus>
                                                <?php if($errors->has('unit')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('unit')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                                    
                                                    
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Department')); ?></label>

                                                <select type="text" placeholder="<?php echo e(__('Select Department')); ?>" class="form-control <?php echo e($errors->has('department') ? ' is-invalid' : ''); ?>" name="department" required autofocus>
                                                    <option value="">Select Department</option>


                                                    <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDeparment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachDeparment->id == $unit->getDepartment()->id): ?>
                                                            <option selected="selected" value="<?php echo e($eachDeparment->id); ?>"><?php echo e($eachDeparment->getDepartment("full")); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachDeparment->id); ?>"><?php echo e($eachDeparment->getDepartment('full')); ?></option>
                                                        <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                </select>
                                                <?php if($errors->has('department')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('department')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <a href="<?php echo e(url("units/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Department Unit Information</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php elseif($displaystate == 'delete'): ?>
                                <div class="header">
                                <h4 class="title text-danger">Delete Department Unit Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('unit/'.$unit->id )); ?>" method="POST">

                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Department Unit?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Unit')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('Unit')); ?>" class="form-control <?php echo e($errors->has('unit') ? ' is-invalid' : ''); ?>" name="unit" value="<?php echo e(old('unit', $unit->unit)); ?>" required autofocus>
                                                <?php if($errors->has('unit')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('unit')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Department')); ?></label>
                                                
                                                <select type="text" placeholder="<?php echo e(__('Select Department')); ?>" class="form-control <?php echo e($errors->has('department') ? ' is-invalid' : ''); ?>" name="department" required autofocus>
                                                    <option value="">Select Department</option>


                                                    <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDeparment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachDeparment->id == $unit->getDepartment()->id): ?>
                                                            <option selected="selected" value="<?php echo e($eachDeparment->id); ?>"><?php echo e($eachDeparment->getDepartment("full")); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachDeparment->id); ?>"><?php echo e($eachDeparment->getDepartment('full')); ?></option>
                                                        <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                </select>
                                                <?php if($errors->has('department')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('department')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("unit/create")); ?>" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE department</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php else: ?>
                                
                                <div class="header">
                                <h4 class="title">View Department Unit Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" >


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Unit')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('Unit')); ?>" class="form-control <?php echo e($errors->has('unit') ? ' is-invalid' : ''); ?>" name="unit" value="<?php echo e(old('unit', $unit->unit)); ?>" required autofocus>
                                                <?php if($errors->has('unit')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('unit')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Department')); ?></label>
                                                
                                                <select disabled="disabled" type="text" placeholder="<?php echo e(__('Select Department')); ?>" class="form-control <?php echo e($errors->has('department') ? ' is-invalid' : ''); ?>" name="department" required autofocus>
                                                    <option value="">Select Department</option>


                                                    <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDeparment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachDeparment->id == $unit->getDepartment()->id): ?>
                                                            <option selected="selected" value="<?php echo e($eachDeparment->id); ?>"><?php echo e($eachDeparment->getDepartment("full")); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachDeparment->id); ?>"><?php echo e($eachDeparment->getDepartment('full')); ?></option>
                                                        <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                </select>
                                                <?php if($errors->has('department')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('department')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <a href="<?php echo e(url("unit/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="<?php echo e(url("unit/{$unit->id}").'/edit'); ?>" class="btn btn-info btn-fill pull-right">Edit Department Information</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        <?php else: ?>
                            
                            <div class="header">
                                <h4 class="title">Add New Units</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('units.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Unit')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Unit')); ?>" class="form-control <?php echo e($errors->has('unit') ? ' is-invalid' : ''); ?>" name="unit" value="<?php echo e(old('unit')); ?>" required autofocus>
                                                <?php if($errors->has('unit')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('unit')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Department')); ?></label>
                                                <select type="text" placeholder="<?php echo e(__('Select Department')); ?>" class="form-control <?php echo e($errors->has('department') ? ' is-invalid' : ''); ?>" name="department" required autofocus>
                                                    <option value="">Select Department</option>
                                                    <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDeparment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($eachDeparment->id == old('department')): ?>
                                                            <option selected="selected" value="<?php echo e($eachDeparment->id); ?>"><?php echo e($eachDeparment->getDepartment('full')); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($eachDeparment->id); ?>"><?php echo e($eachDeparment->getDepartment('full')); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('department')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('department')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add New Units</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        <?php endif; ?>
                        </div>
                        <div> 
                            <?php 
                                $totalDeptUnitCount = \App\DepartmentUnit::count();

                            ?>

                            TOTAL DEPARTMENT Units IS: <?php echo e($totalDeptUnitCount); ?>


                            <script type="text/javascript">
                              document.title = "DEPARTMENT UNIT LISTING::TOTAL DEPARTMENT UNIT <?php echo e($totalDeptUnitCount); ?>";
                            </script>

                            <table id="stafftobepromoted" class="table table-bordered table-condensed">
                                <thead>
                                    <tr>
                                        <td>Unit</td>
                                        <td>Department</td>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <td>Unit</td>
                                        <td>Department</td>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php
                                        $allDeptUnits = \App\DepartmentUnit::all();
                                    ?>

                                    <?php $__currentLoopData = $allDeptUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDeptUnits): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                    <tr>
                                        <td><?php echo e($eachDeptUnits->unit); ?></td>
                                        <td><?php echo e($eachDeptUnits->getDepartment()->getDepartment('full')); ?></td>
                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Department Units Available</h4>
                                <p class="category">This is the list of All Department Units Available</p>
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>Units</th>
                                        <th>Department</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <?php

                                            if(!is_array($department) && !($department instanceof Countable)){
                                                $department = array($department);
                                            }

                                        ?>

                                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDeptUnits): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($eachDeptUnits->unit); ?></td>
                                            <td><?php echo e($eachDeptUnits->getDepartment()->getDepartment('full')); ?></td>
                                            <td>
                                                <a class="btn btn-sm btn-info" href="<?php echo e(url("units/$eachDeptUnits->id").'/edit'); ?>" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="<?php echo e(url("units/$eachDeptUnits->id")); ?>" >View</a>
                                                <a class="btn btn-sm btn-danger" href="<?php echo e(url("units/$eachDeptUnits->id?action=del")); ?>" >Delete</a>
                                            </td>
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>