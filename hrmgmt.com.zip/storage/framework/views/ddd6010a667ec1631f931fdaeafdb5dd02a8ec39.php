<?php
    $current_page = 'salaryscale';
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">

                            <?php if(isset($displaystate)): ?>
                            <?php if($displaystate == 'edit'): ?>
                                <div class="header">
                                <h4 class="title">Update Salary Scale Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('salaryscale/'.$this_salaryscale->id )); ?>" method="POST">

                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Salary Scale')); ?>" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?>" name="salaryscale" value="<?php echo e(old('salaryscale', $this_salaryscale->salaryscale)); ?>" required autofocus>
                                                <?php if($errors->has('salaryscale')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale Max Value')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Salary Scale Max Value. e.g 15')); ?>" class="form-control <?php echo e($errors->has('maxvalue') ? ' is-invalid' : ''); ?>" name="maxvalue" value="<?php echo e(old('description', $this_salaryscale->maxvalue )); ?>" autofocus>
                                                <?php if($errors->has('maxvalue')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('maxvalue')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("salaryscale/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Salary Scale Information</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php elseif($displaystate == 'delete'): ?>
                                <div class="header">
                                <h4 class="title text-danger">Delete Salary Scale Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('salaryscale/'.$this_salaryscale->id )); ?>" method="POST">

                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Salary Scale?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('Salary Scale')); ?>" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?>" name="salaryscale" value="<?php echo e(old('salaryscale', $this_salaryscale->salaryscale)); ?>" required autofocus>
                                                <?php if($errors->has('salaryscale')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale Max Value')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('maxvalue')); ?>" class="form-control <?php echo e($errors->has('maxvalue') ? ' is-invalid' : ''); ?>" name="maxvalue" value="<?php echo e(old('description', $this_salaryscale->maxvalue )); ?>" autofocus>
                                                <?php if($errors->has('maxvalue')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('maxvalue')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("salaryscale/create")); ?>" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE Salary Scale</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php else: ?>
                                
                                <div class="header">
                                <h4 class="title">View Salary Scale Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" >


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('Salary Scale')); ?>" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?>" name="salaryscale" value="<?php echo e(old('salaryscale', $this_salaryscale->salaryscale)); ?>" required autofocus>
                                                <?php if($errors->has('salaryscale')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Scale Max Value')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('Salary Scale Max Value')); ?>" class="form-control <?php echo e($errors->has('maxvalue') ? ' is-invalid' : ''); ?>" name="maxvalue" value="<?php echo e(old('maxvalue', $this_salaryscale->maxvalue )); ?>" autofocus>
                                                <?php if($errors->has('maxvalue')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('maxvalue')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <a href="<?php echo e(url("salaryscale/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="<?php echo e(url("salaryscale/{$this_salaryscale->id}").'/edit'); ?>" class="btn btn-info btn-fill pull-right">Edit Salary Scale Information</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        <?php else: ?>

                            <div class="header">
                                <h4 class="title">Add New Salary Scale</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('salaryscale.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Salary Scale')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Salary Scale')); ?>" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?>" name="salaryscale" value="<?php echo e(old('salaryscale')); ?>" required autofocus>
                                                <?php if($errors->has('salaryscale')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Scale Max Value')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Scale Max Value')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="maxvalue" value="<?php echo e(old('maxvalue')); ?>" required autofocus>
                                                <?php if($errors->has('description')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('maxvalue')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add New Salary Scale</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">All Salary Scale List</h4>
                                <p class="category">This is the list of Salary Scale that a staff must have have</p>
                                <?php if(session('salaryscale')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('salaryscale')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>Salary Scale</th>
                                        <th>Scale Max Value</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $salaryscale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSalaryScale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <tr>
                                            <td><?php echo e($eachSalaryScale->salaryscale); ?></td>
                                            <td><?php echo e("{$eachSalaryScale->maxvalue}"); ?></td>
                                            <td>
                                                <a class="btn btn-sm btn-info" href="<?php echo e(url("salaryscale/$eachSalaryScale->id").'/edit'); ?>" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="<?php echo e(url("salaryscale/$eachSalaryScale->id")); ?>" >View</a>
                                                <a class="btn btn-sm btn-danger" href="<?php echo e(url("salaryscale/$eachSalaryScale->id?action=del")); ?>" >Delete</a>
                                            </td>
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>