<?php $__env->startSection('content'); ?>

<div class="row">

            <div class="col-sm-12">
                <div class="login-card card-block">
                    <form method="POST" action="<?php echo e(route('login')); ?>"  class="md-float-material">
                        <?php echo csrf_field(); ?>
                        <div class="text-center">
                            
                            <h1 class="text-primary"><?php echo e(__('H-R Management App.')); ?></h1>
                        </div>
                        <h3 class="text-center txt-primary">
                            <?php echo e(__('Sign In to your account')); ?>

                        </h3>
                        <div class="md-input-wrapper">
                            <input id="username" type="text" class="md-form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required autofocus />
                            <label><?php echo e(__('Username/Staff Number')); ?></label>
                            <?php if($errors->has('username')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="md-input-wrapper">
                            <input id="password" type="password" class="md-form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            <label><?php echo e(__('Password')); ?></label>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-xs-12">
                            <div class="rkmd-checkbox checkbox-rotate checkbox-ripple m-b-25">
                                <label class="input-checkbox checkbox-primary">
                                    <input type="checkbox" id="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                    <span class="checkbox"></span>
                                </label>
                                <div class="captions"><?php echo e(__('Remember Me')); ?></div>

                            </div>
                                </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-xs-10 offset-xs-1">
                                <button type="submit" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20"><?php echo e(__('Login')); ?></button>
                            </div>
                        </div>
                        <!-- <div class="card-footer"> -->
                        <!-- <div class="col-sm-12 col-xs-12 text-center">
                            <span class="text-muted">Don't have an account?</span>
                            <a href="register2.html" class="f-w-600 p-l-5">Sign up Now</a>
                        </div> -->

                        <!-- </div> -->
                    </form>
                    <!-- end of form -->
                </div>
                <!-- end of login-card -->
            </div>
            <!-- end of col-sm-12 -->
        </div>
        <!-- end of row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appbase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>