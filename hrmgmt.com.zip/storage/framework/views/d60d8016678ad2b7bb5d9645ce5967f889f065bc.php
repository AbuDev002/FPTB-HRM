<?php
    $current_page = 'status';
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">

                            <?php if(isset($displaystate)): ?>
                            <?php if($displaystate == 'edit'): ?>
                                <div class="header">
                                <h4 class="title">Update Status Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('status/'.$status->first()->id )); ?>" method="POST">

                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Status')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Status')); ?>" class="form-control <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" name="status" value="<?php echo e(old('status', $status->first()->status)); ?>" required autofocus>
                                                <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Status Description')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $status->first()->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("status/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Status Information</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php elseif($displaystate == 'delete'): ?>
                                <div class="header">
                                <h4 class="title text-danger">Delete Status Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('status/'.$status->first()->id )); ?>" method="POST">

                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Status?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Status')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('Status')); ?>" class="form-control <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" name="status" value="<?php echo e(old('status', $status->first()->status)); ?>" required autofocus>
                                                <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Status Description')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $status->first()->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("status/create")); ?>" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE Status</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php else: ?>
                                
                                <div class="header">
                                <h4 class="title">View Status Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" >


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Status')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('Status')); ?>" class="form-control <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" name="status" value="<?php echo e(old('status', $status->first()->status)); ?>" required autofocus>
                                                <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Description')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $status->first()->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <a href="<?php echo e(url("status/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="<?php echo e(url("status/{$status->first()->id}").'/edit'); ?>" class="btn btn-info btn-fill pull-right">Edit Status Information</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        <?php else: ?>

                            <div class="header">
                                <h4 class="title">Add New Status</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('status.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Status')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Status')); ?>" class="form-control <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" name="status" value="<?php echo e(old('status')); ?>" required autofocus>
                                                <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Status Description')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('status description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description')); ?>" required autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add New Status</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">All Status List</h4>
                                <p class="category">This is the list of Status that anyone can have</p>
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>Status</th>
                                        <th>Status Description(If Any need)</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($eachStatus->status); ?></td>
                                            <td><?php echo e("{$eachStatus->description}"); ?></td>
                                            <td>
                                                <a class="btn btn-sm btn-info" href="<?php echo e(url("status/$eachStatus->id").'/edit'); ?>" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="<?php echo e(url("status/$eachStatus->id")); ?>" >View</a>
                                                <a class="btn btn-sm btn-danger" href="<?php echo e(url("status/$eachStatus->id?action=del")); ?>" >Delete</a>
                                            </td>
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>