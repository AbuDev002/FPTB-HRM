
<?php if($show_dc_print): ?>
    <div class="col-12">
                                            <input type="hidden" name="this_staff" id="this_staff_id" value="<?php echo e($thisStaff->id); ?>">
                                            <table class="table table-bordered">
                                                <tr>
                                                    <td><div class="form-group">
                                                            <img class="img-thumbnail" src="<?php echo e(Storage::url($thisStaff->photo)); ?>" width="100px" height="100px">
                                                        </div></td>
                                                    <td><?php echo e($thisStaff->getFullName()); ?></td>
                                                    <td>Department: <?php echo e($thisStaff->getDepartment()); ?></td>
                                                    <td>State: <?php echo e($thisStaff->getDetails()['state']); ?></td>
                                                    <td>Local Govt:  <?php echo e($thisStaff->getDetails()['lga']); ?></td>
                                                    <td>Date Of Birth: <?php echo e($thisStaff->dateobirth); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Condolence Message:</td>
                                                    <td colspan="5">
                                                        <?php
                                                            $condolence_msg = \App\CondolenceMessage::where('staff_id', $thisStaff->id)->first();
                                                        ?>
                                                        <?php if(!is_null($condolence_msg)): ?>
                                                            <textarea name="cond_comment" id="cond_comment" class="form-control"
                                                                              rows="5"><?php echo e(\App\CondolenceMessage::where('staff_id', $thisStaff->id)->first()->condolence); ?></textarea>
                                                        <?php else: ?>
                                                            <textarea name="cond_comment" id="cond_comment" class="form-control"
                                                                              rows="5"></textarea>
                                                        <?php endif; ?>
                                                                          </td>

                                                </tr>
                                            </table>
                                        </div>
<?php else: ?>

<form id="btn_basic_update_form" enctype="multipart/form-data" action="<?php echo e(url('staff/'.$thisStaff->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("PUT"); ?>

                                    <input type="hidden" name="this_staff" value="<?php echo e($thisStaff->id); ?>">

                                    <div class="row">
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <img class="img-thumbnail" src="<?php echo e(Storage::url($thisStaff->photo)); ?>" width="100px" height="100px">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Staff No (PFN)')); ?></label>
                                                <span id="staffnocheckokmessage"class="hide text-success">Staff No - Available (good!)</span>
                                                <span id="staffnocheckbadmessage" class="hide text-danger">Staff No - Unavailable (try again)</span>
                                                <input readonly="readonly" id="staffnocheck_" type="text" class="form-control control" placeholder="<?php echo e(__('staffno (PFN)')); ?>" class="form-control <?php echo e($errors->has('staffno') ? ' is-invalid' : ''); ?>" name="staffno" value="<?php echo e(old('staffno', $thisStaff->staffno)); ?>"  required="required" autofocus>

                                                <?php if($errors->has('staffno')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffno')); ?></strong>
                                                        </span>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('FirstName')); ?></label>
                                                <input id="firstname_input" type="text" placeholder="<?php echo e(__('FirstName')); ?>" class="form-control <?php echo e($errors->has('firstname') ? ' is-invalid' : ''); ?>" name="firstname" value="<?php echo e(old('firstname', $thisStaff->fname)); ?>" required autofocus>
                                                <?php if($errors->has('firstname')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('firstname')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('LastName')); ?></label>
                                                <input id="lastname_input" type="text" placeholder="<?php echo e(__('LastName')); ?>" class="form-control <?php echo e($errors->has('lastname') ? ' is-invalid' : ''); ?>" name="lastname" value="<?php echo e(old('lastname', $thisStaff->lname)); ?>" required autofocus>
                                                <?php if($errors->has('lastname')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('lastname')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('OtherName')); ?></label>
                                                <input id="othername_input" type="text" placeholder="<?php echo e(__('OtherName')); ?>" class="form-control <?php echo e($errors->has('othername') ? ' is-invalid' : ''); ?>" name="othername" value="<?php echo e(old('othername', $thisStaff->oname)); ?>"  autofocus>
                                                <?php if($errors->has('othername')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('othername')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Gender')); ?></label>
                                                <select id="gender_input" name="gender" class="form-control" required="required">
                                                    <option <?php echo e(old('gender', $thisStaff->gender) == "M" ? 'selected="selected"' : ''); ?> value="M"><?php echo e(__('Male')); ?></option>
                                                    <option <?php echo e(old('gender', $thisStaff->gender) == "F" ? 'selected="selected"' : ''); ?>  value="F"><?php echo e(__('Female')); ?></option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('Marital Status')); ?></label>
                                                <select id="maritalstatus" class="form-control <?php echo e($errors->has('maritalstatus') ? ' is-invalid' : ''); ?> " name="maritalstatus" required>

                                                    <option <?php echo e(old('maritalstatus', $thisStaff->maritalstatus)=="M"? 'selected="selected"' : ''); ?> value="M" >Married</option>
                                                    <option <?php echo e(old('maritalstatus', $thisStaff->maritalstatus) =="S"? 'selected="selected"' : ''); ?> value="S" >Single</option>

                                                </select>
                                                <?php if($errors->has('maritalstatus')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('maritalstatus')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('PhoneNo')); ?></label>
                                                <input id="phoneno_input" type="text" placeholder="<?php echo e(__('PhoneNo')); ?>" class="form-control <?php echo e($errors->has('phoneno') ? ' is-invalid' : ''); ?>" name="phoneno" value="<?php echo e(old('phoneno', $thisStaff->phoneno)); ?>"  autofocus>
                                                <?php if($errors->has('phoneno')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('phoneno')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('Email')); ?></label>
                                                <input id="email_input" type="email" placeholder="<?php echo e(__('Email')); ?>" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email', $thisStaff->email)); ?>"  autofocus>
                                                <?php if($errors->has('email')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('DateOfBirth')); ?></label>
                                                <input id="dateobirth_input" type="date" class="form-control" placeholder="<?php echo e(__('dateobirth')); ?>" class="form-control <?php echo e($errors->has('dateobirth') ? ' is-invalid' : ''); ?>" name="dateobirth" value="<?php echo e(old('dateobirth', $thisStaff->dateobirth)); ?>" required="required"  autofocus>

                                                <?php if($errors->has('dateobirth')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('dateobirth')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('Photo')); ?></label>
                                                <input id="photo_input" type="file" class="form-control" placeholder="<?php echo e(__('photo')); ?>" class="form-control <?php echo e($errors->has('photo') ? ' is-invalid' : ''); ?>" name="photo" value="<?php echo e(old('photo')); ?>"  autofocus>

                                                <?php if($errors->has('photo')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('photo')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <textarea name="address1" class="form-control" placeholder="Address 1" required="required" ><?php echo e(old('address1', $thisStaff->address1)); ?></textarea>
                                                <?php if($errors->has('address1')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('address1')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-4 col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('State')); ?></label>
                                                <select id="state" name="state" class="form-control" required="required">
                                                    <option value="">Select State Of Origin</option>
                                                    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachState): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option <?php echo e(old('state', $thisStaff->state_id)==$eachState->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachState->id); ?>" ><?php echo e($eachState->state); ?></option>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-4 col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('Lga')); ?></label>
                                                <select id="lga" name="lga" class="form-control" required="required">
                                                    <option value="">Select Local Government</option>
                                                    <?php $__currentLoopData = $lga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachLga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(old('lga', $thisStaff->lga_id)==$eachLga->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachLga->id); ?>" ><?php echo e($eachLga->lga); ?></option>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label><?php echo e(__('GPZone')); ?></label>
                                                <select id="gpzone_select" class="form-control <?php echo e($errors->has('gpzone') ? ' is-invalid' : ''); ?> " name="gpzone" required>

                                                    <?php $__currentLoopData = $gpzone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachGPZone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(old('gpzone', $thisStaff->gpzone)==$eachGPZone->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachGPZone->id); ?>"><?php echo e($eachGPZone->gpzone); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                </select>
                                                <?php if($errors->has('gpzone')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('gpzone')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>


                                    </div>
                                    <hr>
                                    <div class="row" >
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokfname"><?php echo e(__('Next Of Kin First Name')); ?></label>
                                                <input id="nokfname_input" class="form-control" placeholder="Next Of Kin First Name" type="text" name="nokfname" value="<?php echo e($thisStaff->nok_fname); ?>" required="required">
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="noklname"><?php echo e(__('Next Of Kin Last Name')); ?></label>
                                                <input id="noklname_input" class="form-control" placeholder="Next Of Kin Last Name" type="text" name="noklname" value="<?php echo e($thisStaff->nok_lname); ?>" required="required">
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokoname"><?php echo e(__('Next Of Kin Other Name')); ?></label>
                                                <input id="nokoname_input" class="form-control" placeholder="Next Of Kin Other Name" type="text" name="nokoname" value="<?php echo e($thisStaff->nok_oname); ?>" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" >
                                         <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokaddress"><?php echo e(__('Next Of Kin Address')); ?></label>
                                                <textarea id="nokaddress_input" class="form-control" required name="nokaddress" placeholder="Enter Next Of Kin Address" ><?php echo e($thisStaff->nok_address); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokphoneno"><?php echo e(__('Next Of Kin Phone No')); ?></label>
                                                <input id="nokphoneno_input" type="text" class="form-control" required="required" name="nokphoneno" value="<?php echo e($thisStaff->nok_phoneno); ?>" placeholder="Enter Next Of Kin PhoneNo" />
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nokrelationship"><?php echo e(__('Relationship With Next Of Kin')); ?></label>
                                                <input id="nok_relationship_input" type="text" class="form-control" required="required" name="nokrelationship" value="<?php echo e($thisStaff->nok_relationship); ?>" placeholder="Enter Next Of Kin Relationship">
                                                </textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div id="childsection1_div" class="row" style="border-bottom: 2px solid #eee" >
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nameofchild1"><?php echo e(__('Child\'s Name  (If Any)')); ?></label>
                                                <input id="nameofchild1_input" type="text" name="nameofchild1" placeholder="Name of Child (If Any)" class="form-control" value="<?php echo e(old('nameofchild1', $thisStaff->child1_name )); ?>" >
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2" style="border-right: 2px solid #eee">
                                            <div class="form-group">
                                                <label for="ageofchild1"><?php echo e(__('Child\'s Age')); ?></label>
                                                <input id="ageofchild1_input" type="number" name="ageofchild1" placeholder="Age of Child" class="form-control"  value="<?php echo e(old('ageofchild1', $thisStaff->child1_age )); ?>" >
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nameofchild2"><?php echo e(__('Child\'s Name  (If Any)')); ?></label>
                                                <input id="nameofchild2_input" type="text" name="nameofchild2" placeholder="Name of Child (If Any)" class="form-control"  value="<?php echo e(old('ageofchild2', $thisStaff->child2_name )); ?>" >
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2">
                                            <div class="form-group">
                                                <label for="ageofchild2"><?php echo e(__('Child\'s Age')); ?></label>
                                                <input id="ageofchild2_input" type="number" name="ageofchild2" placeholder="Age of Child" class="form-control"  value="<?php echo e(old('ageofchild3', $thisStaff->child2_age)); ?>" >
                                            </div>
                                        </div>

                                    </div>
                                    <div id="childsection2_div" class="row">
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group bor">
                                                <label for="nameofchild3"><?php echo e(__('Child\'s Name  (If Any)')); ?></label>
                                                <input id="nameofchild3_input" type="text" name="nameofchild3" placeholder="Name of Child (If Any)" class="form-control"  value="<?php echo e(old('nameofchild3', $thisStaff->child3_name)); ?>" >
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2" style="border-right: 2px solid #eee">
                                            <div class="form-group">
                                                <label for="ageofchild3"><?php echo e(__('Child\'s Age')); ?></label>
                                                <input id="ageofchild3_input" type="number" name="ageofchild3" placeholder="Age of Child" class="form-control"  value="<?php echo e(old('ageofchild3', $thisStaff->child3_age)); ?>" >
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-4">
                                            <div class="form-group">
                                                <label for="nameofchild4"><?php echo e(__('Child\'s Name  (If Any)')); ?></label>
                                                <input id="nameofchild4_input" type="text" name="nameofchild4" placeholder="Name of Child (If Any)" class="form-control"  value="<?php echo e(old('nameofchild4', $thisStaff->child4_name)); ?>" >
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-md-2">
                                            <div class="form-group">
                                                <label for="ageofchild4"><?php echo e(__('Child\'s Age')); ?></label>
                                                <input id="ageofchild4_input" type="number" name="ageofchild4" placeholder="Age of Child" class="form-control"  value="<?php echo e(old('ageofchild4', $thisStaff->child4_age)); ?>" >
                                            </div>
                                        </div>

                                    </div>

                                    <button id="staff_basic_update_btn" type="submit" disabled="disabled" class="btn btn-success btn-fill pull-right">Update Staff Basic Information</button>
                                    <div class="clearfix"></div>

                                </form>

                                <form id="staff_school_dept_update_form" action="<?php echo e(url('staff_dept_info')); ?>" method="POST" >
                                    <hr id="childsection2_hr" class="">

                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="this_staff" value="<?php echo e($thisStaff->id); ?>">

                                    <div class="row">
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('First Appointment Date')); ?></label>
                                                <input id="firstappointdate_input" type="date" class="form-control" placeholder="<?php echo e(__('First Appointment Date')); ?>" class="form-control <?php echo e($errors->has('firstappointdate') ? ' is-invalid' : ''); ?>" name="firstappointdate" value="<?php echo e(old('firstappointdate', $thisStaff->firstappointdate)); ?>"  required="required"  autofocus>

                                                <?php if($errors->has('firstappointdate')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('firstappointdate')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>


                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('School')); ?></label>
                                                <select id="school" class="form-control <?php echo e($errors->has('school') ? ' is-invalid' : ''); ?> " name="school" required>
                                                    <option selected="selected" >Select School</option>
                                                    <?php $__currentLoopData = $school; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSchool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option <?php echo e(old('school', $staffdepartment->school)==$eachSchool->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachSchool->id); ?>" ><?php echo e($eachSchool->school); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php if($errors->has('school')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('school')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Department')); ?></label>

                                                <select id="department" class="form-control <?php echo e($errors->has('department') ? ' is-invalid' : ''); ?> " name="department" required>
                                                    <option value="" >Select Department</option>

                                                    <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option <?php echo e(old('department', $staffdepartment->dept_id)==$eachDepartment->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachDepartment->id); ?>" ><?php echo e($eachDepartment->department); ?> <?php echo e($eachDepartment->description); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>

                                                <?php if($errors->has('department')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('department')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Department Unit')); ?></label>
                                                <?php
                                                    if(is_null($staffdepartmentunit)){
                                                        $staffdepartmentunit_id = '';
                                                    }else{
                                                        $staffdepartmentunit_id = $staffdepartmentunit->unit_id;
                                                    }
                                                ?>
                                                
                                                
                                                <select id="departmentunit" class="form-control <?php echo e($errors->has('departmentunit') ? ' is-invalid' : ''); ?> " name="departmentunit" required>
                                                    <option value="" >Select Department Unit</option>
                                                    <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option <?php echo e(old('departmentunit', $staffdepartmentunit_id)==$eachUnit->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachUnit->id); ?>" ><?php echo e($eachUnit->unit); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php if($errors->has('departmentunit')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('departmentunit')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                <button id="staff_school_dept_update_btn" type="submit" disabled="disabled" class="btn btn-success btn-fill pull-right">Update Staff Dept Information</button>
                                    <div class="clearfix"></div>
                                <hr>
                                </form>

                                <form id="staff_level_form" action="<?php echo e(url('staff_level_info')); ?>" method="POST">

                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="this_staff" value="<?php echo e($thisStaff->id); ?>">

                                    <div class="row">

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Present Appointment Date')); ?></label>
                                                <input id="presentappointdate_input" type="date" class="form-control" placeholder="<?php echo e(__('Present Appointment Date')); ?>" class="form-control <?php echo e($errors->has('presentappointdate') ? ' is-invalid' : ''); ?>" name="presentappointdate" value="<?php echo e(old('presentappointdate', $currentPromotion->presentappointdate)); ?>" required="required"  autofocus>

                                                <?php if($errors->has('presentappointdate')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('presentappointdate')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Appointment Type')); ?></label>
                                                <select id="appointmenttype_input" class="form-control <?php echo e($errors->has('appointmenttype') ? ' is-invalid' : ''); ?> " name="appointmenttype" required>
                                                    <?php $__currentLoopData = $appointmenttype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anAppointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(old('appointmenttype', $currentPromotion->appointmenttype)==$anAppointment->id? 'selected="selected"' : ''); ?>  value="<?php echo e($anAppointment->id); ?>"><?php echo e($anAppointment->appointmenttype); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php if($errors->has('appointmenttype')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('appointmenttype')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>


                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Position (If Any)')); ?></label>
                                                    <select id="position_input" class="form-control <?php echo e($errors->has('position') ? ' is-invalid' : ''); ?> " name="position" required>

                                                            <option value="0">None</option>
                                                        <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachPosition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option <?php echo e(old('position', $currentPromotion->position)==$eachPosition->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachPosition->id); ?>"><?php echo e($eachPosition->position); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>

                                                <?php if($errors->has('position')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('position')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        

                                        <div class="col-sm-3 col-md-3">
                                            <div class="hidden form-group">
                                                <label><?php echo e(__('Added Responsibilites (If Any)')); ?></label>
                                                    <select multiple="multiple" class="form-control <?php echo e($errors->has('additional_responsibility') ? ' is-invalid' : ''); ?> " name="additional_responsibility[]" required>

                                                            <option value="">Select Position</option>
                                                        <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachPosition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <?php if(empty($thisStaff->getDetails()['addedresponsibilitiesarray']) && $eachPosition->id == \App\Staff::$NONE_ADDED_RESPONSIBLITY): ?>
                                                                
                                                                <option selected="selected" value="<?php echo e($eachPosition->id); ?>"><?php echo e($eachPosition->position); ?></option>                                                                
                                                            <?php else: ?>

                                                            <option <?php echo e(in_array($eachPosition->id, $thisStaff->getDetails()['addedresponsibilitiesarray'] ) ? 'selected="selected"' : ''); ?> value="<?php echo e($eachPosition->id); ?>"><?php echo e($eachPosition->position); ?></option>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>

                                                <?php if($errors->has('additional_responsibility[]')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('additional_responsibility[]')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">

                                        <div class="col-sm-3 col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Staff Class')); ?></label>
                                                <select id="staffclass" class="form-control <?php echo e($errors->has('staffclass') ? ' is-invalid' : ''); ?> " name="staffclass" required>
                                                    <option selected="selected" >Select Staff Class</option>
                                                    <option <?php echo e(old('staffclass', $currentPromotion->staffclass) == "AS"? 'selected="selected"' : ''); ?> value="AS">Academic Staff</option>
                                                    <option  <?php echo e(old('staffclass', $currentPromotion->staffclass) == "NA"? 'selected="selected"' : ''); ?>  value="NA">Non-Academic Staff</option>
                                                </select>

                                                <?php if($errors->has('staffclass')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('staffclass')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div id="salaryscale___parent" class="col-sm-3 col-md-3">
                                            <div id="salaryscale" class="form-group">
                                                <label id="con_label"><?php echo e(__('Salary Scale')); ?></label>
                                                <select id="salaryscale_select" class="form-control <?php echo e($errors->has('salaryscale') ? ' is-invalid' : ''); ?> " name="salaryscale" required>
                                                    <option value="">Select Salary Scale...</option>
                                                    <?php $__currentLoopData = $salaryscale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSalaryScale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(old('salaryscale', $currentPromotion->salary_scale)==$eachSalaryScale->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachSalaryScale->id); ?>" ><?php echo e($eachSalaryScale->salaryscale); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                                <?php if($errors->has('salaryscale')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscale')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div id="salaryscalevalue___parent" class="col-sm-3 col-md-3">
                                            <div id="salaryscalevalue" class="form-group">
                                                <label id="con_label"><?php echo e(__('Salary Scale Value')); ?></label>
                                                <select id="salaryscalevalue_select" class="form-control <?php echo e($errors->has('salaryscalevalue') ? ' is-invalid' : ''); ?> " name="salaryscalevalue" required>
                                                    <?php
                                                    $thisSalaryScale = \App\SalaryScale::find($currentPromotion->salary_scale);
                                                    if($currentPromotion->salary_scale_value  > 0) {
                                                        $salary_values = '<option value="">Select Salary Scale (' . $thisSalaryScale->salaryscale . ') Value ...</option>';
                                                        for($i = 1; $i <= $thisSalaryScale->maxvalue; $i++){
                                                            if($i == $currentPromotion->salary_scale_value)
                                                                $salary_values .= '<option selected="selected" value="' . $i . '">' . $i . '</option>';
                                                            else
                                                                $salary_values .= '<option value="' . $i . '">' . $i . '</option>';
                                                        }
                                                    }else {
                                                        $salary_values = '<option value="">Select Salary Scale Value ...</option>';
                                                    }

                                                    echo $salary_values;

                                                    ?>

                                                </select>
                                                <?php if($errors->has('salaryscalevalue')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('salaryscalevalue')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                       

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Category')); ?></label>
                                                <select id="category_input" class="form-control <?php echo e($errors->has('category') ? ' is-invalid' : ''); ?> " name="category" required>
                                                    <option <?php echo e(old('category', $currentPromotion->category) =="JS"? 'selected="selected"' : ''); ?> value="JS" >Junior Staff</option>
                                                    <option <?php echo e(old('category', $currentPromotion->category)=="SS"? 'selected="selected"' : ''); ?> value="SS" >Senior Staff</option>
                                                </select>

                                                <?php if($errors->has('category')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('category')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label><?php echo e(__('Rank')); ?></label>
                                                <select id="rank" class="form-control <?php echo e($errors->has('rank') ? ' is-invalid' : ''); ?> " name="rank" required>
                                                        <option value="">Select Staff Rank</option>
                                                         <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachRank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option <?php echo e(old('rank', $currentPromotion->rank)==$eachRank->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachRank->id); ?>"><?php echo e($eachRank->rank); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                                <?php if($errors->has('rank')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('rank')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Step')); ?></label>

                                                    <select id="step_select" class="form-control <?php echo e($errors->has('step') ? ' is-invalid' : ''); ?> " name="step" required>

                                                    <?php for($i = 1; $i <= 50; $i++): ?>
                                                        <option <?php echo e(old('step', $currentPromotion->step)=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>

                                                <?php if($errors->has('step')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('step')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>
                                    <button id="staff_level_update_btn" type="submit" disabled="disabled" class="btn btn-success btn-fill pull-right">Update Staff Level Info</button>
                                    <div class="clearfix"></div>
                                </form>

                                <hr>
                                <form id="staff_status_form" action="<?php echo e(url('staff_status')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="this_staff" value="<?php echo e($thisStaff->id); ?>">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(__('Status')); ?></label>
                                                <select id="staff_status" class="form-control <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?> " name="status" required>
                                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(old('status', $thisStaff->status)==$eachStatus->id? 'selected="selected"' : ''); ?> value="<?php echo e($eachStatus->id); ?>"><?php echo e($eachStatus->status); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div><br/>
                                        <button disabled="disabled" title="Please Click To Effect Staff Status Change" id="btnstaff_status" type="submit" class="btn btn-success btn-fill pull-left">Change Staff Status</button>

                                        <?php if($currentPromotion->last_promotion_status == \App\Promotions::$IS_LAST_PROMOTED): ?>
                                            &nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(url('setlastpromotion') . '?staff_id=' . $thisStaff->id); ?>" class="btn btn-warning btn-fill " id="btnstaff_last_promotion" >De-Activate "Can't Be Promoted"</a> &nbsp; &nbsp; &nbsp; <span class="alert alert-danger alert-lg">Status: Staff Cannot Be Promoted</span>
                                        <?php else: ?>
                                            &nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(url('setlastpromotion') . '?staff_id=' . $thisStaff->id); ?>" class="btn btn-warning btn-fill " id="btnstaff_last_promotion" >Activate "Can't Be Promoted"</a>
                                            &nbsp; &nbsp; &nbsp; <span class="alert alert-info alert-lg">Status: Staff Can Be Promoted</span>

                                        <?php endif; ?>
                                    <div class="clearfix"></div>


                                    </div>
                                </form>
                                <?php if($thisStaff->status == \App\Status::where('status', 'DECEASED')->first()->id): ?>
                                <form id="staff_status_form" action="<?php echo e(url('staff_status')); ?>" method="GET">
                                        <div class="col-12">
                                            <input type="hidden" name="this_staff" id="this_staff_id" value="<?php echo e($thisStaff->id); ?>">
                                            <table class="table table-bordered">
                                                <tr>
                                                    <td><div class="form-group">
                                                            <img class="img-thumbnail" src="<?php echo e(Storage::url($thisStaff->photo)); ?>" width="100px" height="100px">
                                                        </div></td>
                                                    <td><?php echo e($thisStaff->getFullName()); ?></td>
                                                    <td>Department: <?php echo e($thisStaff->getDepartment()); ?></td>
                                                    <td>State: <?php echo e($thisStaff->getDetails()['state']); ?></td>
                                                    <td>Local Govt:  <?php echo e($thisStaff->getDetails()['lga']); ?></td>
                                                    <td>Date Of Birth: <?php echo e($thisStaff->dateobirth); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Condolence Message:</td>
                                                    <td colspan="4">
                                                        <?php
                                                            $condolence_msg = \App\CondolenceMessage::where('staff_id', $thisStaff->id)->first();
                                                        ?>
                                                        <?php if(!is_null($condolence_msg)): ?>
                                                            
                                                        <textarea name="cond_comment" id="cond_comment" class="form-control"
                                                                              rows="5"><?php echo e(\App\CondolenceMessage::where('staff_id', $thisStaff->id)->first()->condolence); ?></textarea>
                                                        <?php else: ?>
                                                            <textarea name="cond_comment" id="cond_comment" class="form-control"
                                                                              rows="5"></textarea>
                                                        <?php endif; ?>
                                                                          </td>
                                                    <td><a onclick="preventDefault()" class="btn btn-success btn-fill" id="btn_comment_update">Save</a>&nbsp;&nbsp;<a href="<?php echo e(url('/staff/'.$thisStaff->id.'/edit?act=dcprint')); ?>" class="btn btn-primary btn-fill" id="btn_comment_update">SavePrint</a></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </form>
                                    <?php endif; ?>


                                <form id="qualification_form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('staff_qualification')); ?>">

                                            <hr style="border: 1px solid grey;" />
                                            <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="POST" id="qualification_form_method">
                                    <input type="hidden" name="this_staff" value="<?php echo e($thisStaff->id); ?>" id="this_staff">

                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend  title="#qualification" class="title">Qualification [APPROVED]</legend>
                                            <table class="table table-responsive tab-content">
                                                <thead>
                                                    <tr>
                                                        <td>ID</td>
                                                        <td>Q-TYPE</td>
                                                        <td>QUALIFICATION-TITLE</td>
                                                        <td>QUALIFICATION-DESCRIPTION</td>
                                                        <td>REGISTERED PROFESSIONAL BODY</td>
                                                        <td>STATUS</td>
                                                        <td>ACTION</td>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                       <td>ID</td>
                                                       <td>Q-TYPE</td>
                                                       <td>QUALIFICATION-TITLE</td>
                                                       <td>QUALIFICATION-DESCRIPTION</td>
                                                       <td>REGISTERED PROFESSIONAL BODY</td>
                                                       <td>STATUS</td>
                                                       <td>ACTION</td>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php ($countSN = 1); ?>
                                                    <?php $__currentLoopData = $staffExtras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStaffExtra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS ): ?>
                                                        <tr>
                                                            <td><?php echo e($countSN++); ?></td>
                                                            <td><?php echo e($eachStaffExtra->qualificationtype); ?></td>
                                                            <td><?php echo e($eachStaffExtra->title); ?></td>
                                                            <td><?php echo e($eachStaffExtra->description); ?></td>
                                                            <td><?php echo e($eachStaffExtra->registeredprobody); ?></td>
                                                            <td id="staffextras_td<?php echo e($eachStaffExtra->id); ?>" >
                                                            <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-success">approved</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-info">accepted</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$PROPOSED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-warning">proposed</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$REJECTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-danger">rejected</span>
                                                            <?php endif; ?>
                                                            </td>

                                                            <td>
                                                                <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-success">Already Approved</span>
                                                                    
                                                                <?php else: ?>
                                                                    <button extras_id="<?php echo e($eachStaffExtra->id); ?>" extras_act="accept" class="btn btn-xs btn-info btn-outline-info" type="button">ACCEPT</button>
                                                                    <button extras_id="<?php echo e($eachStaffExtra->id); ?>" extras_act="reject" class="btn btn-xs btn-danger btn-outline-danger" type="button">REJECT</button>
                                                                    <button extras_id="<?php echo e($eachStaffExtra->id); ?>" extras_act="approve" class="btn btn-xs btn-success btn-outline-success" type="button">APPROVE</button>
                                                                    <button extras_id="<?php echo e($eachStaffExtra->id); ?>" extras_act="modify" class="btn btn-xs btn-warning btn-outline-warning" type="button">MODIFY</button>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            <hr style="border: 1px solid grey;" />
                                        </fieldset>
                                    </div>
                                    <div class="row">
                                        <fieldset id="qualificationsection" class="col-md-12">
                                            <legend  title="#qualification" class="title">Qualification [YET TO BE APPROVED]</legend>
                                            <table class="table table-responsive tab-content">
                                                <thead>
                                                    <tr>
                                                        <td>ID</td>
                                                        <td>Q-TYPE</td>
                                                        <td>QUALIFICATION-TITLE</td>
                                                        <td>QUALIFICATION-DESCRIPTION</td>
                                                        <td>REGISTERED PROFESSIONAL BODY</td>
                                                        <td>STATUS</td>
                                                        <td>ACTION</td>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                       <td>ID</td>
                                                       <td>Q-TYPE</td>
                                                       <td>QUALIFICATION-TITLE</td>
                                                       <td>QUALIFICATION-DESCRIPTION</td>
                                                       <td>REGISTERED PROFESSIONAL BODY</td>
                                                       <td>STATUS</td>
                                                       <td>ACTION</td>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <?php ($countSN = 1); ?>
                                                    <?php $__currentLoopData = $staffExtras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachStaffExtra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($eachStaffExtra->status != \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS ): ?>
                                                        <tr>
                                                            <td><?php echo e($countSN++); ?></td>
                                                            <td><?php echo e($eachStaffExtra->qualificationtype); ?></td>
                                                            <td><?php echo e($eachStaffExtra->title); ?></td>
                                                            <td><?php echo e($eachStaffExtra->description); ?></td>
                                                            <td><?php echo e($eachStaffExtra->registeredprobody); ?></td>
                                                            <td id="staffextras_td<?php echo e($eachStaffExtra->id); ?>" >
                                                            <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-success">approved</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$ACCEPTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-info">accepted</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$PROPOSED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-warning">proposed</span>
                                                            <?php elseif($eachStaffExtra->status == \App\StaffExtras::$REJECTED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-danger">rejected</span>
                                                            <?php endif; ?>
                                                            </td>

                                                            <td>
                                                                <?php if($eachStaffExtra->status == \App\StaffExtras::$APPROVED_QUALIFICATION_STATUS): ?>
                                                                <span class="label label-success">Already Approved</span>
                                                                    <button extras_id="<?php echo e($eachStaffExtra->id); ?>" extras_act="modify" class="btn btn-xs btn-warning btn-outline-warning" type="button">MODIFY</button>
                                                                <?php else: ?>
                                                                    <button extras_id="<?php echo e($eachStaffExtra->id); ?>" extras_act="accept" class="btn btn-xs btn-info btn-outline-info" type="button">ACCEPT</button>
                                                                    <button extras_id="<?php echo e($eachStaffExtra->id); ?>" extras_act="reject" class="btn btn-xs btn-danger btn-outline-danger" type="button">REJECT</button>
                                                                    <button extras_id="<?php echo e($eachStaffExtra->id); ?>" extras_act="approve" class="btn btn-xs btn-success btn-outline-success" type="button">APPROVE</button>
                                                                    <button extras_id="<?php echo e($eachStaffExtra->id); ?>" extras_act="modify" class="btn btn-xs btn-warning btn-outline-warning" type="button">MODIFY</button>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            <hr style="border: 1px solid grey;" />
                                            <div id="qualification_new_div" class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select id="qualificationtype" name="qualificationtype" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option  value="OND">OND</option>
                                                            <option  value="HND">HND</option>
                                                            <option  value="DEG">Degree</option>
                                                            <option  value="PGD">PGD</option>
                                                            <option  value="MSC">MSC</option>
                                                            <option  value="PHD">PHD</option>
                                                            <option  value="OTHERS">Others</option>
                                                        </select>
                                                        <?php if($errors->has('qualificationtype')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtype')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input id="qualificationtitle" name="qualificationtitle" type="text" class="form-control" placeholder="Qualification Title" value="<?php echo e(old('qualificationtitle')); ?>"  required="required" >
                                                        <?php if($errors->has('qualificationtitle')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtitle')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input id="qualificationdesc" name="qualificationdesc" type="text" class="form-control" placeholder="Qualification Description" value="<?php echo e(old('qualificationdesc')); ?>"  required="required" >
                                                        <?php if($errors->has('qualificationdesc')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationdesc')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea id="registeredprobody" required="required" name="registeredprobody" class="form-control" placeholder="Registered Professional Body" ><?php echo e(old('registeredprobody')); ?></textarea>
                                                        <?php if($errors->has('registeredprobody')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('registeredprobody')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>

                                                        <input type="hidden" name="qualificationcount" value="1" >
                                                    </div>
                                                </div>

                                            </div>
                                        </fieldset>
                                    </div>


                                    <button id="add_new_qualification" type="button" class="btn btn-info btn-fill pull-left">New Qualification</button>
                                    &nbsp;&nbsp;<a id="btnsubmit" href="<?php echo e(url('staff/'.$thisStaff->id)); ?>" class="btn btn-primary btn-fill">View Staff</a>
                                    <button id="qualification_submit_btn" type="submit" class="btn btn-success btn-fill pull-right">Submit New Qualification</button>
                                    <div class="clearfix"></div>
                                </form>

                                <div id="conpcass" class="form-group hidden">
                                                <label id="con_label"><?php echo e(__('CONPCASS')); ?></label>
                                                <select id="con___AS_select" class="form-control <?php echo e($errors->has('con___') ? ' is-invalid' : ''); ?> " name="con___" required>

                                                    <?php for($i = 1; $i < 10; $i++): ?>
                                                        <option <?php echo e(old('con___')=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                                <?php if($errors->has('con___')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('con___')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                </div>
                                <div id="contediss" class="form-group hidden">
                                                <label id="con_label"><?php echo e(__('CONTEDISS')); ?></label>
                                                <select id="con___NA_select" class="form-control <?php echo e($errors->has('con___') ? ' is-invalid' : ''); ?> " name="con___" required>

                                                    <?php for($i = 1; $i < 16; $i++): ?>
                                                        <option <?php echo e(old('con___')=="$i"? 'selected="selected"' : ''); ?> value="<?php echo e($i); ?>" ><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                                <?php if($errors->has('con___')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('con___')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                 </div>

                                 <div id="qualificationformcontrols" class="qualificationformcontrols hidden">
                                    <div class="row">
                                                <div class="col-md-1"  >
                                                    <div class="form-group">
                                                        <label>Type</label>
                                                        <select name="qualificationtype[]" required="required" class="form-control">
                                                            <option>Select</option>
                                                            <option value="OND">OND</option>
                                                            <option value="HND">HND</option>
                                                            <option value="DEG">Degree</option>
                                                            <option value="PGD">PGD</option>
                                                            <option value="MSC">MSC</option>
                                                            <option value="PHD">PHD</option>
                                                            <option value="OTHERS">Others</option>
                                                        </select>
                                                        <?php if($errors->has('qualificationtype[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtype[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3"  >
                                                    <div class="form-group">
                                                        <label>Qualification Title</label>
                                                        <input required="required" name="qualificationtitle[]" type="text" class="form-control" placeholder="Qualification Title" value="<?php echo e(old('qualificationtitle[]')); ?>">
                                                        <?php if($errors->has('qualificationtitle[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationtitle[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Qualification Description</label>
                                                        <input required="required" name="qualificationdesc[]" type="text" class="form-control" placeholder="Qualification Description" value="<?php echo e(old('qualificationdesc[]')); ?>"  required="required" >
                                                        <?php if($errors->has('qualificationdesc[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('qualificationdesc[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-4">
                                                    <div class="form-group">
                                                        <label>Registered Professional Body</label>
                                                        <textarea required="required" name="registeredprobody[]" class="form-control" placeholder="Registered Professional Body" ><?php echo e(old('registeredprobody[]', "NONE")); ?></textarea>
                                                        <?php if($errors->has('registeredprobody[]')): ?>
                                                                <span class="has-error invalid-feedback">
                                                                    <strong><?php echo e($errors->first('registeredprobody[]')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>

                                                        <input type="hidden" name="qualificationcount[]" value="1" >
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <button onclick="this.parentNode.parentNode.remove()" type="button" class="btn-sm btn-danger pull-right btn removebtn">Remove</button>
                                                </div>
                                                <div class="col-md-12" style="padding-top: 1px; padding-left: 1px;">
                                                <hr style="border: 1px solid grey;">
                                                </div>
                                            </div>
                                 </div>

<?php endif; ?>
