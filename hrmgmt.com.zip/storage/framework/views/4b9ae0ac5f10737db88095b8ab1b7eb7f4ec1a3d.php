<?php
    $current_page = 'position';
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                        
                        <?php if(isset($displaystate)): ?>
                            <?php if($displaystate == 'edit'): ?>
                                <div class="header">
                                <h4 class="title">Update Position Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('position/'.$position->first()->id )); ?>" method="POST">

                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Position')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Position')); ?>" class="form-control <?php echo e($errors->has('position') ? ' is-invalid' : ''); ?>" name="position" value="<?php echo e(old('position', $position->first()->position)); ?>" required autofocus>
                                                <?php if($errors->has('position')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('position')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Description')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $position->first()->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("position/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Position Information</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php elseif($displaystate == 'delete'): ?>
                                <div class="header">
                                <h4 class="title text-danger">Delete Position Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('position/'.$position->first()->id )); ?>" method="POST">

                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This Position?</h3>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Position')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('Position')); ?>" class="form-control <?php echo e($errors->has('position') ? ' is-invalid' : ''); ?>" name="position" value="<?php echo e(old('position', $position->first()->position)); ?>" required autofocus>
                                                <?php if($errors->has('position')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('position')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Position Description')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('position', $position->first()->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
    
                                    <a href="<?php echo e(url("position/create")); ?>" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE position</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php else: ?>
                                
                                <div class="header">
                                <h4 class="title">View Position Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" >


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Position')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('Position')); ?>" class="form-control <?php echo e($errors->has('position') ? ' is-invalid' : ''); ?>" name="position" value="<?php echo e(old('position', $position->first()->position)); ?>" required autofocus>
                                                <?php if($errors->has('position')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('position')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Description')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $position->first()->description )); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <a href="<?php echo e(url("position/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="<?php echo e(url("position/{$position->first()->id}").'/edit'); ?>" class="btn btn-info btn-fill pull-right">Edit Position Information</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        <?php else: ?>
                            
                            <div class="header">
                                <h4 class="title">Add New Position</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('position.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Position')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('Position')); ?>" class="form-control <?php echo e($errors->has('position') ? ' is-invalid' : ''); ?>" name="position" value="<?php echo e(old('position')); ?>" required autofocus>
                                                <?php if($errors->has('position')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('position')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('Description')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('description')); ?>" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description')); ?>" autofocus>
                                                <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add New Position</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Positions Available</h4>
                                <p class="category">This is the list of All Positions Available</p>
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>Position</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachPosition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($eachPosition->position); ?></td>
                                            <td><?php echo e($eachPosition->description); ?></td>
                                            <td>
                                                <a class="btn btn-sm btn-info" href="<?php echo e(url("position/$eachPosition->id").'/edit'); ?>" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="<?php echo e(url("position/$eachPosition->id")); ?>" >View</a>
                                                <a class="btn btn-sm btn-danger" href="<?php echo e(url("position/$eachPosition->id?action=del")); ?>" >Delete</a>
                                            </td>
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>