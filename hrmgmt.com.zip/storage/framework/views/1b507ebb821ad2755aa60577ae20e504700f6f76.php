<?php
    $current_page = 'school';
?>

<?php echo $__env->make('includes.dashboardheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                        
                        <?php if(isset($displaystate)): ?>
                            <?php if($displaystate == 'edit'): ?>
                                <div class="header">
                                <h4 class="title">Update School Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('school/'.$school->id )); ?>" method="POST">

                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('School')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('School')); ?>" class="form-control <?php echo e($errors->has('school') ? ' is-invalid' : ''); ?>" name="school" value="<?php echo e(old('school', $school->school)); ?>" required autofocus>
                                                <?php if($errors->has('school')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('school')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="<?php echo e(url("school/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update School Information</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php elseif($displaystate == 'delete'): ?>
                                <div class="header">
                                <h4 class="title text-danger">Delete School Confirmation</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(url('school/'.$school->id )); ?>" method="POST">

                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="text-danger">Are You Sure That You Want To DELETE This School?</h3>
                                            <p class="text-danger">This School Can Only Be deleted If no department under it exists?</p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('School')); ?></label>
                                                <input disabled="disabled" type="text" placeholder="<?php echo e(__('School')); ?>" class="form-control <?php echo e($errors->has('school') ? ' is-invalid' : ''); ?>" name="school" value="<?php echo e(old('school', $school->school)); ?>" required autofocus>
                                                <?php if($errors->has('school')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('school')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="<?php echo e(url("school/create")); ?>" class="btn btn-default btn-fill pull-left">No, View All</a> &nbsp;&nbsp;
                                    <button type="submit" class="btn btn-danger btn-fill pull-right">Yes I Want To DELETE School</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php else: ?>
                                
                                <div class="header">
                                <h4 class="title">View School Information</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" >


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('School')); ?></label>
                                                <input readonly="readonly" type="text" placeholder="<?php echo e(__('School')); ?>" class="form-control <?php echo e($errors->has('school') ? ' is-invalid' : ''); ?>" name="school" value="<?php echo e(old('school', $school->school)); ?>" required autofocus>
                                                <?php if($errors->has('school')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('school')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <a href="<?php echo e(url("school/create")); ?>" class="btn btn-default btn-fill pull-left">View All</a> &nbsp;&nbsp;
                                    <a href="<?php echo e(url("school/{$school->id}").'/edit'); ?>" class="btn btn-info btn-fill pull-right">Edit School Information</a>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                            <?php endif; ?>
                        <?php else: ?>
                            
                            <div class="header">
                                <h4 class="title">Add New School</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <form enctype="multipart/form-data" action="<?php echo e(route('school.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label><?php echo e(__('School')); ?></label>
                                                <input type="text" placeholder="<?php echo e(__('School')); ?>" class="form-control <?php echo e($errors->has('school') ? ' is-invalid' : ''); ?>" name="school" value="<?php echo e(old('school')); ?>" required autofocus>
                                                <?php if($errors->has('school')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('school')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add New School</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                   <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">School Available</h4>
                                <p class="category">This is the list of All School Available</p>
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>School</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>

                                        <?php

                                            if(!is_array($school) && !($school instanceof Countable)){
                                                $school = array($school);
                                            }

                                        ?>

                                        <?php $__currentLoopData = $school; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachSchool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($eachSchool->school); ?></td>
                                            <td>
                                                <a class="btn btn-sm btn-info" href="<?php echo e(url("school/$eachSchool->id").'/edit'); ?>" >Edit</a>
                                                <a class="btn btn-sm btn-default" href="<?php echo e(url("school/$eachSchool->id")); ?>" >View</a>
                                                
                                            </td>
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>


                </div>
<?php echo $__env->make('includes.dashboardfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>