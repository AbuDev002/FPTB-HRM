            </div>
        </div>


        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                    </ul>
                </nav>
                <p class="copyright pull-right">
                    &copy; FedPoly Bauchi
                </p>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('assets/js/jquery.3.2.1.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>

    <!--  Charts Plugin -->
    <script src="<?php echo e(asset('assets/js/chartist.min.js')); ?>"></script>

    <!--  Notifications Plugin    -->
    <script src="<?php echo e(asset('assets/js/bootstrap-notify.js')); ?>"></script>

    <!--  Google Maps Plugin    -->
    

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
    <script src="<?php echo e(asset('assets/js/light-bootstrap-dashboard.js?v=1.4.0')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatables.min.js')); ?>"></script>
    


    <!-- jQuery Modal -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />

    <!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
    <script src="<?php echo e(asset('assets/js/demo.js')); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function(){

            demo.initChartist();

            var data = "<?php echo e(url('searchbyclassdept')); ?>?staffclass=as&dept=all&status=12";

            if($('#staffreporttable').length){

                var table = $('#staffreporttable').DataTable( {
                    "retrieve": true,
                    dom: 'Bfrtip',
                    buttons: [
                       'excel', 'print', {
                                        extend: 'pdfHtml5',
                                        orientation: 'landscape',
                                        pageSize: 'LEGAL'
                                    }
                    ],
                    ajax: data
                } );

            }

            if($('#stafftobepromoted').length){

                var table = $('#stafftobepromoted').DataTable( {
                    "retrieve": true,
                    dom: 'Bfrtip',
                    buttons: [
                       'excel', 'print', {
                                        extend: 'pdfHtml5',
                                        orientation: 'landscape',
                                        pageSize: 'LEGAL'
                                    }
                    ]
                } );

            }

            if($('#stafftobepromotedlist').length){

                var table = $('#stafftobepromotedlist').DataTable( {
                    "retrieve": true,
                    dom: 'Bfrtip',
                    buttons: [
                       'excel', 'print', {
                                        extend: 'pdfHtml5',
                                        orientation: 'landscape',
                                        pageSize: 'LEGAL'
                                    }
                    ]
                } );

            }

            /*$.notify({
                icon: 'pe-7s-gift',
                message: "Welcome to <b>FPTB Human Resource Management System</b> - Managing records efficiently."

            },{
                type: 'info',
                timer: 4000
            });*/

            var stateVal ;

            $("#state").on('change',
                function() {
                    $("#lga").load("<?php echo e(url('/statelga').'?stateid='); ?>"+$("#state").val(), function(responseTxt, statusTxt, xhr){
                        if(statusTxt == "success");
                            // alert("External content loaded successfully!");
                        if(statusTxt == "error");
                            // alert("Error: " + xhr.status + ": " + xhr.statusText);
                    });
                }
            );

            $("#school").on('change',
                function() {
                    $("#department").load("<?php echo e(url('/school').'?schoolid='); ?>"+$("#school").val(), function(responseTxt, statusTxt, xhr){
                        if(statusTxt == "success");
                            // alert("External content loaded successfully!");
                        if(statusTxt == "error");
                            // alert("Error: " + xhr.status + ": " + xhr.statusText);
                    });
                }
            );

            $("#department").on('change',
                function() {
                    $("#departmentunit").load("<?php echo e(url('/department_unit_select').'?deptid='); ?>"+$("#department").val(), function(responseTxt, statusTxt, xhr){
                        if(statusTxt == "success");
                            // alert("External content loaded successfully!");
                        if(statusTxt == "error");
                            // alert("Error: " + xhr.status + ": " + xhr.statusText);
                    });
                }
            );

            $("#maritalstatus").on('change',
                function() {
                    if($("#maritalstatus").val() == "M"){
                        $("#childsection1_div").removeClass("hidden");
                        $("#childsection2_div").removeClass("hidden");
                        $("#childsection2_hr").removeClass("hidden");
                    }else{
                        $("#childsection1_div").addClass("hidden");
                        $("#childsection2_div").addClass("hidden");
                        $("#childsection2_hr").addClass("hidden");

                        // $("#childsection1_div :input").val("");
                        // $("#childsection2_div :input").val("");
                    }
                }
            );


            <?php if(isset($table_count_show)): ?>
                <?php for($i = 1; $i < count($users); $i++): ?>
                    $("<?php echo e('#userloginhistory_'.$i); ?>").DataTable( {
                                dom: 'Bfrtip',
                                buttons: [
                                    'excel', 'pdf', 'print'
                                ]
                     });
                <?php endfor; ?>
            <?php endif; ?>

            if($("#entirestafflist").length){
                $('#entirestafflist').DataTable( {
                                dom: 'Bfrtip',
                                buttons: [
                                    'excel', 'print',
                                    {
                                        extend: 'pdfHtml5',
                                        orientation: 'landscape',
                                        pageSize: 'LEGAL'
                                    }
                                ]
                            } );
            }

            if($("#reportable_staff").length){
                $('#reportable_staff').DataTable( {
                                "paging":   false,
                                "ordering": false,
                                "info":     false,
                                dom: 'Bfrtip',
                                buttons: [
                                    'excel', 'print',
                                    {
                                        extend: 'pdfHtml5',
                                        orientation: 'landscape',
                                        pageSize: 'LEGAL'
                                    }
                                ]
                            } );
            }

            if($("#summaryStaffReport").length){
                $('#summaryStaffReport').DataTable( {
                                "paging":   false,
                                "ordering": false,
                                "info":     false,
                                dom: 'Bfrtip',
                                buttons: [
                                    'excel', 'print',
                                    {
                                        extend: 'pdfHtml5',
                                        orientation: 'landscape',
                                        pageSize: 'LEGAL'
                                    }
                                ]
                            } );
            }


            if($("#account_login_history_personal").length){
                $('#account_login_history_personal').DataTable( {
                                dom: 'Bfrtip',
                                buttons: [
                                    'excel', 'print',
                                    {
                                        extend: 'pdfHtml5',
                                        pageSize: 'LEGAL'
                                    }
                                ]
                            } );
            }

            $("#btn_select_staff").on('click', function(){
               if($("#btn_select_staff").hasClass('btn-fill')){ // Already Selected
                    $("#btn_select_staff").removeClass('btn-fill');
                    window.location = encodeURI("<?php echo e(url('staff')); ?>");
               }else{ // Not yet selected
                    $("#btn_select_staff").addClass('btn-fill');
                    window.location = encodeURI("<?php echo e(url('staff')); ?>/?hide1=action&hide2=photo");
               }
            });

            
            const _MS_PER_DAY__SPECIAL = 1000 * 60 * 60 * 24;

            // a and b are javascript Date objects
            function myDateDiffInDays(a, b) {
              // Discard the time and time-zone information.
              const utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
              const utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());

              return Math.floor((utc2 - utc1) / _MS_PER_DAY__SPECIAL);
            }

            // test it
            // const a = new Date("2017-01-01"),
            //     b = new Date("2017-07-25"),
            //     difference = myDateDiffInDays(a, b);

            $("#btn_select_staff_promote").on('click', function(){

               var is_range_considered = false;
               // var is_range_considered = $('#range_considered').is(':checked');
               // var date_range_from = $("#daterange_input_from").val();
               // var date_range_to = $("#daterange_input_to").val();

               var year = $("#promotion_year").val();
               var janQ = $("#jan_quater").is(':checked');
               var julyQ = $("#july_quater").is(':checked');
               var all_quater = $("#all_quater").is(':checked');;

               if(janQ) { quater = 'jan'; } 
               if(julyQ) { quater = 'july'; }

               if(all_quater) { quater = 'all'; }

               if(is_range_considered){

                   // var a_from_date_1 = new Date(date_range_from);
                   // var b_to_date_2 = new Date(date_range_to);

                   // var date_diff_from_to = myDateDiffInDays(a_from_date_1, b_to_date_2);
                   // alert(date_diff_from_to);

                   /*if( date_range_from.trim().length == 0 || date_range_to.trim().length == 0 ){
                       alert("Please Enter A Valid Date Range");
                       return;
                   }

                   if(date_diff_from_to < 0){
                       alert("Please `From-Date` Cannot Be Ahead Of `To-Date`. Enter Valid Date Range");
                       return;
                   }*/

                   /*if($("#btn_select_staff_promote").hasClass('btn-fill')){ // Already Selected
                        $("#btn_select_staff_promote").removeClass('btn-fill');
                        window.location = encodeURI("<?php echo e(url('promotionlist')); ?>/?&fd="+ date_range_from +"&td=" + date_range_to +"&quater=" + quater +"&year=" + year );
                   }else{ // Not yet selected
                        $("#btn_select_staff_promote").addClass('btn-fill');
                        window.location = encodeURI("<?php echo e(url('promotionlist')); ?>/?hide1=action&hide2=photo&fd="+ date_range_from +"&td=" + date_range_to  +"&quater=" + quater +"&year=" + year );
                   }*/

               }else{

                   if($("#btn_select_staff_promote").hasClass('btn-fill')){ // Already Selected
                        $("#btn_select_staff_promote").removeClass('btn-fill');
                        window.location = encodeURI("<?php echo e(url('promotionlist')); ?>/?"  +"quater=" + quater +"&year=" + year );
                   }else{ // Not yet selected
                        $("#btn_select_staff_promote").addClass('btn-fill');
                        window.location = encodeURI("<?php echo e(url('promotionlist')); ?>/?hide1=action&hide2=photo"  +"&quater=" + quater +"&year=" + year );
                   }
               }

            });

            $("#btn_enable_staff_update").on('click', function(){

               var confim_activate = confirm("Are you sure that you want to Allow Staff To Update Their Information?");
               if(confim_activate){
                    $.ajax({url: "<?php echo e(url('/enablestaffupdate')); ?>", success: function(result){
                                $("#btn_enable_staff_update").addClass('hidden');
                                $("#btn_disable_staff_update").removeClass('hidden');
                            }});
                }
            });

            $("#btn_disable_staff_update").on('click', function(){

               var confim_activate = confirm("Are you sure that you want to Dis-Allow Staff From Updating Their Information?");
               if(confim_activate){
                    $.ajax({url: "<?php echo e(url('/enablestaffupdate')); ?>", success: function(result){
                                $("#btn_enable_staff_update").removeClass('hidden')
                                $("#btn_disable_staff_update").addClass('hidden');
                            }});
                }
            });


            $("#btn_class_department").on('click', function(){

                if($("#searchByStaffClass").val().length == 0 && $("#searchByDepartment").val().length == 0){
                    alert("Please Select StaffClass And Department To Proceed");
                    return;
                }else if($("#searchByStaffClass").val().length == 0){
                    alert("Please Select StaffClass To Proceed");
                    return;
                }else if($("#searchByDepartment").val().length == 0){
                    alert("Please Select Department To Proceed");
                    return;
                }

                var indicatorImg = document.getElementsByClassName("imgloaderindicator");
                indicatorImg[0].style.display = "block";
                $("#btn_class_department").addClass("btn-fill");

                var data_loaded = "<?php echo e(url('/searchbyclassdept').'?staffclass='); ?>"+$("#searchByStaffClass").val() +"&dept="+$("#searchByDepartment").val() + "&status="+$("#searchByStatus").val();

                if ( $.fn.dataTable.isDataTable( '#staffreporttable' ) ) {
                    var table = $('#staffreporttable').DataTable();
                    console.log("IS DataTable");
                    table.ajax.url( data_loaded ).load(function( settings ) {
                        console.log( 'DataTables has redrawn the table' );
                        indicatorImg[0].style.display = "none";
                        document.getElementById('staff_report_title').scrollIntoView();
                        $("#btn_class_department").removeClass("btn-fill");
                    }, true);
                }else{
                    var table = $('#staffreporttable').DataTable( {
                    retrieve: true,
                    dom: 'Bfrtip',
                    buttons: [
                       'excel', 'print', {
                                        extend: 'pdfHtml5',
                                        orientation: 'landscape',
                                        pageSize: 'LEGAL'
                                    }
                    ],
                    ajax: data_loaded
                } );
                }

            });


            $("#btn_staffno").on('click', function(){

                if($("#staffno").val().length == 0){
                    alert("Please Enter StaffNo To Proceed");
                    return;
                }

                var indicatorImg = document.getElementsByClassName("imgloaderindicator");
                indicatorImg[0].style.display = "block";
                $("#btn_staffno").addClass("btn-fill");

                var data_loaded = "<?php echo e(url('/searchbystaffno').'?staffno='); ?>"+$("#staffno").val()  + "&status="+$("#searchByStatus").val();

                if ( $.fn.dataTable.isDataTable( '#staffreporttable' ) ) {
                    var table = $('#staffreporttable').DataTable();
                    console.log("IS DataTable");
                    table.ajax.url( data_loaded ).load(function( settings ) {
                        console.log( 'DataTables has redrawn the table' );
                        indicatorImg[0].style.display = "none";
                        document.getElementById('staff_report_title').scrollIntoView();
                        $("#btn_staffno").removeClass("btn-fill");
                    }, true);
                }else{
                    var table = $('#staffreporttable').DataTable( {
                    retrieve: true,
                    dom: 'Bfrtip',
                    buttons: [
                       'excel', 'print', {
                                        extend: 'pdfHtml5',
                                        orientation: 'landscape',
                                        pageSize: 'LEGAL'
                                    }
                    ],
                    ajax: data_loaded
                } );
                }

            });

            $("#btn_names").on('click', function(){


                if($("#fname").val().length == 0 && $("#oname").val().length == 0 && $("#lname").val().length == 0){
                    alert("Please Enter Either A FirstName, LastName Or OtherName");
                    return;
                }

                var indicatorImg = document.getElementsByClassName("imgloaderindicator");
                indicatorImg[0].style.display = "block";
                $("#btn_names").addClass("btn-fill");

                var data_loaded = "<?php echo e(url('/searchbystaffnames').'?fname='); ?>"+$("#fname").val() + "&oname="+$("#oname").val() + "&lname=" + $("#lname").val()  + "&status="+$("#searchByStatus").val();

                if ( $.fn.dataTable.isDataTable( '#staffreporttable' ) ) {
                    var table = $('#staffreporttable').DataTable();
                    console.log("IS DataTable");
                    table.ajax.url( data_loaded ).load(function( settings ) {
                        console.log( 'DataTables has redrawn the table' );
                        indicatorImg[0].style.display = "none";
                        document.getElementById('staff_report_title').scrollIntoView();
                        $("#btn_names").removeClass("btn-fill");
                    });
                }else{
                    var table = $('#staffreporttable').DataTable( {
                    retrieve: true,
                    dom: 'Bfrtip',
                    buttons: [
                       'excel', 'print', {
                                        extend: 'pdfHtml5',
                                        orientation: 'landscape',
                                        pageSize: 'LEGAL'
                                    }
                    ],
                    ajax: data_loaded
                } );
                }
            });

            $("#staff_status").on('change',
                function() {
                    $("#btnstaff_status").prop("disabled", false);
                    $("#btnstaff_status").trigger('mouseOver');
            });

            $("#leaveto_date").on('change',
                function() {
                    var fromdate = $("#leavefrom_date").val();
                    var todate = $("#leaveto_date").val();

                    var fromDateObj = new Date(fromdate);
                    var toDateObj = new Date(todate);

                    if(toDateObj - fromDateObj <= 0 ){
                        alert('Please Enter A Valid Range: ToDate Can\'t Be Earlier Than From Date');
                        // disable submit button
                    }else{
                        // enable submit button

                    }


            });

            $("#staff_status_form").on('submit', function(e) {
                var ok = confirm("Are You Sure That You Want To Effect Status Change For This Staff As: '" + $("#staff_status option:selected").text() + "'?");

                if(ok){

                    //windows.location = encodeURI("<?php echo e(url('staff')); ?>");
                    return true;
                }else{
                    $("#staff_status option:first").prop('selected',true);
                    $("#btnstaff_status").prop("disabled", true);
                    return false;
                }
            });


            $("#staff_level_form :input").on('change', function(){
                $("#staff_level_update_btn").prop("disabled", false);
            });

            $("#staff_level_form").on('submit', function(){
                var ok = confirm("Are You Sure That You Want To Proceed With the Updates made so far?");

                if(ok){
                    return true;
                }else{
                    $("#staff_level_update_btn").prop("disabled", true);
                    $("#staff_level_form")[0].reset();
                    return false;
                }
            });


            $("#staff_school_dept_update_form :input").on('change', function(){
                $("#staff_school_dept_update_btn").prop("disabled", false);
            });

            $("#staff_school_dept_update_form").on('submit', function(){
                var ok = confirm("Are You Sure That You Want To Effect the Updates made?");

                if(ok){
                    return true;
                }else{
                    $("#staff_school_dept_update_btn").prop("disabled", true);
                    $("#staff_school_dept_update_form")[0].reset();
                    return false;
                }
            });

            $("#btn_basic_update_form :input").on('change', function(){
                $("#staff_basic_update_btn").prop("disabled", false);
            });

            $("#btn_basic_update_form").on('submit', function(){
                var ok = confirm("Are You Sure That You Want To Effect the Updates made?");

                if(ok){
                    return true;
                }else{
                    $("#staff_basic_update_btn").prop("disabled", true);
                    $("#btn_basic_update_form")[0].reset();
                    return false;
                }
            });

            $("#staffclass").on('change',
                function() {
                    var staffclassval = $("#staffclass").val();

                    if(staffclassval == 'AS'){
                        $("#con___parent").html($('#conpcass').html());
                        $('#con___parent#conpcass').removeClass('hidden');
                    }else if(staffclassval == 'NA'){
                        $("#con___parent").html($('#contediss').html());
                        $('#con___parent#contediss').removeClass('hidden');
                    }

                    $("#rank").load("<?php echo e(url('/getranks').'?staffclass='); ?>"+staffclassval, function(responseTxt, statusTxt, xhr){
                        if(statusTxt == "success");
                            // alert("External content loaded successfully!");
                        if(statusTxt == "error");
                            // alert("Error: " + xhr.status + ": " + xhr.statusText);
                    });
                }
            );

            $(".click_promote_btn").on('click', function(){
                alert("This is COOOL" + $(this).attr('href'));
            });

            $("#salaryscale_select").on('change',
                function() {
                    var salaryscale = $("#salaryscale_select").val().trim();

                    if(salaryscale == ''){
                        // return;
                    }
                    // else if(staffclassval == 'AS'){
                    //     $("#con___parent").html($('#conpcass').html());
                    //     $('#con___parent#conpcass').removeClass('hidden');
                    // }else if(staffclassval == 'NA'){
                    //     $("#con___parent").html($('#contediss').html());
                    //     $('#con___parent#contediss').removeClass('hidden');
                    // }

                    $("#salaryscalevalue_select").load("<?php echo e(url('/getvalues').'?salaryscale='); ?>"+salaryscale, function(responseTxt, statusTxt, xhr){
                        if(statusTxt == "success");
                            // alert("External content loaded successfully!");
                        if(statusTxt == "error");
                            // alert("Error: " + xhr.status + ": " + xhr.statusText);
                    });
                }
            );

            var countQF = 0;

            $("#add_qualification").on('click',
                function() {
                    $('#qualificationsection').append($('#qualificationformcontrols').html());
                }
            );

            $("#add_new_qualification").on('click',
                function() {
                    console.log("QFM");
                    var this_staff = $('#this_staff').val();
                    $("#qualification_form").attr('action', '<?php echo e(url('staff_qualification')); ?>' );
                    $('#qualification_form_method').val("POST");
                    $('#qualificationtype').val("");
                    $('#qualificationtype').focus();
                    $('#qualificationtitle').val("");
                    $('#qualificationdesc').val("");
                    $('#registeredprobody').val("");

                    $("#qualification_submit_btn").html("Submit New Qualification");
                }
            );


            $('button').on('click', function () {

                var me_u = $(this).attr('me_u');
                var u_i = $(this).attr('user_id');
                var u_a = $(this).attr('action');

                if(u_i > 0){
                    var ok = confirm("Are You Sure That You Want To "+ (u_a.toUpperCase()) + " this User?")

                    if(ok){
                        if(me_u == "ad"){

                            $.ajax({url: "<?php echo e(url('/user_activate')); ?>/?user_id="+u_i + "&u_a="+u_a, success: function(result){
                                console.log(result);
                                console.log(u_a);
                                if(result == "success"){
                                    location.reload(true);
                                }
                            }
                            });
                        }
                    }
                }

            });

            $('#btn_comment_update').on('click', function () {

                var thisstaff_id = $("#this_staff_id").val();
                var condolence_comment = $("#cond_comment").val();

                if(condolence_comment.trim().length > 0){
                            $.ajax({url: "<?php echo e(url('/condolence')); ?>/?staff_id="+thisstaff_id + "&condolence_comment="+condolence_comment, success: function(result){
                                console.log(result);
                                console.log(u_a);
                                if(result == "success"){
                                    location.reload(true);
                                }
                            }

                            });
                }

            });

            $('form').on('submit', function () {

               $iflogout = $(this).attr('loguserout');

               if($iflogout == 'yes'){

                   var ok = confirm("Are You Sure That You Want To Log This User Out?");

                    if(ok)
                        return true;

                    return false;
               }
            });

            $('button').on('click', function () {


                var extra_id = $(this).attr('extras_id');
                var extra_act = $(this).attr('extras_act');

                //console.log("Testing");
                //console.log(extra_act);

                if(extra_act == "modify"){

                    $("#qualification_new_div").load("<?php echo e(url('staff_qualification').'?extra_id='); ?>"+extra_id +"&extra_act="+extra_act, function(responseTxt, statusTxt, xhr){
                        if(statusTxt == "success")
                            // alert("External content loaded successfully!");
                            console.log("SUCCESS")
                            $('#qualification_form_method').val("PUT");
                            $("#qualification_submit_btn").html("Update Qualification");
                        if(statusTxt == "error")
                            console.log("ERROR")
                            $("#qualification_new_div").html();

                    });


                }else if(extra_act == "modify" || extra_act == "approve" || extra_act == "reject" || extra_act == "accept"){

                    $.ajax({url: "<?php echo e(url('/staff_qualification')); ?>/?extra_id="+extra_id + "&extra_act="+extra_act, success: function(result){
                        console.log(result);
                        console.log(extra_act);
                        if(result == "success"){

                            if(extra_act == "approve"){
                                $("#staffextras_td"+extra_id).html('<span class="label label-success">approved</span>');
                                location.reload(true);
                            }else if(extra_act == "accept"){
                                $("#staffextras_td"+extra_id).html('<span class="label label-info">accepted</span>');
                            }else if(extra_act == "reject"){
                                $("#staffextras_td"+extra_id).html('<span class="label label-danger">rejected</span>');
                            }

                        }else{
                            location.reload(true);
                        }
                    }

                    });

                    }

            });

            $("#staffnocheck").on('keyup', function(){
                var curval = $(this).val();
                $.ajax({url: "<?php echo e(url('/checkstaffno')); ?>/?staffnovalue="+curval, success: function(result){
                    // $("#div1").html(result);
                    console.log(result);
                    if(result == "YES"){

                        $("#staffnocheckokmessage").removeClass('hide');
                        $("#staffnocheckbadmessage").addClass('hide');

                        $("#btnsubmit").prop("disabled", false);
                    }else{

                        $("#staffnocheckokmessage").addClass('hide');
                        $("#staffnocheckbadmessage").removeClass('hide');

                        $("#btnsubmit").prop("disabled", true);
                    }
                }});
            });``

            $("#staffno_quick_find").on('keyup', function(){
                var curval = $(this).val();
                $.ajax({url: "<?php echo e(url('/checkstaffno_quick_find')); ?>/?staffnovalue="+curval, success: function(result){

                    console.log(result);
                    if(result == "NO"){
                        $("#quick_find_table_div").html("");
                        $("#staff_listing_quick_search").addClass('hide');
                    }else{
                        $("#staff_listing_quick_search").removeClass('hide');
                        $("#quick_find_table_div").html(result);

                    }
                }});
            });

            $("#btn_names_quick_search").on('click', function(){


                if($("#full_name_quick_search").val().length == 0){
                    alert("Please Enter A Staff Name");
                    return;
                }

                var indicatorImg = document.getElementsByClassName("imgloaderindicator");
                indicatorImg[0].style.display = "block";
                $("#btn_names").addClass("btn-fill");

                $.ajax({url: "<?php echo e(url('/searchbystaffnames_quick_find').'?fullname='); ?>"+$("#full_name_quick_search").val(), success: function(result){

                    console.log(result);
                    if(result == "NO"){
                        console.log("NO");
                        $("#quick_find_table_div").html("");
                        $("#staff_listing_quick_search").addClass('hide');

                        indicatorImg[0].style.display = "none";
                        $("#btn_names").removeClass("btn-fill");

                    }else{
                        $("#staff_listing_quick_search").removeClass('hide');
                        $("#quick_find_table_div").html(result);
                        indicatorImg[0].style.display = "none";
                        $("#btn_names").removeClass("btn-fill");
                    }
                }});

            });

        });
    </script>

</html>
